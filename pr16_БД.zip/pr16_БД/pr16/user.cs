﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pr16
{
    public partial class user : Form
    {
        string str = "host=localhost;user=root;pwd=root;database=pr16_kichigin";
        string login;
        public bool realClose = false;
        public user(string login)
        {
            InitializeComponent();
            dateTimePicker1.Value = DateTime.Now;
            this.login = login;
        }

        private void exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
            realClose = true;
        }
        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (!realClose)
                e.Cancel = true;
        }

        private void user_Load(object sender, EventArgs e)
        {
            MySqlConnection con = new MySqlConnection(str);
            try
            {
                con.Open();
                MySqlCommand cmd = new MySqlCommand(@"SELECT full_name FROM user WHERE login = @login", con);
                cmd.Parameters.AddWithValue("@login", login);

                object result = cmd.ExecuteScalar();

                label1.Text = $"Добро пожаловать, {result.ToString()}!";

                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка подключения к БД: {ex.Message}");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            authorization authorizationForm = new authorization();
            this.Visible = false;
            authorizationForm.ShowDialog();
            this.Visible = false;
        }
    }
}