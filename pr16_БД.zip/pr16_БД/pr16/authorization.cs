﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ProgressBar;

namespace pr16
{
    public partial class authorization : Form
    {
        string str = "host=localhost;user=root;pwd=root;database=pr16_kichigin";

        string[] img = { @"imgCaptha/one.jpg", @"imgCaptha/two.jpg", @"imgCaptha/three.jpg" };

        Random random = new Random();

        int ran;
        int proverka;
        int try_authorize = 3;
        public authorization()
        {
            InitializeComponent();

            //шифрование пароля
            password.PasswordChar = '*';

            reroll.Cursor = Cursors.Hand;

            proverka = randomImage(ran);
        }

        private void authorization_Load(object sender, EventArgs e)
        {
            try
            {
                MySqlConnection con = new MySqlConnection(str);
                con.Open();

                MySqlCommand cmd = new MySqlCommand();
                cmd.Connection = con;

                cmd.CommandText = @"SELECT 
                        CONCAT(full_name, ' (', login, ')') AS display_text,
                        id AS user_id
                        FROM user;";

                MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                DataTable dt2 = new DataTable();

                da.Fill(dt2);

                comboBox1.DataSource = dt2;
                comboBox1.DisplayMember = "display_text";
                comboBox1.ValueMember = "user_id";

                con.Close();

                comboBox1.SelectedIndex = -1;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "Ошибка заполнения списков", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        string GetHashPass(string password)
        {
            //получаем байтовое представление строки
            //byte[] bytesPass = Encoding.Unicode.GetBytes(password);
            byte[] bytesPass = Encoding.UTF8.GetBytes(password);

            //экземпляр класса для работы с алгоритмом SHA256
            SHA256Managed hashstring = new SHA256Managed();

            //получаем хеш из строки в виде массива байтов
            byte[] hash = hashstring.ComputeHash(bytesPass);

            //очищаем строку
            string hashPasswd = string.Empty;

            //собираем полученный хеш воедино
            foreach (byte x in hash)
            {
                hashPasswd += String.Format("{0:x2}", x);
            }

            //освобождаем все ресурсы связанные с экземпляром объекта SHA256Managed
            hashstring.Dispose();

            return hashPasswd;
        }

        bool tryCaptha(int captha, string text)
        {
            if(captha == 0 && text == "798yuhi")
            {
                return true;
            }
            if (captha == 1 && text == "zser67e")
            {
                return true;
            }
            if (captha == 2 && text == "8tyugh")
            {
                return true;
            }

            return false;
        }
        private void authorize_Click(object sender, EventArgs e)
        {
            try
            {
                string login = Regex.Match(comboBox1.Text, @"\((.*?)\)").Groups[1].Value;
                string inputPassword = password.Text;
                string captchaText = textBox1.Text;

                using (MySqlConnection con = new MySqlConnection(str))
                {
                    con.Open();

                    MySqlCommand cmd = new MySqlCommand(
                        "SELECT password, category FROM user WHERE login=@login", con);
                    cmd.Parameters.AddWithValue("@login", login);

                    MySqlDataAdapter sda = new MySqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    sda.Fill(dt);

                    if (dt.Rows.Count == 0)
                    {
                        MessageBox.Show("Пользователь не найден",
                            "Ошибка авторизации", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    string hashPassword = GetHashPass(inputPassword);

                    string hashPasswordInDB = dt.Rows[0]["password"].ToString();

                    string category = dt.Rows[0]["category"].ToString();

                    if (hashPassword == hashPasswordInDB)
                    {
                        if (tryCaptha(proverka, captchaText))
                        {
                            this.Visible = false;

                            if (category == "Администратор")
                            {
                                admin open = new admin(category);
                                open.ShowDialog();
                            }
                            else
                            {
                                user open = new user(login);
                                open.ShowDialog();
                            }

                            Close();
                        }
                        else
                        {
                            MessageBox.Show("Неверно введена капча",
                                "Ошибка авторизации", MessageBoxButtons.OK, MessageBoxIcon.Error);

                            proverka = randomImage(ran);
                            textBox1.Text = "";
                        }
                    }
                    else
                    {
                        MessageBox.Show("Неверный логин или пароль",
                            "Ошибка авторизации", MessageBoxButtons.OK, MessageBoxIcon.Error);

                        proverka = randomImage(ran);
                        comboBox1.SelectedIndex = -1;
                        password.Text = "";
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            --try_authorize;
            authorize.Text = $"Авторизовать (Осталось {try_authorize} попыток)";

            if (try_authorize == 0)
            {
                authorize.Enabled = false;
                authorize.Text = "Система заблокирована на 5 секунд";
                MessageBox.Show("Превышено количество попыток",
                    "Блокировка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void authorize_MouseClick(object sender, MouseEventArgs e)
        {
            if (try_authorize == 0)
            {
                Thread.Sleep(5000);
                try_authorize = 3;
                authorize.Text = "Осталось " + Convert.ToString(try_authorize) + " попыток";
            }
        }
        int randomImage(int ran)
        {
            for (int i = 0; i < img.Length; i++)
            {
                ran = random.Next(img.Length);
                if (ran == 0)
                {
                    captha.Image = Image.FromFile(img[ran]);
                    return 0;
                }
                else if (ran == 1)
                {
                    captha.Image = Image.FromFile(img[ran]);
                    return 1;
                }
                else if (ran == 2)
                {
                    captha.Image = Image.FromFile(img[ran]);
                    return 2;
                }
            }
            return 0;
        }
        private void reroll_Click(object sender, EventArgs e)
        {
            proverka = randomImage(ran);
        }
        private void exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
