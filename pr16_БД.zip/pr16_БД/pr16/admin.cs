﻿using System;
using System.Data;
using System.Text;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace pr16
{
    public partial class admin : Form
    {
        string str = "host=localhost;user=root;pwd=root;database=pr16_kichigin";
        public bool realClose = false;

        public admin(string userCategory)
        {
            InitializeComponent();

            if (userCategory != "Администратор")
            {
                MessageBox.Show("Доступ запрещён", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                Close();
                return;
            }

            comboBox1.Items.AddRange(new string[] { "Администратор", "Пользователь" });
            comboBox1.SelectedIndex = 1;

            SetAddMode();
            LoadUsers();
        }

        void LoadUsers()
        {
            using (MySqlConnection con = new MySqlConnection(str))
            {
                string sql = @"SELECT id, login, category, full_name, phone,
                               create_account, mode_account FROM user";

                MySqlDataAdapter da = new MySqlDataAdapter(sql, con);
                DataTable dt = new DataTable();
                da.Fill(dt);

                dataGridView1.DataSource = dt;

                dataGridView1.Columns["id"].Visible = false;

                dataGridView1.Columns["login"].HeaderText = "Логин";
                dataGridView1.Columns["category"].HeaderText = "Категория";
                dataGridView1.Columns["full_name"].HeaderText = "ФИО";
                dataGridView1.Columns["phone"].HeaderText = "Телефон";
                dataGridView1.Columns["create_account"].HeaderText = "Дата создания";
                dataGridView1.Columns["mode_account"].HeaderText = "Дата изменения";

                dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
                dataGridView1.ReadOnly = true;
                dataGridView1.AllowUserToAddRows = false;
                dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            }
        }

        void SetAddMode()
        {
            button3.Enabled = true;
            button1.Enabled = false;
        }

        void SetEditMode()
        {
            button3.Enabled = false;
            button1.Enabled = true;
        }

        bool ValidateInput()
        {
            if (string.IsNullOrWhiteSpace(textBox1.Text))
            {
                MessageBox.Show("Введите логин");
                return false;
            }
            if (string.IsNullOrWhiteSpace(textBox3.Text))
            {
                MessageBox.Show("Введите пароль");
                return false;
            }
            if (comboBox1.SelectedIndex == -1)
            {
                MessageBox.Show("Выберите категорию");
                return false;
            }
            if (string.IsNullOrWhiteSpace(textBox2.Text))
            {
                MessageBox.Show("Введите ФИО");
                return false;
            }
            if (!maskedTextBox1.MaskCompleted)
            {
                MessageBox.Show("Введите номер телефона полностью");
                return false;
            }
            return true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            const string chars =
                "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*";
            Random rnd = new Random();
            int length = rnd.Next(4, 9);

            StringBuilder pass = new StringBuilder();
            for (int i = 0; i < length; i++)
                pass.Append(chars[rnd.Next(chars.Length)]);

            textBox3.Text = pass.ToString();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (!ValidateInput()) return;

            try
            {
                using (MySqlConnection con = new MySqlConnection(str))
                {
                    con.Open();

                    MySqlCommand check = new MySqlCommand(
                        "SELECT COUNT(*) FROM user WHERE login=@login", con);
                    check.Parameters.AddWithValue("@login", textBox1.Text);

                    if (Convert.ToInt32(check.ExecuteScalar()) > 0)
                    {
                        MessageBox.Show("Пользователь с таким логином уже существует");
                        return;
                    }

                    MySqlCommand cmd = new MySqlCommand(@"
                        INSERT INTO user
                        (login, password, category, full_name, phone, create_account, mode_account)
                        VALUES
                        (@login, SHA2(@pass,256), @cat, @fio, @phone, NOW(), NOW())", con);

                    cmd.Parameters.AddWithValue("@login", textBox1.Text);
                    cmd.Parameters.AddWithValue("@pass", textBox3.Text);
                    cmd.Parameters.AddWithValue("@cat", comboBox1.Text);
                    cmd.Parameters.AddWithValue("@fio", textBox2.Text);
                    cmd.Parameters.AddWithValue("@phone", maskedTextBox1.Text);

                    cmd.ExecuteNonQuery();

                    MessageBox.Show("Пользователь добавлен");
                    LoadUsers();
                    ClearForm();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка: " + ex.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow == null)
            {
                MessageBox.Show("Выберите пользователя");
                return;
            }

            if (!ValidateInput()) return;

            try
            {
                int id = Convert.ToInt32(dataGridView1.CurrentRow.Cells["id"].Value);

                using (MySqlConnection con = new MySqlConnection(str))
                {
                    con.Open();

                    MySqlCommand cmd = new MySqlCommand(@"
                        UPDATE user SET
                        login=@login,
                        password=SHA2(@pass,256),
                        category=@cat,
                        full_name=@fio,
                        phone=@phone,
                        mode_account=NOW()
                        WHERE id=@id", con);

                    cmd.Parameters.AddWithValue("@id", id);
                    cmd.Parameters.AddWithValue("@login", textBox1.Text);
                    cmd.Parameters.AddWithValue("@pass", textBox3.Text);
                    cmd.Parameters.AddWithValue("@cat", comboBox1.Text);
                    cmd.Parameters.AddWithValue("@fio", textBox2.Text);
                    cmd.Parameters.AddWithValue("@phone", maskedTextBox1.Text);

                    cmd.ExecuteNonQuery();

                    MessageBox.Show("Данные обновлены");
                    LoadUsers();
                    ClearForm();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка: " + ex.Message);
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            textBox1.Text = dataGridView1.Rows[e.RowIndex].Cells["login"].Value.ToString();
            comboBox1.Text = dataGridView1.Rows[e.RowIndex].Cells["category"].Value.ToString();
            textBox2.Text = dataGridView1.Rows[e.RowIndex].Cells["full_name"].Value.ToString();
            maskedTextBox1.Text = dataGridView1.Rows[e.RowIndex].Cells["phone"].Value.ToString();

            SetEditMode();
        }

        void ClearForm()
        {
            textBox1.Text = "";
            textBox3.Text = "";
            comboBox1.SelectedIndex = -1;
            textBox2.Text = "";
            maskedTextBox1.Text = "";

            dataGridView1.ClearSelection();
            SetAddMode();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            ClearForm();
        }

        private void exit_Click(object sender, EventArgs e)
        {
            authorization authorizationForm = new authorization();
            this.Visible = false;
            authorizationForm.ShowDialog();
            this.Visible = false;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Application.Exit();
            realClose = true;
        }
        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (!realClose)
                e.Cancel = true;
        }
    }
}
