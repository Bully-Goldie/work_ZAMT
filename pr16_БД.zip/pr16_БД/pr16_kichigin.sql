CREATE DATABASE pr16_kichigin;

USE pr16_kichigin;

CREATE TABLE user(id INT AUTO_INCREMENT PRIMARY KEY,
				login VARCHAR(50) NOT NULL UNIQUE,
				password VARCHAR(255) NOT NULL,
				category ENUM('Администратор', 'Пользователь') NOT NULL,
                full_name VARCHAR(100) NOT NULL,
				phone VARCHAR(20) NOT NULL,
				create_account DATETIME NOT NULL,
				mode_account DATETIME NOT NULL);

INSERT INTO user(login, password, category, full_name, phone, create_account, mode_account) VALUES
('admin', SHA2('admin', 256), 'Администратор', 'Иванов Иван Иванович', '+7 (912) 345-67-89', '2025-01-15 10:00:00', NOW()),
('user1', SHA2('user1', 256), 'Пользователь', 'Большаков Семен Александрович', '+7 (922) 344-67-82', '2025-04-16 10:00:00', NOW()),
('user2', SHA2('user2', 256), 'Пользователь', 'Зенленкин Андрей Алексеевич', '+7 (967) 324-57-72', '2025-05-16 10:00:00', NOW()),
('user3', SHA2('user3', 256), 'Пользователь', 'Ерышев Андрей Борисович', '+7 (911) 312-66-76', '2025-07-18 10:00:00', NOW()),
('user4', SHA2('user4', 256), 'Пользователь', 'Пшеницын Даниил Олегович', '+7 (919) 822-63-86', '2025-07-18 10:00:00', NOW());