﻿using System;
using System.Xml;
using System.Xml.Linq;

namespace пр19
{
    internal class Program
    {
        static int DigitN(int K, int N)
        {
            if (K <= 0 || N <= 0)
            {
                return -1;
            }
            int pos = 1;
            while (K > 0)
            {
                int last = K % 10;
                if (pos == N)
                {
                    return last;
                }
                K /= 10;
                pos++;
            }
            return -1;
        }
        static void Main(string[] args)
        {
            // Задание 1
            // Проверить истинность высказывания: "Все цифры данного целого положительного пятизначного числа введенного с клавиатуры различны".
            try
            {
                XmlDocument doc = new XmlDocument();
                doc.Load("input1.xml");

                XmlNodeList items = doc.GetElementsByTagName("PR19");

                int N = 0;

                foreach (XmlNode item in items)
                {
                    N = Convert.ToInt32(item["value"].InnerText);
                }

                int one = (N / 10000) % 10;
                int two = (N / 1000) % 10;
                int three = (N / 100) % 10;
                int four = (N / 10) % 10;
                int five = N % 10;

                if (one != two && two != three && three != four && four != five)
                {
                    XDocument xdoc = new XDocument(
                        new XElement("PR19",
                            new XElement("Result", "Все цифры данного числа различны")
                        )
                    );

                    string filePath = "output1.xml";

                    xdoc.Save(filePath);
                }
                else
                {
                    XDocument xdoc = new XDocument(
                        new XElement("PR19",
                            new XElement("Result", "Не все цифры данного числа различны")
                        )
                    );

                    string filePath = "output1.xml";

                    xdoc.Save(filePath);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            // Задание 2
            // Дано количество часов, минут и секунд (1 час = 60 минут, 1 минута = 60 секунд). Вычислить и вывести общее количество секунд.
            try
            {
                XmlDocument doc = new XmlDocument();
                doc.Load("input2.xml");

                XmlNodeList items = doc.GetElementsByTagName("PR19");

                int hours = 0;
                int minutes = 0;
                int seconds = 0;

                foreach (XmlNode item in items)
                {
                    hours = Convert.ToInt32(item["value1"].InnerText);
                    minutes = Convert.ToInt32(item["value2"].InnerText);
                    seconds = Convert.ToInt32(item["value3"].InnerText);
                }

                int conv = hours * 60;
                int conv2 = (minutes + conv) * 60;
                int res = seconds + conv2;

                XDocument xdoc = new XDocument(
                    new XElement("PR19",
                        new XElement("Result", $"{res}")
                    )
                );

                string filePath = "output2.xml";

                xdoc.Save(filePath);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            // Задание 3
            // В вещественном массиве известны данные о количестве осадков, выпавших за каждый день месяца N (N - любой месяц в году).
            // Найти общее число осадков, выпавших по четным числам месяца.
            // Предоставить возможность пользователю реализовать заполнение элементов массива случайными (рандомными) числами.
            try
            {
                XmlDocument doc = new XmlDocument();
                doc.Load("input3.xml");

                XmlNodeList items = doc.GetElementsByTagName("PR19");

                string str = "";
                int days = 0;

                foreach (XmlNode item in items)
                {
                    str = item["value"].InnerText;
                    days = Convert.ToInt32(item["value1"].InnerText);
                }

                string[] chararray = str.Split('_');

                int[] array = new int[chararray.Length];
                for (int i = 0; i < chararray.Length; i++)
                {
                    array[i] += Convert.ToInt32(chararray[i]);
                }

                int res = 0;
                for (int i = 0; i < array.Length; i++)
                {
                    if (array[i] % 2 == 0)
                    {
                        res += array[i];
                    }
                }

                XDocument xdoc = new XDocument(
                    new XElement("PR19",
                        new XElement("Result", $"{res}")
                    )
                );

                string filePath = "output3.xml";

                xdoc.Save(filePath);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            // Задание 4
            // Написать функцию int DigitN(K, N) целого типа, возвращающую N-ю цифру целого положительного числа K (цифры в числе нумеруются справа налево).
            // Если количество цифр в числе K меньше N, то функция должна возвращать значение -1.
            try
            {
                XmlDocument doc = new XmlDocument();
                doc.Load("input4.xml");

                XmlNodeList items = doc.GetElementsByTagName("PR19");

                int K = 0;
                int N = 0;

                foreach (XmlNode item in items)
                {
                    K = Convert.ToInt32(item["value"].InnerText);
                    N = Convert.ToInt32(item["value1"].InnerText);
                }

                int res = DigitN(K, N);

                XDocument xdoc = new XDocument(
                    new XElement("PR19",
                        new XElement("Result", $"{res}")
                    )
                );

                string filePath = "output4.xml";

                xdoc.Save(filePath);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
