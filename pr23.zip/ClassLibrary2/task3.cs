﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary2
{
    public class task3
    {
        public int[] array(int N, int a, int b)
        {
            Random random = new Random();

            int[] array = new int[N];

            for (int i = 0; i < N; i++)
            {
                array[i] = random.Next(50);
            }

            int min = 0;
            int max = 0;

            for (int i = 1; i < N; i++)
            {
                if (array[i] < array[min])
                    min = i;
                if (array[i] > array[max])
                    max = i;
            }

            int start = Math.Min(min, max) + 1;
            int end = Math.Max(min, max) - 1;

            while (start < end)
            {
                int temp = array[start];
                array[start] = array[end];
                array[end] = temp;

                start++;
                end--;
            }

            return array;
        }
    }
}
