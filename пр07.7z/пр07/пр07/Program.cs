﻿using System;
using System.IO;
using System.Linq;
using System.Runtime.Remoting.Contexts;

namespace пр07
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /* Задание 1
            Даны ненулевые числа x, y.
            Проверить истинность высказывания: «Точка с координатами (x, y) лежит во второй координатной четверти».
            */

            string input1 = "input1.txt";
            string output1 = "output1.txt";

            try
            {
                string content1 = File.ReadAllText(input1);

                string[] str1 = content1.Split(new char[] { ' ', ',', '!', '.', '?' }, StringSplitOptions.RemoveEmptyEntries);

                int x = Convert.ToInt32(str1[0]);
                int y = Convert.ToInt32(str1[1]);

                if (x < 0 && y > 0)
                {
                    File.WriteAllLines(output1, new string[] { "Точка с координатами (x, y) лежит во второй координатной четверти." });
                }
                else
                {
                    File.WriteAllLines(output1, new string[] { "Точка с координатами (x, y) лежит в другой координатной четверти." });
                }
            }
            catch (FileNotFoundException ex)
            {

                Console.WriteLine($"Ошибка: файл '{input1}' не найден. {ex}");
            }
            catch (IOException ex)
            {

                Console.WriteLine($"Ошибка ввода-вывода: {ex.Message}");
            }
            catch (Exception ex)
            {

                Console.WriteLine($"Ошибка при обработке файла: {ex.Message}");
            }

            /* Задание 2
            Из пяти целых различных ненулевых положительных и отрицательных чисел найти самое наибольшее число.
            */
            string input2 = "input2.txt";
            string output2 = "output2.txt";

            try
            {
                string content2 = File.ReadAllText(input2);

                string[] str2 = content2.Split(new char[] { ' ', ',', '!', '.', '?' }, StringSplitOptions.RemoveEmptyEntries);

                int[] array2 = new int[str2.Length];

                for (int i = 0; i < str2.Length; i++)
                {
                    array2[i] = Convert.ToInt32(str2[i].ToString());
                }

                int max = array2.Max();

                File.WriteAllLines(output2, new string[] { $"Максимально число = {max}" });
            }
            catch (FileNotFoundException ex)
            {

                Console.WriteLine($"Ошибка: файл '{input2}' не найден. {ex}");
            }
            catch (IOException ex)
            {

                Console.WriteLine($"Ошибка ввода-вывода: {ex.Message}");
            }
            catch (Exception ex)
            {

                Console.WriteLine($"Ошибка при обработке файла: {ex.Message}");
            }

            /* Задание 3
            Дан целочисленный массив, состоящий из N элементов (N > 0).
            Найти сумму и произведение всех нечетных чисел из данного массива.
            */
            string input3 = "input3.txt";
            string output3 = "output3.txt";

            try
            {
                string content3 = File.ReadAllText(input3);

                string[] str3 = content3.Split(new char[] { ' ', ',', '!', '.', '?' }, StringSplitOptions.RemoveEmptyEntries);

                int[] array3 = new int[str3.Length];

                for (int i = 0; i < str3.Length; i++)
                {
                    array3[i] = Convert.ToInt32(str3[i].ToString());
                }

                int sum3 = 0;
                int res2 = 1;

                for (int i = 0; i < array3.Length; i++)
                {
                    if (array3[i] < 0)
                    {
                        sum3 += array3[i];
                        res2 *= array3[i];
                    }
                }

                File.WriteAllLines(output3, new string[] { $"Сумма всех отрицательных чисел = {sum3}", $"Произведение всех отрицательных чисел = {res2}" });
            }
            catch (FileNotFoundException ex)
            {

                Console.WriteLine($"Ошибка: файл '{input3}' не найден. {ex}");
            }
            catch (IOException ex)
            {

                Console.WriteLine($"Ошибка ввода-вывода: {ex.Message}");
            }
            catch (Exception ex)
            {

                Console.WriteLine($"Ошибка при обработке файла: {ex.Message}");
            }


            /* Задание 4
            Вводится строка, состоящая из слов, разделенных подчеркиваниями (одним или несколькими).
            Длина строки может быть разной. Определить и вывести количество слов, начинающихся и заканчивающихся на одну и ту же букву.
            */

            string input4 = "input4.txt";
            string output4 = "output4.txt";

            try
            {
                string content4 = File.ReadAllText(input4);

                string[] str4 = content4.Split(new char[] { '_' }, StringSplitOptions.RemoveEmptyEntries);

                int count = 0;

                foreach (string word in str4)
                {
                    if (char.ToLower(word[0]) == char.ToLower(word[word.Length - 1]))
                    {
                        count++;
                    }
                }

                File.WriteAllLines(output4, new string[] { $"Кол-во слов, начинающихся и заканчивающихся на одну и ту же букву: {count}" });
            }
            catch (FileNotFoundException ex)
            {

                Console.WriteLine($"Ошибка: файл '{input4}' не найден. {ex}");
            }
            catch (IOException ex)
            {

                Console.WriteLine($"Ошибка ввода-вывода: {ex.Message}");
            }
            catch (Exception ex)
            {

                Console.WriteLine($"Ошибка при обработке файла: {ex.Message}");
            }

            /* Задание 5
            Вводится строка, состоящая из слов (разделенных знаком равенства - '='), содержащая, по крайней мере, один символ '='.
            Длина строки может быть разной. Вывести подстроку, расположенную между вторым и третьим знаком '=' исходной строки.
            Если строка содержит менее 3-х символов '=', то вывести всю строку.
            */

            string input5 = "input5.txt";
            string output5 = "output5.txt";

        m5:
            try
            {
                string content5 = File.ReadAllText(input5);
                char[] chararray5 = content5.ToCharArray();
                bool proverka = false;
                int count5 = 0;

                for (int i = 0; i < chararray5.Length; i++)
                {
                    if (chararray5[i] == '=')
                    {
                        proverka = true;
                    }
                }

                if (proverka)
                {
                    for (int i = 0; i < chararray5.Length; i++)
                    {
                        if (chararray5[i] == '=')
                        {
                            count5++;
                        }
                    }
                }

                else
                {
                    File.WriteAllLines(output5, new string[] { "Нету знаков '='." });
                }

                int two = 0;
                int three = 0;

                int count4 = 0;

                for (int i = 0; i < chararray5.Length; i++)
                {
                    if (chararray5[i] == '=')
                    {
                        count4++;
                        if (count4 == 2)
                        {
                            two = i;
                        }
                        else if (count4 == 3)
                        {
                            three = i;
                            break;
                        }
                    }
                }
                if (two != -1 && three != -1)
                {
                    string res = content5.Substring(two + 1, three - two - 1).Trim();
                    File.WriteAllLines(output5, new string[] { $"Подстрока между вторым и третьим '=': {res}" });
                }

                if (count5 < 3)
                {
                    File.WriteAllLines(output5, new string[] { $"Меньше трех '=': {content5}" });
                }
            }
            catch (FileNotFoundException ex)
            {

                Console.WriteLine($"Ошибка: файл '{input5}' не найден. {ex}");
            }
            catch (IOException ex)
            {

                Console.WriteLine($"Ошибка ввода-вывода: {ex.Message}");
            }
            catch (Exception ex)
            {

                Console.WriteLine($"Ошибка при обработке файла: {ex.Message}");
            }
        }
    }
}
