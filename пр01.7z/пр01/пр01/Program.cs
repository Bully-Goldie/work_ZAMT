﻿using System;

namespace пр01
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // задание 03
            Console.WriteLine("Найдем площадь поверхности параллелепипеда!");

            // исходные данные
            Console.Write("Введите длинну: ");
            int a1 = Convert.ToInt32(Console.ReadLine());

            Console.Write("Введите ширину: ");
            int b1 = Convert.ToInt32(Console.ReadLine());

            Console.Write("Введите высоту: ");
            int c1 = Convert.ToInt32(Console.ReadLine());

            // вычисление площади поверхности параллелепипеда
            int Sp = 2 * ((a1 * b1) + (b1 * c1) + (a1 * c1));

            // вывод результата
            Console.WriteLine("Площадь поверхности параллелепипеда = {0} кв.см", Sp);



            // задание 17
            Console.WriteLine("Найдем площадь объем цилиндра!");

            // исходные данные
            Console.Write("Введите радиус основания: ");
            int R = Convert.ToInt32(Console.ReadLine());

            Console.Write("Введите высота цилиндра: ");
            int H = Convert.ToInt32(Console.ReadLine());

            // находим объем цилиндра
            double V = Math.PI * Math.Pow(2, R) * H;

            // вывод результата
            Console.WriteLine("Объем цилиндра = {0} см.куб.", V);



            // задание 10
            Console.WriteLine("Найдем площадь треугольника!");

            //исходные данные
            Console.Write("Введите длину первой стороны треугольника: ");
            int a2 = Convert.ToInt32(Console.ReadLine());

            Console.Write("Введите длину второй стороны треугольника: ");
            int b2 = Convert.ToInt32(Console.ReadLine());

            Console.Write("Введите величину угла между сторонами: ");
            int gradus = Convert.ToInt32(Console.ReadLine());


            // вычисление площади треугольника
            double S = (0.5) * a2 * b2 * Math.Sin(gradus);

            // вывод результата
            Console.WriteLine("Площадь треугольника = {0} кв.см", S);

            Console.ReadKey();
        }
    }
}
