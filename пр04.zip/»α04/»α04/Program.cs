﻿using System;
using System.Linq;

namespace пр04
{
    internal class Program
    {
        static void Main(string[] args)
        {
        #region ЗАДАНИЕ 1
        /* Задание 1
        Проверить истинность высказывания: "Среди трех данных целых положительны чисел введенных с клавиатуры,
        есть хотя бы одна пара совпадающих".
        */
        m1:
            try
            {
                Console.WriteLine("Задание 1");
                Console.Write("Введите введите целое трехзначное число: ");
                int N = Convert.ToInt32(Console.ReadLine());

                if (N > -1)
                {
                    if (N >= 100 && N <= 999)
                    {
                        int sotni = N / 100;
                        int ten = (N / 10) % 10;
                        int one = N % 10;
                        if (sotni == ten || sotni == one || ten == one)
                        {
                            Console.WriteLine("Есть одна пара совподающих.");
                        }
                        else
                        {
                            Console.WriteLine("Нету совподающих чисел.");
                        }
                    }

                    else
                    {
                        Console.WriteLine("Вы введи не трехзначное число. Попробуйте еще раз...");
                        goto m1;
                    }
                }

                else
                {
                    Console.WriteLine("Вы ввели не положительное чилсло. Попробуйте еще раз...");
                    goto m1;
                }
            }

            catch (System.FormatException ex1)
            {
                Console.WriteLine("Ошибка! Вы ввели не число или же оно с плавующей точкой. {0}", ex1.Message.ToString());
                goto m1;
            }

            catch (System.OverflowException ex2)
            {
                Console.WriteLine("Ошибка! Значение недопустимо большое. {0}", ex2.Message.ToString());
                goto m1;
            }
        #endregion

        #region ЗАДАНИЕ 2
        /* Задание 2
        Дан целочисленный массив, состоящий из N элементов (N > 0).
        Обнулить элементы массива, расположенные между его минимальным и максимальным элементами (не включая минимальный и максимальный элементы).
        */
        m2:
            try
            {
                Console.WriteLine("Задание 2");
                Console.Write("Напишите длинну массива: ");
                int N = Convert.ToInt32(Console.ReadLine());

                if (N > 0)
                {
                    Console.Write("Введите 1 или 2 (1 - заполнить массив рандомными числами, 2 - заполнить массив с клавиотуры): ");
                    int A = Convert.ToInt32(Console.ReadLine());

                    int[] array = new int[N];
                    m21:
                    switch (A)
                    {
                        case 1:
                            {
                                Random random = new Random();
                                for (int i = 0; i < array.Length; i++)
                                {
                                    array[i] = random.Next(-50, 50);
                                    Console.Write("{0} ", array[i]);
                                }
                                Console.WriteLine();
                                Console.WriteLine("=========================");
                            }
                            break;

                        case 2:
                            {
                                int i = 0;
                                while (i < N)
                                {
                                    array[i] = Convert.ToInt32(Console.ReadLine());
                                    Console.WriteLine();
                                    i++;
                                }
                            }
                            break;

                        default:
                            Console.WriteLine("Вы введи не 1 и не 2. Попробуйте еще раз...");
                            goto m21;
                    }

                    int max = array.Max();
                    int min = array.Min();

                    for (int i = 0; i < array.Length; i++)
                    {
                        if (array[i] != max && array[i] != min)
                        {
                            array[i] = 0;
                        }
                        Console.Write("{0} ", array[i]);
                    }
                    Console.WriteLine();
                }
            }
            catch (System.FormatException ex1)
            {
                Console.WriteLine("Ошибка! Вы ввели не число или же оно с плавующей точкой. {0}", ex1.Message.ToString());
                goto m2;
            }

            catch (System.OverflowException ex2)
            {
                Console.WriteLine("Ошибка! Значение недопустимо большое. {0}", ex2.Message.ToString());
                goto m2;
            }
            #endregion

        #region ЗАДАНИЕ 3
            /* Задание 3
            Вводится строка, состоящая из слов, разделенных подчеркиваниями (одним или несколькими).
            Длина строки может быть разной. Строка содержит цифры и строчные латинские буквы. Если буквы в строке упорядочены по алфавиту, то вывести 0;
            в противном случае вывести номер первого символа строки, нарушающего алфавитный порядок.
            */
            Console.WriteLine("Задание 3");
            Console.Write("Введите строку, состоящая из латинских слов, разделенных подчеркиваниями (одним или несколькими): ");
            string str = Console.ReadLine();

            string cleanedStr = str.Replace("_", "");

            if (string.IsNullOrEmpty(cleanedStr))
            {
                Console.WriteLine("Строка не содержит слов.");
                return;
            }

            string[] words = str.Split(new char[] { '_' }, StringSplitOptions.RemoveEmptyEntries);

            int wordCount = words.Length;

            bool a = false;
            int count = 1;

            char[] chararray = cleanedStr.ToCharArray();

            for (int i = 1; i < chararray.Length; i++)
            {
                if (chararray[i - 1] == chararray[i] - 1)
                {
                    a = true;
                }
                else
                {
                    a = false;
                    break;
                }
            }

            if (a)
            {
                Console.WriteLine(0);
            }
            else
            {
                Console.WriteLine("Символ строки, нарушающего алфавитный порядок = {0}", count);
            }

            Console.WriteLine("Количество слов: {0}", wordCount);

            #endregion

        #region ЗАДАНИЕ 4
            /* Задание 4
             Вводится строка-предложение на английском языке.
            Длина строки может быть разной. Найти и вывести количество слов, содержащих хотя бы одну цифру.
            */
            Console.WriteLine("Задание 4");
            Console.Write("Ввдети строку-предложение на английском языке: ");
            string str2 = Console.ReadLine();

            string[] chararray2 = str2.Split(new char[] { ' ', '.', ',', '!', '?', ';', ':' }, StringSplitOptions.RemoveEmptyEntries);

            int count1 = 0;

            for (int i = 0; i < chararray2.Length; i++)
            {
                for (int j = 0; j < chararray2[i].Length; j++)
                {
                    if (char.IsDigit(chararray2[i][j]))
                    {
                        count1++;
                        break;
                    }
                }
            }

            Console.WriteLine("Количество слов, содержащих хотя бы одну цифру: {0}", count1);
        #endregion

        #region ЗАДАНИЕ 5
        /* Задание 5
        Вводится строка, состоящая из слов (разделенных знаком равенства - '='), содержащая, по крайней мере, один символ '='.
        Длина строки может быть разной. Вывести подстроку, расположенную между вторым и третьим знаком '=' исходной строки.
        Если строка содержит менее 3-х символов '=', то вывести всю строку.
        */
        m5:
            Console.WriteLine("Задание 5");
            Console.Write("Введите строку состоящую из слов разделительным знаком равенства =: ");
            string str3 = Console.ReadLine();
            bool proverka = false;
            int count3 = 0;

            char[] chararray3 = str3.ToCharArray();

            for (int i = 0; i < chararray3.Length; i++)
            {
                if (chararray3[i] == '=')
                {
                    proverka = true;
                }
            }

            if (proverka)
            {
                for (int i = 0; i < chararray3.Length; i++)
                {
                    if (chararray3[i] == '=')
                    {
                        count3++;
                    }
                }
            }

            else
            {
                Console.WriteLine("Нету знаков '='. Попробуйте еще раз...");
                goto m5;
            }

            int two = 0;
            int three = 0;

            int count4 = 0;

            for (int i = 0; i < chararray3.Length; i++)
            {
                if (chararray3[i] == '=')
                {
                   count4++;
                    if (count4 == 2)
                    {
                        two = i;
                    }
                    else if (count4 == 3)
                    {
                        three = i;
                        break;
                    }
                }
            }
            if (two != -1 && three != -1)
            {
                string res = str3.Substring(two + 1, three - two - 1).Trim();
                Console.WriteLine("Подстрока между вторым и третьим '=': {0}", res);
            }

            if (count3 < 3)
            {
                Console.WriteLine("Меньше трех '=': {0}", str3);
            }
            #endregion
        }
    }
}
