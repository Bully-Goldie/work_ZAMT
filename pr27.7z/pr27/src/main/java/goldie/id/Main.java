package goldie.id;

import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //Даны три целых числа - это коэффициенты A, B, C квадратного уравнения A·x2 + B·x + C = 0 (A не равно 0).
        //Найти корни данного уравнения. Корни вычисляются как вещественные числа.
        //Если имеются два различных корня, то вначале выводить меньший, а затем больший (каждый на новой строке).
        //Если корней нет, то вывести текст «NO».
        try {
            System.out.println("Задание 1");
            Scanner sc = new Scanner(System.in);

            System.out.print("Введите целое число A которое не равно 0: ");
            int A = sc.nextInt();

            System.out.print("Введите целое число B: ");
            int B = sc.nextInt();

            System.out.print("Введите целое число C: ");
            int C = sc.nextInt();

            if(A != 0){
                int D = B * B + 4 * A * C;

                if(D >= 1){
                    double res1 = (-B - D) / 2 * B;
                    double res2 = (-B + D) / 2 * B;

                    double[] arr = {res1, res2};
                    Arrays.sort(arr);

                    System.out.println(Arrays.toString(arr));
                }else if(D == 0){
                    double result = -B / 2 * A;
                    System.out.println("Результат одного корня: "+result);
                }else{
                    System.out.println("NO");
                }
            }
            else{
                System.out.println("Число A равно нулю.");
            }
        }catch (Exception ex){
            System.out.println(ex.getMessage());
        }

        //Дан целочисленный массив, состоящий из N элементов (N > 0).
        //Если в наборе имеются отрицательные нечетные числа, то найти сумму всех положительных четных чисел,
        //иначе вычислить сумму всех чисел, которые кратные числу 5.
        try{
            System.out.println("Задание 2");
            Scanner sc = new Scanner(System.in);

            System.out.print("Введите размер массива: ");
            int N = sc.nextInt();

            if(N > 0){
                int[] array = new int[N];
                boolean proverka = false;
                int result = 0;

                Random random = new Random();

                for(int i = 0; i < N; i++){
                    array[i] = random.nextInt(50);
                }

                for(int i = 0; i < N; i++){
                    if(array[i] < 0 && array[i] % 2 != 0){
                        proverka = true;
                    }
                }

                if(proverka){
                    for(int i = 0; i < N; i++) {
                        if (array[i] > 0 && array[i] % 2 == 0) {
                            result = result + array[i];
                        }
                    }
                    System.out.println("Сумма всех положительных четных чисел = " + result);
                }
                else{
                    for(int i = 0; i < N; i++) {
                        if (array[i] % 5 == 0) {
                            result = result + array[i];
                        }
                    }
                    System.out.println("Сумма всех чисел, которые кратные числу 5 = " + result);
                }
            }else{
                System.out.println("Вы ввели размер массива меньше нуля.");
            }
        }catch (Exception ex){
            System.out.println(ex.getMessage());
        }

        //Дан целочисленный массив, состоящий из N элементов (N > 0).
        //После каждого отрицательного элемента массива вставить элемент с нулевым значением.
        try {
            System.out.println("Задание 3");
            Scanner sc = new Scanner(System.in);

            System.out.print("Введите размер массива: ");
            int N = sc.nextInt();

            if(N > 0) {
                int[] array = new int[N];

                Random random = new Random();

                for (int i = 0; i < N; i++) {
                    array[i] = random.nextInt(-50, 50);
                }
                System.out.println("До: "+Arrays.toString(array));

                int count = 0;
                for (int i = 0; i < N; i++) {
                    if(array[i] < 0){
                        count++;
                    }
                }

                int[] newArr = new int[N+count];
                int index = 0;

                for (int i = 0; i < N; i++){
                    newArr[index++] = array[i];
                    if(array[i] < 0){
                        newArr[index++] = 0;
                    }
                }
                System.out.println("После: "+Arrays.toString(newArr));
            }else{
                System.out.println("Вы ввели размер массива меньше нуля.");
            }

        }catch (Exception ex){
            System.out.println(ex.getMessage());
        }

        //Вводится строка, состоящая из слов, разделенных подчеркиваниями (одним или несколькими).
        //Длина строки может быть разной. Найти и вывести длину самого большого слова и вывести это слово на экран.
        try{
            System.out.println("Задание 4");
            Scanner sc = new Scanner(System.in);

            System.out.print("Введите строку которая состоит из слов разделенных подчеркиваниями: ");
            String str = sc.next();

            String[] strSplit = str.split("_");

            int indexMax = 0;
            for (int i = 0; i < strSplit.length; i++){
                indexMax = strSplit[i].length() > strSplit[indexMax].length() ? i : indexMax;
            }

            char[] arr = new char[strSplit[indexMax].length()];

            System.out.println("Самое длинное слово = "+strSplit[indexMax] + ", длинна = "+arr.length);

        }catch (Exception ex){
            System.out.println(ex.getMessage());
        }

        //Вводится строка, состоящая из слов, разделенных подчеркиваниями (одним или несколькими).
        //Длина строки может быть разной. Определить и вывести количество слов в строке.
        try{
            System.out.println("Задание 5");
            Scanner sc = new Scanner(System.in);

            System.out.print("Введите строку которая состоит из слов разделенных подчеркиваниями: ");
            String str = sc.next();

            String[] splitStr = str.split("_");

            System.out.println("Количество строк в строке = "+splitStr.length);
        }
        catch (Exception ex){
            System.out.println(ex.getMessage());
        }
    }
}