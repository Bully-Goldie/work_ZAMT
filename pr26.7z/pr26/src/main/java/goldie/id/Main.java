package goldie.id;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        //Проверить истинность высказывания: "Квадратное уравнение A·x2 + B·x + C = 0 с данными коэффициентами A (A не равно 0),
        // B, C имеет ровно один вещественный корень".
        System.out.println("Задание 1");

        System.out.print("Введите число A !=0: ");
        int A = sc.nextInt();

        System.out.print("Введите число B: ");
        int B = sc.nextInt();

        System.out.print("Введите число C: ");
        int C = sc.nextInt();

        if(A > 0) {
            int check = B * B - 4 * A * C;

            if(check == 0){
                System.out.println("Корень именнт один корень");
            }else{
                System.out.println("Коронь не имеет один корень.");
            }
        }else{
            System.out.println("Число А не может быть нулевым.");
        }

        //Даны два целых положительных числа: A, B. Проверить истинность высказывания: «Каждое из чисел A и B нечетное».
        System.out.println("Задание 2");

        System.out.print("Введите целое положительное число A: ");
        int A1 = sc.nextInt();

        System.out.print("Введите целое положительное число B: ");
        int B1 = sc.nextInt();

        if(A1 > 0 && B1 > 0) {
            if(A1 % 2 != 0 && B1 % 2 != 0){
                System.out.println("Все числа нечетные");
            }else{
                System.out.println("Не все числа нечетные");
            }
        }else{
            System.out.println("Вы ввели не положительно числа.");
        }

        //Даны два целых положительных числа A и B (A < B).
        // Найти произведение всех нечетных чисел расположенных между этими числами A и B.
        System.out.println("Задание 3");

        System.out.print("Введите целое положительное число A: ");
        int A2 = sc.nextInt();

        System.out.print("Введите целое положительное число B: ");
        int B2 = sc.nextInt();

        if(A2 > 0 && B2 > 0) {
            int result = 1;

            for (int i = A2; i < B2; i++){
                if(i % 2 != 0){
                    result = result * i;
                }
            }
            System.out.println("Произведение всех нечетный чисел: " + result);
        }else{
            System.out.println("Вы ввели не положительные числа.");
        }

        //Задано целое положительное четырехзначное число N (N > 0).
        // Найти разницу между суммой всех его цифр и произведением первой и последней цифры.

        System.out.println("Задание 4");

        System.out.print("Введете целое положительное четырехзначное число: ");
        int N = sc.nextInt();

        if(N > 999 && N <= 9999){
            int one = (N / 1000) % 10;
            int two = (N / 100) % 10;
            int three = (N / 10) % 10;
            int four = N % 10;

            int sum = one + two + three + four;
            int composition = one * four;

            int result = sum - composition;

            System.out.println("Разница = " + result);
        }else{
            System.out.println("Вы ввели не положительное или не четырехзначное число.");
        }

        //Дано целое число N в диапазоне от -900 до 900.
        // Вывести строку-описание данного числа, например: "положительное трехзначное число" или "отрицательное двузначное".

        System.out.println("Задание 5");

        System.out.print("Введите целое число в диапазоне от -900 до 900: ");
        int N2 = sc.nextInt();

        if(N2 >= -900 && N2 <=900){
            String sign = (N2 > 0) ? "положительное" : "отрицательное";

            int absN = Math.abs(N2);
            String digits;

            switch (String.valueOf(absN).length()) {
                case 1:
                    digits = "однозначное";
                    break;
                case 2:
                    digits = "двузначное";
                    break;
                case 3:
                    digits = "трехзначное";
                    break;
                default:
                    digits = "неопределённое";
            }

            System.out.println(sign + " " + digits + " число");
        }else{
            System.out.println("Вы ввели число вне диапозона.");
        }

    }
}