﻿using System;
using System.Net.Mime;
using System.Runtime.InteropServices;
using System.Runtime.Remoting.Contexts;

namespace пр03
{
    internal class Program
    {
        static void Main(string[] args)
        {
        #region ЗАДАНИЕ 1
        // Задание 1
        m1:
            try
            {
                Console.WriteLine("Задание 1");
                Console.Write("Введите введите целое трехзначное число: ");
                int N = Convert.ToInt32(Console.ReadLine());

                if (N > -1)
                {
                    if (N >= 100 && N <= 999)
                    {
                        int sotni = N / 10;
                        int ten = (N / 10) % 10;
                        int one = N % 10;
                        if (sotni != ten && sotni != one && ten != one)
                        {
                            Console.WriteLine("Все цифры различны.");
                        }
                        else
                        {
                            Console.WriteLine("Цифры не различны.");
                        }
                    }

                    else
                    {
                        Console.WriteLine("Вы введи не трехзначное число. Попробуйте еще раз...");
                        goto m1;
                    }
                }

                else
                {
                    Console.WriteLine("Вы ввели не положительное чилсло. Попробуйте еще раз...");
                    goto m1;
                }
            }

            catch (System.FormatException ex1)
            {
                Console.WriteLine("Ошибка! Вы ввели не число или же оно с плавующей точкой. {0}", ex1.Message.ToString());
                goto m1;
            }

            catch (System.OverflowException ex2)
            {
                Console.WriteLine("Ошибка! Значение недопустимо большое. {0}", ex2.Message.ToString());
                goto m1;
            }
        #endregion

        #region ЗАДАНИЕ 2
        // Задание 2
        m2:
            try
            {
                Console.WriteLine("Задание 2");
                Console.Write("Введите четырехзначное положительное число N: ");
                int N = Convert.ToInt32(Console.ReadLine());
                if (N > -1)
                {
                    if (N >= 1000 && N <= 9999)
                    {
                        int tis = N / 1000;
                        int sot = (N / 100) % 10;
                        int ten = (N / 10) % 10;
                        int one = N % 10;

                        int sum = tis * sot;
                        int sum2 = ten * one;

                        Console.WriteLine("Произведение первых двух чисел = {0}", sum);
                        Console.WriteLine("Произведение последних двух чисел = {0}", sum2);
                    }
                    else
                    {
                        Console.WriteLine("Вы введи не четырехзначное число. Попробуйте еще раз...");
                        goto m2;
                    }
                }

                else
                {
                    Console.WriteLine("Вы ввели не положительное чилсло. Попробуйте еще раз...");
                    goto m2;
                }
            }

            catch (System.FormatException ex1)
            {
                Console.WriteLine("Ошибка! Вы ввели не число или же оно с плавующей точкой. {0}", ex1.Message.ToString());
                goto m2;
            }

            catch (System.OverflowException ex2)
            {
                Console.WriteLine("Ошибка! Значение недопустимо большое. {0}", ex2.Message.ToString());
                goto m2;
            }
        #endregion

        #region ЗАДАНИЕ 3
        // Задание 3
        m3:
            try
            {
                Console.WriteLine("Задание 3");
                Console.Write("Введите размер массива он должен быть больше 0: ");
                int N = Convert.ToInt32(Console.ReadLine());
                int res = 0;
                bool proverka = false;
            m31:
                Console.Write("Введите 1 или 2 (1 - заполнить массив рандомными числами, 2 - заполнить массив с клавиотуры): ");
                int A = Convert.ToInt32(Console.ReadLine());


                if (N > 0)
                {
                    int[] array = new int[N];

                    switch (A)
                    {
                        case 1:
                            {
                                Random random = new Random();
                                for (int i = 0; i < array.Length; i++)
                                {
                                    array[i] = random.Next(-50, 50);
                                    Console.Write("{0} ", array[i]);
                                }
                                Console.WriteLine();
                            }
                            break;

                        case 2:
                            {
                                int i = 0;
                                while (i < N)
                                {
                                    array[i] = Convert.ToInt32(Console.ReadLine());
                                    Console.WriteLine();
                                    i++;
                                }
                            }
                            break;

                        default:
                            Console.WriteLine("Вы введи не 1 и не 2. Попробуйте еще раз...");
                            goto m31;
                    }

                    for (int i = 0; i < array.Length; i++)
                    {
                        if (array[i] < 0)
                        {
                            proverka = true;
                            break;
                        }
                    }

                    if (proverka)
                    {

                        for (int i = 0; i < array.Length; i++)
                        {
                            if (array[i] > 0 && array[i] % 2 <= 1)
                            {
                                res += array[i];
                            }
                        }
                        Console.WriteLine("Сумма всех положительных чисел = {0}", res);
                    }

                    else
                    {
                        for (int i = 0; i < array.Length; i++)
                        {
                            if (array[i] % 3 == 0)
                            {
                                res += array[i];
                            }

                        }
                        Console.WriteLine("Сумма всех чисел кратное 3 = {0}", res);
                    }

                }
                else
                {
                    Console.WriteLine("Размер массива не может быть отрицательным! Попробуйте еще раз...");
                    goto m3;
                }

            }
            catch (System.FormatException ex1)
            {
                Console.WriteLine("Ошибка! Вы ввели не число или же оно с плавующей точкой. {0}", ex1.Message.ToString());
                goto m3;
            }

            catch (System.OverflowException ex2)
            {
                Console.WriteLine("Ошибка! Значение недопустимо большое. {0}", ex2.Message.ToString());
                goto m3;
            }
        #endregion

        #region ЗАДАНИЕ 4
        // задание 4
        m4:
            try
            {
                Console.WriteLine("Задание 4");
                Console.Write("Введите размер массива он должен быть больше 0: ");
                int N = Convert.ToInt32(Console.ReadLine());

                Console.Write("Введите целое число K с которого не суммируется: ");
                int K = Convert.ToInt32(Console.ReadLine());

                Console.Write("Введите целое число L до которого не суммируется: ");
                int L = Convert.ToInt32(Console.ReadLine());

            m41:
                Console.Write("Введите 1 или 2 (1 - заполнить массив рандомными числами, 2 - заполнить массив с клавиотуры): ");
                int A = Convert.ToInt32(Console.ReadLine());

                int res = 0;

                if (N > 0 && K >= 1 && L >= K && N >= L)
                {
                    int[] array = new int[N];

                    switch (A)
                    {
                        case 1:
                            {
                                Random random = new Random();
                                for (int i = 0; i < array.Length; i++)
                                {
                                    array[i] = random.Next(-50, 50);
                                    Console.Write("{0} ", array[i]);
                                }
                                Console.WriteLine();
                            }
                            break;

                        case 2:
                            {
                                int i = 0;
                                while (i < N)
                                {
                                    array[i] = Convert.ToInt32(Console.ReadLine());
                                    Console.WriteLine();
                                    i++;
                                }
                            }
                            break;

                        default:
                            Console.WriteLine("Вы введи не 1 и не 2. Попробуйте еще раз...");
                            goto m41;
                    }

                    for (int i = 0; i < array.Length; i++)
                    {
                        if (i < K || i > L)
                        {
                            res += array[i];
                        }
                    }
                    Console.WriteLine("Сумму всех элементов массива, кроме элементов с номерами от K до L включительно = {0}", res);
                }

                else
                {
                    Console.WriteLine("Размер массива не может быть отрицательным или числа L, K не подходят под условие! Попробуйте еще раз...");
                    goto m4;
                }
            }

            catch (System.FormatException ex1)
            {
                Console.WriteLine("Ошибка! Вы ввели не число или же оно с плавующей точкой. {0}", ex1.Message.ToString());
                goto m4;
            }

            catch (System.OverflowException ex2)
            {
                Console.WriteLine("Ошибка! Значение недопустимо большое. {0}", ex2.Message.ToString());
                goto m4;
            }
        #endregion

        #region ЗАДАНИЕ 5
        // Задание 5
        m5:
            try
            {
                Console.WriteLine("Задание 5");
                Console.Write("Введите размер массива он должен быть больше 0 и быть четным: ");
                int N = Convert.ToInt32(Console.ReadLine());

            m51:
                Console.Write("Введите 1 или 2 (1 - заполнить массив рандомными числами, 2 - заполнить массив с клавиотуры): ");
                int A = Convert.ToInt32(Console.ReadLine());

                if (N > 0 && N % 2 == 0)
                {
                    int[] array = new int[N];

                    switch (A)
                    {
                        case 1:
                            {
                                Random random = new Random();
                                for (int i = 0; i < array.Length; i++)
                                {
                                    array[i] = random.Next(-50, 50);
                                    Console.Write("{0} ", array[i]);
                                }
                                Console.WriteLine();
                            }
                            break;

                        case 2:
                            {
                                int i = 0;
                                while (i < N)
                                {
                                    array[i] = Convert.ToInt32(Console.ReadLine());
                                    Console.WriteLine();
                                    i++;
                                }
                            }
                            break;

                        default:
                            Console.WriteLine("Вы введи не 1 и не 2. Попробуйте еще раз...");
                            goto m51;
                    }

                    int one_polovina = N / 2;

                    int[] one = new int[one_polovina];

                    for (int i = 0; i < one_polovina; i++)
                    {
                        one[i] = array[i];
                    }

                    for (int i = 0; i < one_polovina; i++)
                    {
                        array[i] = array[i + one_polovina];
                    }

                    for (int i = 0; i < one_polovina; i++)
                    {
                        array[i + one_polovina] = one[i];
                    }

                    for (int i = 0; i < array.Length; i++)
                    {
                        Console.Write("{0} ", array[i]);
                    }
                    Console.WriteLine();
                }
                else
                {
                    Console.WriteLine("Размер массива отрицательный или не четный! Попробуйте еще раз...");
                    goto m5;
                }
            }

            catch (System.FormatException ex1)
            {
                Console.WriteLine("Ошибка! Вы ввели не число или же оно с плавующей точкой. {0}", ex1.Message.ToString());
                goto m5;
            }

            catch (System.OverflowException ex2)
            {
                Console.WriteLine("Ошибка! Значение недопустимо большое. {0}", ex2.Message.ToString());
                goto m5;
            }
            #endregion
        }
    }
}
