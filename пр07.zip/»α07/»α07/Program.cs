﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection.Emit;
using System.Runtime.InteropServices;
using System.Threading;

namespace пр07
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /* Задание 1
            Даны ненулевые числа x, y.
            Проверить истинность высказывания: «Точка с координатами (x, y) лежит во второй координатной четверти».
            */

            string input1 = "input1.txt";
            string output1 = "output1.txt";

            try
            {
                string content1 = File.ReadAllText(input1);

                string[] str1 = content1.Split(new char[] { ' ', ',', '!', '.', '?' }, StringSplitOptions.RemoveEmptyEntries);

                int x = Convert.ToInt32(str1[0]);
                int y = Convert.ToInt32(str1[1]);

                if (x < 0 && y > 0)
                {
                    File.WriteAllLines(output1, new string[] { "Точка с координатами (x, y) лежит во второй координатной четверти." });
                }
                else
                {
                    File.WriteAllLines(output1, new string[] { "Точка с координатами (x, y) лежит в другой координатной четверти." });
                }
            }
            catch (FileNotFoundException ex)
            {

                Console.WriteLine($"Ошибка: файл '{input1}' не найден. {ex}");
            }
            catch (IOException ex)
            {

                Console.WriteLine($"Ошибка ввода-вывода: {ex.Message}");
            }
            catch (Exception ex)
            {

                Console.WriteLine($"Ошибка при обработке файла: {ex.Message}");
            }

            /* Задание 2
            Из пяти целых различных ненулевых положительных и отрицательных чисел найти самое наибольшее число.
            */
            string input2 = "input2.txt";
            string output2 = "output2.txt";

            try
            {
                string content2 = File.ReadAllText(input2);

                string[] str2 = content2.Split(new char[] { ' ', ',', '!', '.', '?' }, StringSplitOptions.RemoveEmptyEntries);

                int[] array2 = new int[str2.Length];

                for (int i = 0; i < str2.Length; i++)
                {
                    array2[i] = Convert.ToInt32(str2[i].ToString());
                }

                int max = array2.Max();

                File.WriteAllLines(output2, new string[] { $"Максимально число = {max}" });
            }
            catch (FileNotFoundException ex)
            {

                Console.WriteLine($"Ошибка: файл '{input2}' не найден. {ex}");
            }
            catch (IOException ex)
            {

                Console.WriteLine($"Ошибка ввода-вывода: {ex.Message}");
            }
            catch (Exception ex)
            {

                Console.WriteLine($"Ошибка при обработке файла: {ex.Message}");
            }

            /* Задание 3
            Дан целочисленный массив, состоящий из N элементов (N > 0).
            Найти сумму и произведение всех нечетных чисел из данного массива.
            */
            string input3 = "input3.txt";
            string output3 = "output3.txt";

            try
            {
                string content3 = File.ReadAllText(input3);

                string[] str3 = content3.Split(new char[] { ' ', ',', '!', '.', '?' }, StringSplitOptions.RemoveEmptyEntries);

                int[] array3 = new int[str3.Length];

                for (int i = 0; i < str3.Length; i++)
                {
                    array3[i] = Convert.ToInt32(str3[i].ToString());
                }

                int sum3 = 0;
                int res2 = 1;

                for (int i = 0; i < array3.Length; i++)
                {
                    if (array3[i] < 0)
                    {
                        sum3 += array3[i];
                        res2 *= array3[i];
                    }
                }

                File.WriteAllLines(output3, new string[] { $"Сумма всех отрицательных чисел = {sum3}", $"Произведение всех отрицательных чисел = {res2}" });
            }
            catch (FileNotFoundException ex)
            {

                Console.WriteLine($"Ошибка: файл '{input3}' не найден. {ex}");
            }
            catch (IOException ex)
            {

                Console.WriteLine($"Ошибка ввода-вывода: {ex.Message}");
            }
            catch (Exception ex)
            {

                Console.WriteLine($"Ошибка при обработке файла: {ex.Message}");
            }
        }
    }
}
