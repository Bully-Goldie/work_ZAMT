INSERT INTO level (code, number_level) VALUES ('0', 1),('1', 2),('2', 3), ('3', 2), ('4', 1);
INSERT INTO status_job (code, repair_job) VALUES ('0', 'Выполнено'),('1', 'В процессе'),('2', 'Отложено'),('3', 'Не начато'),('4', 'Проблемы');
INSERT INTO brand (code, name) VALUES ('0', 'Volvo'),('1', 'BMW'),('2', 'Mersedes'),('3', 'Lada'),('4', 'Lambarguni');
INSERT INTO type_body (code, description) VALUES ('0', 'Седан'),('1', 'Купе'),('2', 'Хетчбек'),('3', 'Лифтбек'),('4', 'Фастбек');
INSERT INTO model (code, title, brand) VALUES ('0', 'S60', '0'),('1', 'M5 F90', '1'),('2', 'GL-Klasse', '2'),('3', 'Granta', '3'),('4', 'Reventon', '4');
INSERT INTO car_mechanic (table_number,
						  date_of_birth,
						  level,
						  last_name,
						  first_name,
						  third_name) VALUES ('0', '01.02.1990', '0', 'Сергей', 'Иванов', 'Анатольевич'),
						  ('1', '1991-01-03', '1', 'Егор', 'Гусихин', 'Алексннвич'),
						  ('2', '1993-05-02', '2', 'Иван', 'Кичигин', 'Алексннвич'),
						  ('3', '1995-06-07', '3', 'Роман', 'Гусихин', 'Олегович'),
						  ('4', '1996-07-09', '4', 'Олег', 'Карсаков', 'Алексннвич');
INSERT INTO car (number,
				 brand,
				 model,
				 color,
				 type_body,
				 years_extract) VALUES ('0', '0', '0', 'Синий', '0', 1980),
				 ('1', '1', '1', 'Красный', '1', 1978),
				 ('2', '2', '2', 'Оранжевый', '2', 1990),
				 ('3', '3', '3', 'Жёлтый', '3', 1999),
				 ('4', '4', '4', 'Голубой', '4', 2001);
INSERT INTO repair (number,
				   car,
				   date,
				   problem_report,
				   status) VALUES ('0', '0', '2025-03-22', 'Неисправнфе тормаза', '0'),
				   ('1', '1', '2025-04-12', 'Неисправнфе тормаза', '1'),
				   ('2', '2', '2025-03-05', 'Неисправнфе тормаза', '2'),
				   ('3', '3', '2025-02-28', 'Неисправнфе тормаза', '3'),
				   ('4', '4', '2025-04-15', 'Неисправнфе тормаза', '4');
INSERT INTO renovates (car_mechanic, repair) VALUES ('0', '0'), ('1', '1')