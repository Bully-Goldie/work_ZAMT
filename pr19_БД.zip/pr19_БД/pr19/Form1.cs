﻿using MySql.Data.MySqlClient;
using System;
using System.Data;
using System.Windows.Forms;
using Excel = Microsoft.Office.Interop.Excel;
using System.IO;

namespace pr19
{
    public partial class Form1 : Form
    {
        string str = "host=localhost;uid=root;pwd=root;database=pr19_kichigin;";

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            Environment.Exit(0);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            MySqlConnection con = new MySqlConnection(str);
            Excel.Application excelApp = null;

            try
            {
                con.Open();

                excelApp = new Excel.Application();
                excelApp.Visible = true;
                var workBook = excelApp.Workbooks.Add(Type.Missing);
                Excel.Worksheet sheet = (Excel.Worksheet)workBook.ActiveSheet;

                sheet.Name = "worker";

                MySqlCommand cmd = new MySqlCommand("SELECT * FROM worker;", con);
                MySqlDataReader reader = cmd.ExecuteReader();
                for (int j = 0; j < reader.FieldCount; j++)
                {
                    sheet.Cells[1, j + 1] = reader.GetName(j);
                }

                int row = 2;
                while (reader.Read())
                {
                    for (int col = 0; col < reader.FieldCount; col++)
                    {
                        sheet.Cells[row, col + 1] = reader.GetValue(col).ToString();
                    }
                    row++;
                }

                sheet.Columns.AutoFit();

                string savePath = AppDomain.CurrentDomain.BaseDirectory + "workers.xlsx";
                workBook.SaveAs(savePath);

                con.Close();

                MessageBox.Show($"Данные рабочих успешно экспортированы!");
                excelApp.Quit();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка: " + ex.Message);
                if (excelApp != null) excelApp.Quit();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                MySqlConnection con = new MySqlConnection(str);

                con.Open();

                MySqlCommand cmd = new MySqlCommand($@"SELECT * FROM worker;", con);

                MySqlDataReader rdr = cmd.ExecuteReader();

                DataTable dt = new DataTable();
                dt.Load(rdr);

                StreamWriter writer = new StreamWriter("worker.csv", false);

                for (int j = 0, len = dt.Columns.Count - 1; j <= len; ++j)
                {
                    if (j != len)
                        writer.Write(dt.Columns[j].ColumnName + ";");
                    else
                        writer.Write(dt.Columns[j].ColumnName);
                }

                writer.Write("\n");

                int count = dt.Rows.Count;

                foreach (DataRow dataRow in dt.Rows)
                {
                    string r = String.Join(";", dataRow.ItemArray);
                    writer.WriteLine(r);
                }
                writer.Close();

                con.Close();

                MessageBox.Show("Выгружено", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка: " + ex.Message);
            }
        }
    }
}