CREATE DATABASE pr19_kichigin;

USE pr19_kichigin;

CREATE TABLE worker(worker_id INT AUTO_INCREMENT PRIMARY KEY,
					first_name VARCHAR(30) NOT NULL,
                    last_name VARCHAR(30) NOT NULL,
                    middle_name VARCHAR(30),
                    experience INT NOT NULL,
                    phone VARCHAR(20) NOT NULL);
                    
CREATE TABLE client(client_id INT AUTO_INCREMENT PRIMARY KEY,
					first_name VARCHAR(30) NOT NULL,
					last_name VARCHAR(30) NOT NULL,
                    middle_name VARCHAR(30),
                    phone VARCHAR(20) NOT NULL,
                    email VARCHAR(100));
                    
CREATE TABLE car(car_id INT AUTO_INCREMENT PRIMARY KEY,
				worker_id INT NOT NULL,
                client_id INT NOT NULL,
				name VARCHAR(30) NOT NULL,
                take_date DATE NOT NULL,
                return_date DATE NOT NULL,
                FOREIGN KEY (worker_id) REFERENCES worker(worker_id),
                FOREIGN KEY (client_id) REFERENCES client(client_id));
                
INSERT INTO worker (first_name, last_name, middle_name, experience, phone) VALUES
('Александр', 'Иванов', 'Сергеевич', 5, '+79001112233'),
('Дмитрий', 'Петров', 'Алексеевич', 3, '+79002223344'),
('Елена', 'Сидорова', 'Владимировна', 7, '+79003334455'),
('Максим', 'Кузнецов', 'Николаевич', 2, '+79004445566'),
('Ольга', 'Васильева', 'Игоревна', 10, '+79005556677'),
('Артем', 'Смирнов', 'Михайлович', 4, '+79006667788'),
('Ирина', 'Попова', 'Андреевна', 6, '+79007778899'),
('Никита', 'Соколов', 'Викторович', 1, '+79008889900'),
('Татьяна', 'Морозова', 'Павловна', 8, '+79009990011'),
('Андрей', 'Новиков', 'Денисович', 12, '+79000001122');

INSERT INTO client (first_name, last_name, middle_name, phone, email) VALUES
('Игорь', 'Белов', 'Юрьевич', '+79111234567', 'belov@mail.ru'),
('Марина', 'Тихонова', 'Олеговна', '+79222345678', 'marina_t@gmail.com'),
('Сергей', 'Волков', 'Артемович', '+79333456789', 'volkov_s@yandex.ru'),
('Анна', 'Зайцева', 'Витальевна', '+79444567890', 'zaytseva@bk.ru'),
('Виктор', 'козлов', 'Евгеньевич', '+79555678901', 'v_kozlov@inbox.ru'),
('Наталья', 'Павлова', 'Сергеевна', '+79666789012', 'nat_p@gmail.com'),
('Денис', 'Медведев', 'Романович', '+79777890123', 'den_med@mail.ru'),
('Юлия', 'Семенова', 'Ильинична', '+79888901234', 'yulia_sem@yandex.ru'),
('Роман', 'Фролов', 'Александрович', '+79999012345', 'frolov_r@outlook.com'),
('Оксана', 'Борисова', 'Игоревна', '+79000123456', 'borisova_o@mail.ru');

INSERT INTO car (worker_id, client_id, name, take_date, return_date) VALUES
(1, 1, 'Toyota Camry', '2026-01-10', '2026-01-15'),
(2, 2, 'Hyundai Solaris', '2026-01-12', '2026-01-14'),
(3, 3, 'Kia Rio', '2026-01-15', '2026-01-20'),
(4, 4, 'BMW X5', '2026-01-18', '2026-01-25'),
(5, 5, 'Mercedes-Benz E-Class', '2026-01-20', '2026-01-22'),
(6, 6, 'Volkswagen Polo', '2026-02-01', '2026-02-05'),
(7, 7, 'Audi A4', '2026-02-03', '2026-02-10'),
(8, 8, 'Skoda Octavia', '2026-02-05', '2026-02-07'),
(9, 9, 'Lada Vesta', '2026-02-10', '2026-02-12'),
(10, 10, 'Mazda CX-5', '2026-02-15', '2026-02-20');