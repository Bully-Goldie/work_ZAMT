#!/bin/bash

echo "************ Задание 1 *********************"
echo

declare -a my_array=( "Меню скрипта:" "Информация об интерфейсах" "Настройка интерфейса" "Пинговать" "Quit" )

# все атрибуты по умолчанию
NORMAL='\033[0m'

# Цвет фона и текста
main='\033[1m'
yellow='\033[1;42;36m'
blue='\033[1;44;33m'
cyan='\033[1;47;31m'
green='\033[1;32m'

echo -e "\t${main}${my_array}"
echo -e "${yellow}${my_array[1]}${NORMAL}"
echo -e "${blue}${my_array[2]}${NORMAL}"
echo -e "${cyan}${my_array[3]}${NORMAL}"
echo -e "${green}${my_array[4]}${NORMAL}"

echo
echo "************ Задание 2 *********************"
echo

red='\033[31m'
yellow2='\033[33m'
gray='\033[37m'

declare -A arr=(
    [remove]="Я догадываюсь, что ты догадываешься, что я догадываюсь, что ты догадываешься, что я догадываюсь"
    [slice]="Я знаю, что я знаю, что я знаю, что я знаю, что я знаю"
    [symbol]="Мастер и Маргарита, Михаил Булгаков"
)

echo -e "${red}${arr[remove]//что }${NORMAL}"
echo -e "${yellow2}${arr[slice]:8:-11}${NORMAL}"
echo -e "${gray}${arr[symbol]^^:18:0}${NORMAL}"

echo
echo "************ Задание 3 *********************"
echo

declare -a array

array+=(file{0..9}.log)

echo ${array[@]}

unset  array[{5..9}]
echo "${array[@]}"

array=("${array[@]//.log/.gz}")
array=("${array[@]^}")

echo "${array[@]}"