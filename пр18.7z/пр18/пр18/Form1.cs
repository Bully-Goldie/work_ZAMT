﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace пр18
{
    public partial class Form1 : Form
    {
        public int InvDigits(int K)
        {
            int polovina = 0;
            for (int i = 0; i < K; i++)
            {
                int last = K % 10;
                polovina = polovina * 10 + last;
                K /= 10;
            }
            return polovina;
        }
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                int A = Convert.ToInt32(textBox1.Text);
                int B = Convert.ToInt32(textBox2.Text);
                int C = Convert.ToInt32(textBox3.Text);

                int D = (B*B)-(4 * A * C);

                if (D > 0)
                {
                    label5.Text = "Квадратное уравнение имеет 2 корня";
                }
                else
                {
                    label5.Text = "Квадратное уравнение не имеет 2 корня";
                }
            }
            catch (Exception ex)
            {
                label5.Text = ex.Message;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                int N = Convert.ToInt32(textBox4.Text);

                int res = 1;
                for (int i = 1; i <= N; i++)
                {
                    res *= i;
                }

                label9.Text = res.ToString();
            }
            catch (Exception ex)
            {
                label9.Text = ex.Message;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                int K = Convert.ToInt32(textBox5.Text);

                int res = InvDigits(K);

                label12.Text = res.ToString();
            }
            catch (Exception ex)
            {
                label12.Text = ex.Message;
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                int N = Convert.ToInt32(textBox6.Text);

                if (N > 0 && N <= 31)
                {
                    int[] array = new int[N];
                    Random random = new Random();

                    for (int i = 0; i < array.Length; i++)
                    {
                        array[i] += random.Next(50);
                    }

                    double res = 0;

                    for (int i = 0; i < N; i++)
                    {
                        if ((i + 1) % 2 != 0)
                        {
                            res += array[i];
                        }
                    }
                    label16.Text = res.ToString();
                }
                else
                {
                    label16.Text = "Вы ввели не корректное число дней. Попробуйте еще раз...";
                }

            }
            catch (Exception ex)
            {
                label16.Text = ex.Message;
            }
        }
    }
}
