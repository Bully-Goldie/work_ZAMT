﻿using System;

namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // задание 10

            //исходные данные
            Console.Write("Введите длину первой стороны треугольника: ");
            int a = Convert.ToInt32(Console.ReadLine());

            Console.Write("Введите длину второй стороны треугольника: ");
            int b = Convert.ToInt32(Console.ReadLine());

            Console.Write("Введите величину угла между сторонами: ");
            int gradus = Convert.ToInt32(Console.ReadLine());


            // вычисление площади треугольника
            double S = (1/2) * a * b * Math.Sin(gradus);

            // вывод результата
            Console.WriteLine("Площадь треугольника = {0} кв.см", S);
        }
    }
}
