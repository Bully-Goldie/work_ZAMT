﻿using System;

namespace пр01
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // задание 03

            // исходные данные
            Console.Write("Введите длинну: ");
            int a = Convert.ToInt32(Console.ReadLine());

            Console.Write("Введите ширину: ");
            int b = Convert.ToInt32(Console.ReadLine());

            Console.Write("Введите высоту: ");
            int c = Convert.ToInt32(Console.ReadLine());

            // вычисление площади поверхности параллелепипеда
            int Sp = 2 * ((a * b) + (b * c) + (a * c));

            // вывод результата
            Console.WriteLine("Площадь поверхности параллелепипеда = {0} кв.см", Sp);
        }
    }
}
