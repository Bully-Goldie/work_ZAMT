﻿using System;

namespace ConsoleApp2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // задание 17

            // исходные данные
            Console.Write("Введите радиус основания");
            int R = Convert.ToInt32(Console.ReadLine());

            Console.Write("Введите высота цилиндра");
            int H = Convert.ToInt32(Console.ReadLine());

            // находим объем цилиндра
            double V = Math.PI * Math.Pow(2, R) * H;

            // вывод результата
            Console.WriteLine("Объем цилиндра = {0} см.куб.", V);
        }
    }
}
