﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace pr25
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public double TriangleS(int a)
        {
            return a * a * (Math.Pow(a, 0.5)) / 4;
        }
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btn1_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int N = Convert.ToInt32(tb1.Text);

                if (N > 999 && N <= 9999)
                {
                    int one = (N / 1000) % 10;
                    int two = (N / 100) % 10;
                    int three = (N / 10) % 10;
                    int four = N % 10;

                    if(one != two && one != three && one != four && two != three && three != four)
                    {
                        otvet1.Content = true;
                    }
                    else
                    {
                        otvet1.Content = false;
                    }
                }
                else
                {
                    otvet1.Content = "Вы ввели не четырехзначное число.";
                }
            }
            catch (Exception ex)
            {
                otvet1.Content = ex.Message.ToString();
            }
        }

        private void btn2_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int a = Convert.ToInt32(tb2_1.Text);
                int b = Convert.ToInt32(tb2_2.Text);
                int c = Convert.ToInt32(tb2_3.Text);
                int d = Convert.ToInt32(tb2_4.Text);
                int q = Convert.ToInt32(tb2_5.Text);

                if (a > 0 && b > 0 && c > 0 && d > 0 && q > 0)
                {
                    int[] array = { a, b, c, d, q };

                    Array.Sort(array);

                    otvet2.Content = array[3] * array[4];
                }
                else
                {
                    otvet2.Content = "Вы написали число меньше 0.";
                }
            }
            catch (Exception ex)
            {
                otvet2.Content = ex.Message.ToString();
            }
        }

        private void btn3_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int N = Convert.ToInt32(tb3.Text);

                int[] array = new int[N];
                bool proverka = false;
                int res = 0;

                Random random = new Random();

                for (int i = 0; i < N; i++)
                {
                    array[i] = random.Next(-50, 50);
                }

                for (int i = 0; i < N; i++)
                {
                    if (array[i] % 2 != 0 && array[i] < 0)
                    {
                        proverka = true;
                        break;
                    }
                    else
                    {
                        if(array[i] % 5 == 0)
                        {
                            res += array[i];
                        }
                    }
                }

                if (proverka)
                {
                    for (int i = 0; i < N; i++)
                    {
                        if (array[i] % 2 != 0 && array[i] > 0)
                        {
                            res += array[i];
                        }
                    }
                }
                otvet3.Content = res;
            }
            catch(Exception ex)
            {
                otvet3.Content = ex.Message.ToString();
            }
        }

        private void btn4_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int a = Convert.ToInt32(tb4.Text);

                otvet4.Content = TriangleS(a);
            }
            catch (Exception ex)
            {
                otvet4.Content = ex.Message.ToString();
            }
        }
    }
}
