﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Word = Microsoft.Office.Interop.Word;

namespace pr21
{
    public partial class Form1 : Form
    {
        public bool IsSquare(int K5)
        {
            Math.Sqrt(K5);
            if (K5 % 1 == 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                //Задание 1
                int N = Convert.ToInt32(textBox1.Text);
                bool result = false;

                if (N >= 1000 && N<=9999)
                {
                    int n1 = (N / 1000) % 10;
                    int n2 = (N / 100) % 10;
                    int n3 = (N / 10) % 10;
                    int n4 = N % 10;

                    if (n1 != n2 && n2!=n3 && n3 != n4 && n1 != n3 && n1 != n4)
                    {
                        result = true;
                    }
                    else
                    {
                        result = false;
                    }
                }
                    //Задание 2
                    int N2 = Convert.ToInt32(textBox2.Text);
                int result2 = 0;

                if (N2 > 0)
                {
                    result2 = N2 * 7;
                }

                //Задание 3
                int arr = Convert.ToInt32(textBox6.Text);
                int N3 = Convert.ToInt32(textBox3.Text);
                bool result3 = false;

                Random random = new Random();
                int[] array = new int[arr];
                int chot = 0;
                int nechot = 0;

                for (int i = 0; i < array.Length; i++)
                {
                    array[i] = random.Next(50);

                    if (array[i] % 2 == 0)
                    {
                        chot += array[i];
                    }
                    else
                    {
                        nechot += array[i];
                    }
                }
                if (chot > nechot)
                {
                    result3 = true;
                }
                else
                {
                    result3 = false;
                }

                //Задание 4
                int N4 = Convert.ToInt32(textBox4.Text);
                int K = Convert.ToInt32(textBox7.Text) - 1;
                int L = Convert.ToInt32(textBox8.Text) - 1;

                int[] array4 = new int[N4];
                int res4 = 0;
                int kolvo = 0;

                for (int i = 0; i < array4.Length; i++)
                {
                    array4[i] = random.Next(50);
                }
                for (int i = K; i <= L; i++)
                {
                    res4 += array4[i];
                    kolvo++;
                }
                int result4 = res4 / kolvo;

                //Задание 5
                int K5 = Convert.ToInt32(textBox5.Text);

                bool result5 = IsSquare(K5);

                //создаем новый документ Word
                Word.Application wdApp = new Word.Application();
                Word.Document wdDoc = null;
                Object wdMiss = System.Reflection.Missing.Value;

                wdDoc = wdApp.Documents.Add(ref wdMiss, ref wdMiss, ref wdMiss, ref wdMiss);

                wdDoc.PageSetup.Orientation = Word.WdOrientation.wdOrientPortrait;

                wdDoc.PageSetup.TopMargin = wdApp.InchesToPoints(0.60f);
                wdDoc.PageSetup.BottomMargin = wdApp.InchesToPoints(0.60f);
                wdDoc.PageSetup.LeftMargin = wdApp.InchesToPoints(0.80f);
                wdDoc.PageSetup.RightMargin = wdApp.InchesToPoints(0.59f);

                wdApp.Visible = true;

                wdApp.ActiveWindow.Selection.ParagraphFormat.LineSpacingRule = Word.WdLineSpacing.wdLineSpaceSingle;
                wdApp.ActiveWindow.Selection.ParagraphFormat.SpaceAfter = 0.0F;

                Word.Paragraph oPara7;
                oPara7 = wdDoc.Content.Paragraphs.Add(ref wdMiss);
                oPara7.Range.Text = "МДК.01.01 Разработка программных модулей";
                oPara7.Alignment = Word.WdParagraphAlignment.wdAlignParagraphCenter;
                oPara7.Range.Font.Size = Convert.ToInt32(18);
                oPara7.Range.Font.Bold = 1;
                oPara7.Range.InsertParagraphAfter();
                oPara7.CloseUp();

                Word.Paragraph oPara8;
                oPara8 = wdDoc.Content.Paragraphs.Add(ref wdMiss);
                oPara8.Range.Text = "ПР21 «Программное создание документов MS Word в языке С#»\r\nВыполнил Кичигин И.А., студент группы ИС-23Б\r\n";
                oPara8.Alignment = Word.WdParagraphAlignment.wdAlignParagraphJustify;
                oPara8.Range.Font.Size = Convert.ToInt32(16);
                oPara8.Range.Font.Bold = 0;
                wdApp.ActiveWindow.Selection.ParagraphFormat.LineSpacingRule = Word.WdLineSpacing.wdLineSpaceSingle;
                wdApp.ActiveWindow.Selection.ParagraphFormat.SpaceAfter = 0.0F;
                oPara8.Range.InsertParagraphAfter();
                oPara8.CloseUp();

                Word.Paragraph oPara1;
                oPara1 = wdDoc.Content.Paragraphs.Add(ref wdMiss);
                oPara1.Range.Text = string.Format("\r\nЗадание 1:\r\nначальное число 1: {0}\r\nрезультат: {1}\r\n", N, result);
                oPara1.Alignment = Word.WdParagraphAlignment.wdAlignParagraphJustify;
                oPara1.Range.Font.Size = Convert.ToInt32(16);
                oPara1.Range.Font.Bold = 0;
                wdApp.ActiveWindow.Selection.ParagraphFormat.LineSpacingRule = Word.WdLineSpacing.wdLineSpaceSingle;
                wdApp.ActiveWindow.Selection.ParagraphFormat.SpaceAfter = 0.0F;
                oPara1.Range.InsertParagraphAfter();
                oPara1.CloseUp();

                Word.Paragraph oPara2;
                oPara2 = wdDoc.Content.Paragraphs.Add(ref wdMiss);
                oPara2.Range.Text = string.Format("Задание 2:\r\nначальное число 1: {0}\r\nрезультат: {1}\r\n", N2, result2);
                oPara2.Alignment = Word.WdParagraphAlignment.wdAlignParagraphJustify;
                oPara2.Range.Font.Size = Convert.ToInt32(16);
                oPara2.Range.Font.Bold = 0;
                wdApp.ActiveWindow.Selection.ParagraphFormat.LineSpacingRule = Word.WdLineSpacing.wdLineSpaceSingle;
                wdApp.ActiveWindow.Selection.ParagraphFormat.SpaceAfter = 0.0F;
                oPara2.Range.InsertParagraphAfter();
                oPara2.CloseUp();

                Word.Paragraph oPara3;
                oPara3 = wdDoc.Content.Paragraphs.Add(ref wdMiss);
                oPara3.Range.Text = string.Format("Задание 3:\r\nначальное число 1: {0}\r\nрезультат: {1}\r\n", N3, result3);
                oPara3.Alignment = Word.WdParagraphAlignment.wdAlignParagraphJustify;
                oPara3.Range.Font.Size = Convert.ToInt32(16);
                oPara3.Range.Font.Bold = 0;
                wdApp.ActiveWindow.Selection.ParagraphFormat.LineSpacingRule = Word.WdLineSpacing.wdLineSpaceSingle;
                wdApp.ActiveWindow.Selection.ParagraphFormat.SpaceAfter = 0.0F;
                oPara3.Range.InsertParagraphAfter();
                oPara3.CloseUp();

                Word.Paragraph oPara4;
                oPara4 = wdDoc.Content.Paragraphs.Add(ref wdMiss);
                oPara4.Range.Text = string.Format("Задание 4:\r\nначальное число 1: {0}\r\nначальное число 2: {1}\r\nрезультат: {2}\r\n", K, L, result4);
                oPara4.Alignment = Word.WdParagraphAlignment.wdAlignParagraphJustify;
                oPara4.Range.Font.Size = Convert.ToInt32(16);
                oPara4.Range.Font.Bold = 0;
                wdApp.ActiveWindow.Selection.ParagraphFormat.LineSpacingRule = Word.WdLineSpacing.wdLineSpaceSingle;
                wdApp.ActiveWindow.Selection.ParagraphFormat.SpaceAfter = 0.0F;
                oPara4.Range.InsertParagraphAfter();
                oPara4.CloseUp();

                Word.Paragraph oPara5;
                oPara5 = wdDoc.Content.Paragraphs.Add(ref wdMiss);
                oPara5.Range.Text = string.Format("Задание 5:\r\nначальное число 1: {0}\r\nрезультат: {1}\r\n", K5, result5);
                oPara5.Alignment = Word.WdParagraphAlignment.wdAlignParagraphJustify;
                oPara5.Range.Font.Size = Convert.ToInt32(16);
                oPara5.Range.Font.Bold = 0;
                wdApp.ActiveWindow.Selection.ParagraphFormat.LineSpacingRule = Word.WdLineSpacing.wdLineSpaceSingle;
                wdApp.ActiveWindow.Selection.ParagraphFormat.SpaceAfter = 0.0F;
                oPara5.Range.InsertParagraphAfter();
                oPara5.CloseUp();

                try
                {
                    object filename = @"pr21" + ".doc";

                    wdDoc.SaveAs(ref filename);

                    wdDoc.Close(ref wdMiss, ref wdMiss, ref wdMiss);
                    wdDoc = null;

                    wdApp.Quit(ref wdMiss, ref wdMiss, ref wdMiss);
                    wdDoc = null;
                }
                catch (Exception y)
                {
                    Console.WriteLine("Ошибка сохранения документа", y.ToString());
                }
                label11.Text = "";
            }
            catch (Exception ex)
            {
                label11.Text = ex.Message;
                
            }
        }
    }
}
