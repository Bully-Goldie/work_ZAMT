﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Win32;

namespace пр17
{
    internal class Program
    {
        static double Factorial(int N)
        {
            int res = 1;
            for (int i = 1; i <= N; i++)
            {
                res *= i;
            }
            return res;
        }

        static void Main(string[] args)
        {
            RegistryKey myKey = Registry.CurrentUser;
            myKey.CreateSubKey("ПР17");
            // Задание 1
            // Даны три целых числа: A, B, C. Проверить истинность высказывания: «Хотя бы одно из чисел A, B, C положительное».
            m1:
            try
            {
                Console.WriteLine("Задание 1");
                Console.Write("Введите целое число A: ");
                int A = Convert.ToInt32(Console.ReadLine());

                Console.Write("Введите целое число B: ");
                int B = Convert.ToInt32(Console.ReadLine());

                Console.Write("Введите целое число C: ");
                int C = Convert.ToInt32(Console.ReadLine());

                RegistryKey wKey = myKey.OpenSubKey("ПР17", true);
                RegistryKey newKey = wKey.CreateSubKey("Task01");

                newKey.SetValue("A", A);
                newKey.SetValue("B", B);
                newKey.SetValue("C", C);

                if (A > 0 || B > 0 || C > 0)
                {
                    newKey.SetValue("Result1", "Одно из чисел положительное");
                }
                else
                {
                    newKey.SetValue("Result1", "Нет положительных чисел");
                }

                wKey.Close();
                newKey.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                goto m1;
            }

        // Задание 2
        // С некоторого момента прошло N недель (N > 0). Сколько полных дней прошло за этот период?
        m2:
            try
            {
                Console.WriteLine("Задание 2");
                Console.Write("Введите целое положительно число N: ");
                int N = Convert.ToInt32(Console.ReadLine());

                if (N > 0)
                {
                    RegistryKey wKey = myKey.OpenSubKey("ПР17", true);
                    RegistryKey newKey = wKey.CreateSubKey("Task02");

                    newKey.SetValue("N", N);

                    int res = N * 7;

                    newKey.SetValue("Result2", res);

                    wKey.Close();
                    newKey.Close();
                }
                else
                {
                    Console.WriteLine("Вы ввели число меньше нуля. Попробуйте еще раз...");
                    goto m2;
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                goto m2;
            }

        // Задание 3
        // Дан целочисленный массив, состоящий из N элементов (N > 0).
        // Проверить, чередуются ли в нем четные и нечетные числа.
        // Если чередуются, то вывести 0, если нет, то вывести порядковый номер первого элемента, нарушающего закономерность.
        m3:
            try
            {
                Console.WriteLine("Задание 3");
                Console.Write("Введите длину массива: ");
                int N = Convert.ToInt32(Console.ReadLine());

                if (N > 0)
                {
                    Console.Write("Введите 1 или 2 (1 - заполнить массив рандомными числами, 2 - заполнить массив с клавиатуры): ");
                    int A = Convert.ToInt32(Console.ReadLine());

                    int[] array = new int[N];
                m21:
                    switch (A)
                    {
                        case 1:
                            {
                                Random random = new Random();
                                for (int i = 0; i < array.Length; i++)
                                {
                                    array[i] = random.Next(-50, 50);
                                }
                            }
                            break;

                        case 2:
                            {
                                int i = 0;
                                while (i < N)
                                {
                                    array[i] = Convert.ToInt32(Console.ReadLine());
                                    i++;
                                }
                            }
                            break;

                        default:
                            Console.WriteLine("Вы введи не 1 и не 2. Попробуйте еще раз...");
                            goto m21;
                    }

                    RegistryKey wKey = myKey.OpenSubKey("ПР17", true);
                    RegistryKey newKey = wKey.CreateSubKey("Task03");

                    for (int i = 0; i < N; i++)
                    {
                        newKey.SetValue($"Array_{i + 1}", array[i]);
                    }

                    for (int i = 1; i < array.Length; i++)
                    {
                        bool chetnoe = array[i] % 2 == 0;
                        bool nechetnote = array[i - 1] % 2 == 0;

                        if (chetnoe == nechetnote)
                        {
                            newKey.SetValue("Result3", i + 1);
                        }
                        else
                        {
                            newKey.SetValue("Result3", 0);
                        }
                    }

                    wKey.Close();
                    newKey.Close();
                }
                else
                {
                    Console.WriteLine("Вы ввели число меньше нуля. Попробуйте еще раз...");
                    goto m3;
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                goto m3;
            }

        // Задание 4
        // Написать функцию double Factorial(N) вещественного типа, вычисляющую значение факториала N! = 1*2*…*N
        // (N > 0 — параметр целого типа; вещественное возвращаемое значение используется для того,
        // чтобы избежать целочисленного переполнения при больших значениях N).
        m4:
            try
            {
                Console.WriteLine("Задание 4");
                Console.Write("Введите целое положительно число N: ");
                int N = Convert.ToInt32(Console.ReadLine());

                if (N > 0)
                {
                    RegistryKey wKey = myKey.OpenSubKey("ПР17", true);
                    RegistryKey newKey = wKey.CreateSubKey("Task04");

                    newKey.SetValue("N", N);

                    double res = Factorial(N);

                    newKey.SetValue("Result4", res);

                    wKey.Close();
                    newKey.Close();
                }
                else
                {
                    Console.WriteLine("Вы ввели число меньше нуля. Попробуйте еще раз...");
                    goto m4;
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                goto m4;
            }

        // Задание 5
        // Вводится строка. Длина строки может быть разной. Подсчитать количество содержащихся в ней строчных букв латинского алфавита.
            Console.WriteLine("Задание 5");
            Console.WriteLine("Введи строку: ");
            string str = Console.ReadLine();
            int count = 0;

            char[] chararray = str.ToCharArray();

            for (int i = 0; i < chararray.Length; i++)
            {
                if (char.IsLower(chararray[i]))
                {
                    count++;
                }
            }

            RegistryKey wKey1 = myKey.OpenSubKey("ПР17", true);
            RegistryKey newKey1 = wKey1.CreateSubKey("Task05");

            newKey1.SetValue("Str", str);

            newKey1.SetValue("Result5", count);

            wKey1.Close();
            newKey1.Close();
        }
    }
}
