﻿using System;

namespace пр02
{
    class Program
    {
        static void Main(string[] args)
        {
            // задание 1
            M1:
            try
            {
                Console.Write("Введите челое положительное число A: ");
                int A = Convert.ToInt32(Console.ReadLine());

                Console.Write("Введите челое положительное число B: ");
                int B = Convert.ToInt32(Console.ReadLine());

                if (A % 2 == 0 && B % 2 == 0)
                {
                    Console.WriteLine("Все числа четные");
                }
                else if (A % 2 == 0 || B % 2 == 0)
                {
                    Console.WriteLine("Одно из числа четное");
                }
                else
                {
                    Console.WriteLine("Все числа не четные");
                }

            }
            catch (System.FormatException ex1)
            {
                Console.WriteLine("Ошибка! Вы ввели не число {0}", ex1.Message.ToString());
                goto M1;
            }
            catch (System.OverflowException ex2)
            {
                Console.WriteLine("Значение недопустимо большим {0}", ex2.Message.ToString());
                goto M1;
            }
            // задание 2
            try
            {
                Console.Write("Введите челое положительное число A: ");
                int A = Convert.ToInt32(Console.ReadLine());

                Console.Write("Введите челое положительное число B: ");
                int B = Convert.ToInt32(Console.ReadLine());

                for (int i = 0; A > B; i++)
                {
                }
            }
            catch (System.FormatException ex1)
            {
            }
        }
    }
}
