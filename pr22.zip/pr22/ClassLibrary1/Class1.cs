﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace kichigin
{
    public class Class1
    {
        public static bool zadanie1(int A, int B)
        {
            if (A % 2 != 0 && B % 2 == 0)
            {
                return true;
            }
            else if (A % 2 == 0 && B % 2 != 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public static int zadanie2(int N)
        {
            int one = (N / 10000) % 10;
            int two = (N / 1000) % 10;
            int three = (N / 100) % 10;
            int four = (N / 10) % 10;
            int five = N % 10;

            return one+ two + three + four + five;
        }

        public static int[] zadanie3(int[] array)
        {
            int maxEven = int.MinValue;

            int[] array2 = new int[array.Length];
            for (int i = 0; i < array.Length; i++)
            {
                if (array[i] % 2 == 0 && array[i] > maxEven)
                {
                    maxEven = array[i];
                }
            }

            for (int i = 0; i < array.Length; i++)
            {
                if (array[i] % 2 != 0)
                {
                    array2[i] = array[i] + maxEven;
                }
                else
                {
                    array2[i] = array[i];
                }
            }

            return array2;
        }

        public static int Calc(int A, int B, int Op)
        {
            switch (Op)
            {
                case 1:
                    return A - B;
                case 2: 
                    return A * B;
                case 3:
                    return A / B;
                case 4:
                    return A + B;
                default:
                    return 0;
            }
        }
    }
}
