﻿using kichigin;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using kichigin;

namespace pr22
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                int A = Convert.ToInt32(textBox1.Text);
                int B = Convert.ToInt32(textBox2.Text);

                if (A > 0 && B > 0)
                {
                    bool result = kichigin.Class1.zadanie1(A, B);
                    label4.Text = result.ToString();
                }
                else
                {
                    label4.Text = "Вы ввели не положительные числа";
                }
            }
            catch (Exception ex)
            {
                label4.Text = ex.Message;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                int N = Convert.ToInt32(textBox3.Text);
                if(N > 9999 && N <= 99999)
                {
                    int result = kichigin.Class1.zadanie2(N);
                    label7.Text = "Ответ: " + result.ToString();
                }
                else
                {
                    label7.Text = "Вы ввели не положительное или не пятизначное число";
                }
            }
            catch (Exception ex)
            {
                label7.Text = ex.Message;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                int N = Convert.ToInt32(textBox4.Text);

                if (N > 0)
                {
                    int[] array = new int[N];

                    Random random = new Random();

                    for (int i = 0; i < N; i++)
                    {
                        array[i] = random.Next(50);
                    }

                    int[] result = kichigin.Class1.zadanie3(array);

                    label10.Text = String.Join(" ", result);
                }
                else
                {
                    label10.Text = "Вы ввели массив меньше 0";
                }
            }
            catch (Exception ex)
            {
                label10.Text = ex.Message;
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                int A = Convert.ToInt32(textBox5.Text);
                int B = Convert.ToInt32(textBox6.Text);
                int Op = Convert.ToInt32(textBox7.Text);

                if (Op <= 4 && Op > 0)
                {
                    int result = kichigin.Class1.Calc(A, B, Op);

                    label15.Text = result.ToString();
                }
                else
                {
                    label15.Text = "Вы ввели не ту операцию";
                }
            }
            catch (Exception ex)
            {
                label15.Text = ex.Message;
            }
        }
    }
}
