﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using Mysqlx.Connection;

namespace ПР09
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //CREATE TABLE teacher (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(50) NOT NULL, object VARCHAR(20) NOT NULL, guide VARCHAR(10), experience INT, email VARCHAR(30));
        //INSERT INTO teacher (name, object, guide, experience, email) VALUES
        //('Иванова Мария Сергеевна', 'Математика', '10А', 15, 'm.ivanova@school123.ru'),
        //('Петров Алексей Владимирович', 'История', '5Б', 8, 'a.petrov@school123.ru'),
        //('Сидорова Анна Петровна', 'Русский язык', NULL, 22, 'a.sidorova@school123.ru'),
        //('Козлов Дмитрий Игоревич', 'Физика', '11Ф', 10, 'd.kozlov@school123.ru'),
        //('Никитина Елена Вадимовна', 'Химия', '9В', 18, 'e.nikitina@school123.ru'),
        //('Фёдоров Артём Олегович', 'Информатика', '8Г', 6, 'a.fedorov@school123.ru'),
        //('Жукова Ольга Борисовна', 'Биология', NULL, 30, 'o.zhukova@school123.ru'),
        //('Громов Иван Сергеевич', 'Литература', '6А', 12, 'i.gromov@school123.ru'),
        //('Ткаченко Светлана Викторовна', 'Английский язык', '7Б', 9, 's.tkachenko@school123.ru'),
        //('Белов Павел Николаевич', 'Физкультура', NULL, 25, 'p.belov@school123.ru');
        string strCon = "host=localhost;" +
                        "uid=root;" +
                        "pwd=root;" +
                        "database=teacher";
        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                MySqlConnection con = new MySqlConnection(strCon);

                con.Open();
                MessageBox.Show(Text = "Успешная авторизация!");

                MySqlCommand cmd = new MySqlCommand("SELECT * FROM school;", con);

                MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                DataTable dt = new DataTable();

                da.Fill(dt);
                dataGridView1.DataSource = dt;

                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(Text = "Вы не подключились к БД");
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                MySqlConnection con = new MySqlConnection(strCon);

                con.Open();

                //Запись в таблицу
                string name = textBox1.Text;
                string object_ = textBox2.Text;
                string guide = textBox3.Text;
                string experience = textBox4.Text;
                string email = textBox5.Text;

                string comand = $"INSERT INTO school(name, object, guide, experience, email) VALUES ('{name}', '{object_}', '{guide}', {experience}, '{email}');";
                MySqlCommand cmd = new MySqlCommand(comand, con);

                cmd.ExecuteNonQuery();
                MessageBox.Show(Text = "Запись успешно добавлена!");

                //Вывод
                MySqlCommand cmd2 = new MySqlCommand("SELECT * FROM school;", con);

                MySqlDataAdapter da = new MySqlDataAdapter(cmd2);
                DataTable dt = new DataTable();

                da.Fill(dt);
                dataGridView1.DataSource = dt;

                textBox1.Text = "";
                textBox2.Text = "";
                textBox3.Text = "";
                textBox4.Text = "";
                textBox5.Text = "";

                con.Close();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
    }
}
