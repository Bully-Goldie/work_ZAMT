SELECT 
    room.id,
    name,
    number_room,
    COUNT(DISTINCT kind_id)
FROM 
    room
JOIN 
    playsment ON room.id = room_id
GROUP BY 
    room.id, name, number_room