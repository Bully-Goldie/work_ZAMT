SELECT playsment.id, kind_id, room_id, quantity, name, number_room
FROM playsment
JOIN room ON playsment.room_id = room.id
WHERE playsment.quantity = 
(SELECT MAX(quantity) FROM playsment);