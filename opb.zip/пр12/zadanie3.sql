SELECT * FROM room
JOIN playsment ON room.id = playsment.room_id
WHERE quantity >= 5 AND quantity <= 10;