SELECT name, number_room, quantity
FROM playsment
JOIN kind ON kind_id = kind.id
JOIN room ON room_id = kind.id
WHERE species_name = '';