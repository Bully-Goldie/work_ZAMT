SELECT species_name, family, quantity, name, number_room
FROM 
    playsment
JOIN 
    kind ON kind_id = kind.id
JOIN 
    room ON room_id = room.id
ORDER BY 
    number_room ASC;