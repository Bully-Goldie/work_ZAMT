package goldie.id;

import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class Main {
    public static boolean Zadanie1(int N){
        int one = (N / 100) % 10;
        int two = (N / 10) % 10;
        int three = N % 10;

        int sum = one + two + three;
        int proiz = one * three;

        if(sum == proiz){
            return true;
        }else{
            return false;
        }
    }

    public static int[] Zadanie2(int[] array){
        int[] arrNeg = new int[array.length];

        for (int i = 0; i < array.length; i++){
            if(array[i] % 2 != 0){
                arrNeg[i] += array[i];
            }
        }
        Arrays.sort(arrNeg);
        int index = array.length;
        int max = arrNeg[index-1];

        for (int i = 0; i < array.length; i++){
            if(array[i] % 2 == 0){
                array[i] = array[i] + max;
            }
        }
        return array;
    }

    public static int[] Zadanie3(int[] array){
        int count = 0;

        for(int i = 0; i < array.length; i++){
            if(array[i] < 0){
                count++;
            }
        }

        int[] newArr = new int[array.length + count];
        int newIndex = 0;

        for (int i = 0; i < array.length; i++) {
            newArr[newIndex] = array[i];
            newIndex++;
            if (array[i] < 0) {
                newArr[newIndex] = 0;
                newIndex++;
            }
        }

        return newArr;
    }

    public static int Calc(int A, int B, int Op){
        switch (Op){
            case 1:
                return A - B;
            case 2:
                return A * B;
            case 3:
                return A / B;
            case 4:
                return A + B;
        }
        return 0;
    }

    public static void main(String[] args) {
        //Ввести целое положительное трехзначное число N (N>0).
        //Проверить истинность высказывания: "Сумма всех цифр введенного числа равна произведению первой и третьей цифры введенного числа".
        try{
            Scanner sc = new Scanner(System.in);
            System.out.println("Задние 1");

            System.out.print("Введите целое положительное трехзначное число: ");
            int N = sc.nextInt();
            if(N > 99 && N <= 999){
                boolean result = Zadanie1(N);

                System.out.println("Результат: " + result);
            }else{
                System.out.println("Вы ввели не трехзначное число.");
            }

        }catch (Exception ex){
            System.out.println(ex.getMessage());
        }

        //Дан целочисленный массив, состоящий из N элементов (N > 0).
        //Сложить со всеми четными числами максимальное нечетное число из этого массива. Вывести новый полученный массив.
        try{
            Scanner sc = new Scanner(System.in);
            System.out.println("Задание 2");

            System.out.print("Введите кол-во элементов массива: ");
            int N = sc.nextInt();

            if(N > 0){
                Random random = new Random();

                int[] array = new int[N];

                for (int i = 0; i < N; i++){
                    array[i] = random.nextInt(50);
                }

                System.out.println("До: "+Arrays.toString(array));

                int[] newArr = Zadanie2(array);
                System.out.println("После: " + Arrays.toString(newArr));
            }else{
                System.out.println("Вы ввели отрицательное кол-во элементов массива.");
            }
        }catch (Exception ex){
            System.out.println(ex.getMessage());
        }

        //Дан целочисленный массив, состоящий из N элементов (N > 0).
        //После каждого отрицательного элемента массива вставить элемент с нулевым значением.
        try{
            Scanner sc = new Scanner(System.in);
            System.out.println("Задание 3");

            System.out.print("Введите кол-во элементов массива: ");
            int N = sc.nextInt();

            if(N > 0){
                Random random = new Random();

                int[] array = new int[N];

                for (int i = 0; i < N; i++){
                    array[i] = random.nextInt();
                }

                int[] newArr = Zadanie3(array);

                System.out.println("Результат: " + Arrays.toString(newArr));
            }else{
                System.out.println("Вы ввели отрицательное кол-во элементов массива.");
            }
        }catch (Exception ex){
            System.out.println(ex.getMessage());
        }

        //Написать функцию int Calc(A, B, Op) целого типа, выполняющую над ненулевыми целыми числами A и B одну из арифметических операций и возвращающую ее результат.
        //Вид операции определяется целым параметром Op: 1 — вычитание, 2 — умножение, 3 — деление, 4 — сложение.
        try {
            Scanner sc = new Scanner(System.in);
            System.out.println("Задание 4");

            System.out.print("Введите первое число A: ");
            int A = sc.nextInt();

            System.out.print("Введите первое число B: ");
            int B = sc.nextInt();

            System.out.print("Введите операцию (1 — вычитание, 2 — умножение, 3 — деление, 4 — сложение): ");
            int Op = sc.nextInt();

            if(Op >= 1 && Op <= 4){
                int result = Calc(A, B, Op);

                System.out.println("Результат: " + result);
            }else{
                System.out.println("Вы неправильно ввели операцию.");
            }
        }catch (Exception ex){
            System.out.println(ex.getMessage());
        }
    }
}