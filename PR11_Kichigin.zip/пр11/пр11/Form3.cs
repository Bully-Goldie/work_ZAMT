﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using static System.Runtime.CompilerServices.RuntimeHelpers;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace пр11
{
    public partial class Form3 : Form
    {
        string StrCon = "host=localhost" +
        ";uid=root" +
        ";pwd=root;" +
        "database=pr11_Kichigin";
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            button2.Enabled = false;

            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridView1.DefaultCellStyle.SelectionBackColor = ColorTranslator.FromHtml("#D32B39");

            FillDataGrid();
        }

        void FillDataGrid()
        {
            using (MySqlConnection con = new MySqlConnection())
            {
                try
                {
                    con.ConnectionString = StrCon;

                    con.Open();

                    MySqlCommand cmd = new MySqlCommand("SELECT * FROM employers", con);
                    cmd.ExecuteNonQuery();

                    MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                    DataTable dt = new DataTable();

                    da.Fill(dt);

                    dataGridView1.DataSource = dt;
                    dataGridView1.Columns["id"].Visible = false;
                }
                catch (Exception)
                {
                    MessageBox.Show(Text = "Вы не подключились к БД");
                }
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;

            if ((ch >= 'А' && ch <= 'я') || ch == (char)Keys.Back || ch == (char)Keys.Space)
            {
                e.Handled = false;

                return;
            }

            e.Handled = true;
        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = Char.IsDigit(e.KeyChar) || e.KeyChar == (char)Keys.Back ? false : true;
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0 || e.ColumnIndex >= dataGridView1.Rows.Count)
                return;

            int rowIndex = e.RowIndex;
            string id = dataGridView1.Rows[rowIndex].Cells["id"].Value.ToString();
            string strCmd = "SELECT * FROM employers WHERE id='" + id + "';";


            using (MySqlConnection con = new MySqlConnection())
            {
                try
                {
                    con.ConnectionString = StrCon;

                    con.Open();

                    MySqlCommand cmd = new MySqlCommand(strCmd, con);
                    MySqlDataReader rdr = cmd.ExecuteReader();

                    rdr.Read();

                    textBox1.Text = rdr["company_name"].ToString();
                    textBox2.Text = rdr["contact_person"].ToString();
                    maskedTextBox1.Text = rdr["phone"].ToString();
                    textBox3.Text = rdr["available_vacancies"].ToString();
                    textBox4.Text = rdr["address"].ToString();

                    button2.Enabled = true;
                }
                catch (Exception)
                {
                    throw;
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int rowIndex = dataGridView1.CurrentCell.RowIndex;

            string primaryKey = dataGridView1.Rows[rowIndex].Cells["id"].Value.ToString();

            string strCmd = @"UPDATE employers SET company_name='" + textBox1.Text + "', contact_person='" + textBox2.Text + "', phone='" + maskedTextBox1.Text + "', available_vacancies='" + textBox3.Text + "', address='" + textBox4.Text + "' WHERE id='" + primaryKey + "';";

            using (MySqlConnection con = new MySqlConnection())
            {
                try
                {
                    con.ConnectionString = StrCon;

                    con.Open();

                    MySqlCommand cmd = new MySqlCommand(strCmd, con);
                    int res = cmd.ExecuteNonQuery();

                    MessageBox.Show("Отредактирован атрибут под id " + primaryKey.ToString(), "Успешное редактирование!", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);

                    button2.Enabled = false;
                    textBox1.Text = "";
                    textBox2.Text = "";
                    maskedTextBox1.Text = "";
                    textBox3.Text = "";
                    textBox4.Text = "";

                    FillDataGrid();
                }
                catch (Exception ex)
                {
                    throw;
                }
            }
        }
    }
}
