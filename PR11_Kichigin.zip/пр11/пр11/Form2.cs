﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace пр11
{
    public partial class Form2 : Form
    {
        string StrCon = "host=localhost" +
                ";uid=root" +
                ";pwd=root;" +
                "database=pr11_Kichigin";
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridView1.DefaultCellStyle.SelectionBackColor = ColorTranslator.FromHtml("#D32B39");

            try
            {
                MySqlConnection con = new MySqlConnection(StrCon);

                con.Open();

                MySqlCommand cmd = new MySqlCommand("SELECT * FROM employers;", con);

                MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                DataTable dt = new DataTable();

                da.Fill(dt);
                dataGridView1.DataSource = dt;
                dataGridView1.Columns["id"].Visible = false;

                con.Close();
            }
            catch (Exception)
            {
                MessageBox.Show(Text = "Вы не подключились к БД");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
