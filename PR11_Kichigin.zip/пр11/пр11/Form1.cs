﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace пр11
{
    public partial class Form1 : Form
    {
        string StrCon = "host=localhost" +
                        ";uid=root" +
                        ";pwd=root;" +
                        "database=pr11_Kichigin";

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                MySqlConnection conn = new MySqlConnection(StrCon);

                conn.Open();

                label1.Text = "Успешная авторизация!";

                conn.Close();
            }
            catch(Exception)
            {
                MessageBox.Show(Text = "Вы не подключились к БД!");
            }

        }
        private void button1_Click(object sender, EventArgs e)
        {
            Form2 settingsForm = new Form2();
            settingsForm.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form3 settingsForm = new Form3();
            settingsForm.Show();
        }
    }
}
