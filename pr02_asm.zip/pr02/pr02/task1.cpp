﻿#include <iostream>

int main()
{
    _asm
    {   
        //Задание 1
        //Определить, больше ли число 382, чем сумма первых 14 элементов последовательности целых нечетных чисел?

        mov ebx,382
        mov eax,1
        mov edx,0
        mov ecx,0

    m100:
        cmp ecx,14
        je m200
        inc ecx
        add edx,eax
        add eax,2
        jmp m100
    m200:
        cmp ebx,edx
        jg m300
        mov al,0
        jmp m400
    m300:
        mov al,1
        nop
    m400:
        nop
    }
}