﻿#include <iostream>

int main()
{
	char arr[] = "g7hjygj7ghj7gh7jghj7ghjghh7gyffh878ytgvhjhiig6uy";

	_asm
	{
		//Задание 3
		//Дана строка.Размер строки может быть разным.
		//Подсчитать количество символов 'h' и '7' в заданной строке.Если символа 'h' больше чем символа '7' - поместить в регистр AL значение 1,
		//иначе поместить 0 в тот же регистр.
		mov eax, 0 //h 104
		mov ebx, 0 //7 55
		mov ecx, 0

	m1:
		lea esi,arr[ecx]
		cmp arr[ecx], 0
		je m4

		cmp arr[ecx],104
		je m2
		
		cmp arr[ecx],55
		je m3

		inc ecx
		
		jmp m1
	m2:
		add eax,1
		inc ecx
		jmp m1
	m3:
		add ebx,1
		inc ecx
		jmp m1
	m4:
		cmp eax,ebx
		jge m5
		mov al,0
		jmp m6
	m5:
		mov al,1
	m6:
		nop
	}
}