﻿#include <iostream>

int main()
{
    char arr[] = "cbcfcdf_kfkfgkhmfmr__dqoqyn";

    //Задание 2
    //Дана строка. Размер строки может быть разным. Заменить на символ 'Q' все символы в заданной строке, имеющие одинаковых соседей слева и справа.
    //Например, abcQcdf_kfgQgkhmQmr__dqozyn.

    _asm
    {
        mov bl,0
        mov al,0
    m1:
        mov bl, byte ptr arr[ecx]
        jmp m2
    m2:
        add ecx,2
        jmp m3
    m3:
        mov al,byte ptr arr[ecx]
        jmp m4
    m4:
        cmp bl,al
        je m5
        sub ecx,1 
        jmp m1
    m5:
        sub ecx, 1
        mov arr[ecx], 'Q'
        inc ecx
        cmp arr[ecx], 0
        je m6
        jmp m1
    m6:
        lea esi,arr
        nop
    }
}