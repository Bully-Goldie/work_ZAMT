﻿using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace пр08
{
    class Program
    {
        static string zadanie1(int N)
        {
            int one = (N / 1000) % 10;
            int two = (N / 100) % 10;
            int three = (N / 10) % 10;
            int four = N % 10;

            if (one != two && two != three && three != four)
            {
                return "Все цифры данного числа различны";
            }
            else
            {
                return "Не все числа данного числа различны";
            }
        }

        static void zadanie2(int N, int A)
        {
            int[] array = new int[N];

            switch (A)
            {
                case 1:
                    {
                        Random random = new Random();
                        for (int i = 0; i < array.Length; i++)
                        {
                            array[i] = random.Next(-50, 50);
                        }
                    }
                    break;

                case 2:
                    {
                        Console.WriteLine("Введите элементы массива:");
                        for (int i = 0; i < N; i++)
                        {
                            array[i] = Convert.ToInt32(Console.ReadLine());
                        }
                    }
                    break;

                default:
                    Console.WriteLine("Некорректный выбор.");
                    return;
            }

            Console.WriteLine(string.Join(", ", array));

            int one_polovina = N / 2;
            int[] one = new int[one_polovina];

            for (int i = 0; i < one_polovina; i++)
            {
                one[i] = array[i];
            }

            for (int i = 0; i < one_polovina; i++)
            {
                if (i + one_polovina < N)
                {
                    array[i] = array[i + one_polovina];
                }
            }

            for (int i = 0; i < one_polovina; i++)
            {
                if (i + one_polovina < N)
                {
                    array[i + one_polovina] = one[i];
                }
            }

            Console.WriteLine(string.Join(", ", array));
        }
        static int Lower(string str)
        {
            string[] chararray = str.Split(new char[] { '_' }, StringSplitOptions.RemoveEmptyEntries);

            int count = 0;

            for (int i = 0; i < chararray.Length; i++)
            {
                char[] charArray = chararray[i].ToCharArray();
                for (int j = 0; j < charArray.Length; j++)
                {
                    if (char.IsLower(charArray[j]))
                    {
                        count++;
                    }
                }
            }
            return count;
        }

        static int SumRangeOdd(int A, int B)
        {
            if (A > B)
            {
                return 0;
            }

            int sum = 0;
            for (int i = A; i <= B; i++)
            {
                if (i % 2 != 0)
                {
                    sum += i;
                }
            }
            return sum;
        }

        static int Min2Of5Sum(int A, int B, int C, int D, int E)
        {
            int[] array = {A, B, C, D, E};

            Array.Sort(array);

            return array[0] + array[1];
        }
        static void Main(string[] args)
        {
        m:
            try
            {
                Console.Write("Введите номер задания от 1 до 5 или нажмите 6 чтобы выйти из программы: ");
                int A = Convert.ToInt32(Console.ReadLine());

                switch (A)
                {
                    case 1:
                        {
                        //Дано четырехзначное целое положительное число N (N>0).
                        //Проверить истинность высказывания: "Все цифры данного числа различны".
                        m1:
                            try
                            {
                                Console.WriteLine("Задание 1");

                                Console.Write("Введите целое четырехзначное число: ");
                                int N = Convert.ToInt32(Console.ReadLine());

                                if (N >= 1000 && N <= 9999)
                                {
                                    string res = zadanie1(N);

                                    Console.WriteLine(res);
                                }
                                else
                                {
                                    Console.WriteLine("Вы ввели не четырехзначное число. Попробуйте еще раз...");
                                    goto m1;
                                }
                            }
                            catch (System.FormatException ex1)
                            {
                                Console.WriteLine("Ошибка! Вы ввели не число или же оно с плавающей точкой. {0}", ex1.Message.ToString());
                                goto m1;
                            }

                            catch (System.OverflowException ex2)
                            {
                                Console.WriteLine("Ошибка! Значение недопустимо большое. {0}", ex2.Message.ToString());
                                goto m1;
                            }
                        }
                        goto m;

                    case 2:
                        {
                        //Дан массив размера N (N — четное положительное число).
                        //Поменять местами первую и вторую половины массива.
                        m2:
                            try
                            {
                                Console.WriteLine("Задание 2");
                                Console.Write("Введите размер массива: ");
                                int N = Convert.ToInt32(Console.ReadLine());

                                if (N > 0 && N % 2 == 0)
                                {
                                    Console.Write("Введите 1 чтобы заполнить массив рандомными числами или 2 чтобы заполнить массив вручную: ");
                                    int A2 = Convert.ToInt32(Console.ReadLine());

                                    zadanie2(N, A2);
                                }
                                else
                                {
                                    Console.WriteLine("Массив отрицательный либо не четный. Попробуйте еще раз...");
                                    goto m2;
                                }
                            }
                            catch (System.FormatException ex1)
                            {
                                Console.WriteLine("Ошибка! Вы ввели не число или же оно с плавающей точкой. {0}", ex1.Message.ToString());
                                goto m2;
                            }

                            catch (System.OverflowException ex2)
                            {
                                Console.WriteLine("Ошибка! Значение недопустимо большое. {0}", ex2.Message.ToString());
                                goto m2;
                            }
                        }
                        goto m;
                    case 3:
                        {
                        //Вводится строка, состоящая из слов, разделенных подчеркиваниями (одним или несколькими).
                        //Длина строки может быть разной. Подсчитать количество строчных букв в каждом слове и вывести их.
                            
                            Console.WriteLine("Задание 3");

                            Console.WriteLine("Введите строку разделенными подчеркиваниями: ");
                            string str = Console.ReadLine();
                            int res = Lower(str);
                            Console.WriteLine("Количество строчных букв = {0}", res);
                        }
                        goto m;
                    case 4:
                        {
                        //Написать функцию int SumRangeOdd(A, B) целого типа,
                        //находящую сумму всех нечетных целых чисел в диапазоне от A до B включительно (A и B — целые положительные).
                        //Если A > B, то функция должна возвращать число 0.
                        m4:
                            try
                            {
                                Console.WriteLine("Задание 4");
                                Console.Write("Введите число A: ");
                                int A1 = Convert.ToInt32(Console.ReadLine());
                                Console.Write("Введите число B: ");
                                int B = Convert.ToInt32(Console.ReadLine());

                                if (A>0 && B>0)
                                {
                                    int res = SumRangeOdd(A1, B);

                                    Console.WriteLine(res);
                                }
                                else
                                {
                                    Console.WriteLine("Числа не могут быть отрицательными. Попробуйте еще раз...");
                                    goto m4;
                                }
                            }
                            catch (System.FormatException ex1)
                            {
                                Console.WriteLine("Ошибка! Вы ввели не число или же оно с плавающей точкой. {0}", ex1.Message.ToString());
                                goto m4;
                            }

                            catch (System.OverflowException ex2)
                            {
                                Console.WriteLine("Ошибка! Значение недопустимо большое. {0}", ex2.Message.ToString());
                                goto m4;
                            }
                        }
                        goto m;
                    case 5:
                        {
                        //Написать функцию int Min2Of5Sum(A, B, C, D, E) целого типа,
                        //возвращающую сумму двух самых минимальных из 5-ти своих аргументов (параметры A, B, C, D, E - целые числа).
                        m5:
                            try
                            {
                                Console.WriteLine("Задание 5");
                                Console.WriteLine("Введите числа A, B, C, D, E");
                                int A1 = Convert.ToInt32(Console.ReadLine());
                                int B = Convert.ToInt32(Console.ReadLine());
                                int C = Convert.ToInt32(Console.ReadLine());
                                int D = Convert.ToInt32(Console.ReadLine());
                                int E = Convert.ToInt32(Console.ReadLine());

                                int res = Min2Of5Sum(A1, B, C, D, E);
                                Console.WriteLine("Сумму двух самых минимальных = {0}", res);
                            }
                            catch (System.FormatException ex1)
                            {
                                Console.WriteLine("Ошибка! Вы ввели не число или же оно с плавающей точкой. {0}", ex1.Message.ToString());
                                goto m5;
                            }

                            catch (System.OverflowException ex2)
                            {
                                Console.WriteLine("Ошибка! Значение недопустимо большое. {0}", ex2.Message.ToString());
                                goto m5;
                            }
                        }
                        goto m;
                    case 6:
                        {
                            Console.WriteLine("Вы вышли из программы.");
                        }break;

                    default:
                        Console.WriteLine("Вы не ввели номер задания. Попробуйте еще раз...");
                        goto m;
                }
            }
            catch (System.FormatException ex1)
            {
                Console.WriteLine("Ошибка! Вы ввели не число или же оно с плавающей точкой. {0}", ex1.Message.ToString());
                goto m;
            }

            catch (System.OverflowException ex2)
            {
                Console.WriteLine("Ошибка! Значение недопустимо большое. {0}", ex2.Message.ToString());
                goto m;
            }
        }
    }
}
