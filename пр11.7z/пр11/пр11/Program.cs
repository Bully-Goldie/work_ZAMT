﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using var10;

namespace пр11
{
    class Program
    {
        static void Main(string[] args)
        {
        //Задание 1
        //Ввести целое положительное число. Проверить истинность высказывания: "Данное целое число является четным двузначным числом".
        m1:
            try
            {
                Console.WriteLine("Задание 1");
                Console.Write("Введите целое положительное число: ");
                int N = Convert.ToInt32(Console.ReadLine());
                string res;

                Task1 zadanie1 = new Task1();

                zadanie1.N = N;

                if (zadanie1.Positive()==true)
                {
                    res = zadanie1.Check();
                    Console.WriteLine(res);
                }
                else
                {
                    Console.WriteLine("Вы ввели не положительное число. попробуйте еще раз...");
                    goto m1;
                }
            }
            catch (System.FormatException ex1)
            {
                Console.WriteLine(ex1.Message.ToString());
                goto m1;
            }
            catch (System.OverflowException ex2)
            {
                Console.WriteLine(ex2.Message.ToString());
                goto m1;
            }

        //Задание 2
        //Дано целое положительное пятизначное число N (N > 0). Найти разницу между суммой всех его цифр и произведением четных цифр.
        m2:
            try
            {
                Console.WriteLine("Задание 2");
                Console.Write("Введите целое положительное пятизначное число: ");
                int N = Convert.ToInt32(Console.ReadLine());

                Task2 zadanie2 = new Task2();
                zadanie2.N = N;

                if (zadanie2.Check() == true)
                {
                    int res = zadanie2.Five();

                    Console.WriteLine("Разница между суммой всех его цифр и произведением четных цифр = {0}", res);
                }
                else
                {
                    Console.WriteLine("Вы ввели не пятизначное число. Попробуйте еще раз...");
                    goto m2;
                }
            }
            catch (System.FormatException ex1)
            {
                Console.WriteLine(ex1.Message.ToString());
                goto m2;
            }
            catch (System.OverflowException ex2)
            {
                Console.WriteLine(ex2.Message.ToString());
                goto m2;
            }

        //Задание 3
        //Дан целочисленный массив, состоящий из N элементов (N > 0, N - четное число),
        //в котором количество отрицательных элементов равно количеству положительным.
        //Поменяйте местами первый отрицательный и первый положительный элемент массива,
        //второй отрицательный и второй положительный и так далее.
        m3:
            try
            {
                Console.WriteLine("Задание 3");
                Console.Write("Введите четное кол-во элементов массива: ");
                int N = Convert.ToInt32(Console.ReadLine());

                Task3 zadanie3 = new Task3();
                zadanie3.N = N;

                if (zadanie3.Check() == true)
                {
                    int[] array = zadanie3.Array();
                    Console.WriteLine(string.Join(" ", array));
                }
                else
                {
                    Console.WriteLine("Вы ввели не четное или не положительное число. Попробуйте еще раз...");
                    goto m3;
                }
            }
            catch (System.FormatException ex1)
            {
                Console.WriteLine(ex1.Message.ToString());
                goto m3;
            }
            catch (System.OverflowException ex2)
            {
                Console.WriteLine(ex2.Message.ToString());
                goto m3;
            }

        //Задание 4
        //Написать функцию int CountDigitsOdd(K) целого типа, возвращающую количество нечетных цифр в целом положительном числе K.
        m4:
            try
            {
                Console.WriteLine("Задание 4");
                Console.WriteLine("Введите целое положительно число: ");
                int K = Convert.ToInt32(Console.ReadLine());

                Task4 zadanie4 = new Task4();
                zadanie4.K = K;

                if (zadanie4.Check() == true)
                {
                    int res = zadanie4.CountDigitsOdd(K);

                    Console.WriteLine(res);
                }
                else
                {
                    Console.WriteLine();
                    goto m4;
                }
            }
            catch (System.FormatException ex1)
            {
                Console.WriteLine(ex1.Message.ToString());
                goto m4;
            }
            catch (System.OverflowException ex2)
            {
                Console.WriteLine(ex2.Message.ToString());
                goto m4;
            }
        }
    }
}
