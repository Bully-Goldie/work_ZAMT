﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace var10
{
    class Task2
    {
        public int N;

        public bool Check()
        {
            if(N > 9999 && N <= 99999)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public int Five()
        {
            int one = (N / 10000) % 10;
            int two = (N / 1000) % 10;
            int three = (N / 100) % 10;
            int four = (N / 10) % 10;
            int five = N % 10;

            int sum = one + two + three + four + five;

            int[] array = { one, two, three, four, five };

            int res = 1;

            for (int i = 0; i < array.Length; i++)
            {
                res *= array[i];
            }

            return sum - res;
        }
    }
}
