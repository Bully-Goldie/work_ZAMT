﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace var10
{
    class Task4
    {
        public int K;

        public bool Check()
        {
            if (K > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public int CountDigitsOdd(int K)
        {
            int count = 0;

            while (K > 0)
            {
                int digit = K % 10;

                if (digit % 2 != 0)
                {
                    count++;
                }

                K /= 10;
            }

            return count;
        }
    }
}
