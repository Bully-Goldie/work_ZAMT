﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace var10
{
    class Task1
    {
        public int N;

        public bool Positive()
        {
            if (N < 0)
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        public string Check()
        {
            if (N % 2 == 0 && N > 9 && N < 100)
            {
                return "Данное целое число является четным двузначным числом";
            }
            else
            {
                return "Данное число не является четным и двухзначным";
            }
        }
    }
}
