﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace var10
{
    class Task3
    {
        public int N;

        public bool Check()
        {
            if (N % 2 == 0 && N > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public int[] Array()
        {
            int[] array1 = new int[N / 2];
            int[] array2 = new int[N / 2];

            Random random = new Random();

            for (int i = 0; i < array1.Length; i++)
            {
                array1[i] = random.Next(100);
            }

            for (int i = 0; i < array2.Length; i++)
            {
                array2[i] = -random.Next(1, 100);
            }

            int[] array = new int[N];

            for (int i = 0; i < array1.Length; i++)
            {
                array[2 * i] = array1[i];
                array[2 * i + 1] = array2[i];
            }

            return array;
        }
    }
}
