﻿using System;

namespace пр02
{
    class Program
    {
        static void Main(string[] args)
        {
            // задание 1
            M1:
            try
            {
                // ввод значений через консоль пользователем
                Console.WriteLine("Задание 1");
                Console.Write("Введите челое положительное число A: ");
                int A = Convert.ToInt32(Console.ReadLine());

                Console.Write("Введите челое положительное число B: ");
                int B = Convert.ToInt32(Console.ReadLine());

                // проверка на положительное числа
                if (A>0 && B>0)
                {
                    //Проверка истинности высказывания: «Каждое из чисел A и B нечетное»
                    if (A % 2 == 0 && B % 2 == 0)
                    {
                        Console.WriteLine("Все числа четные");
                    }
                    else if (A % 2 == 0 || B % 2 == 0)
                    {
                        Console.WriteLine("Одно из числа четное");
                    }
                    else
                    {
                        Console.WriteLine("Все числа не четные");
                    }
                }
                else
                {
                    Console.WriteLine("Вы введи не положительные числа! Попробуйте еще раз...");
                    goto M1;
                }

            }
            // обработка ошибок
            catch (System.FormatException ex1)
            {
                Console.WriteLine("Ошибка! Вы ввели не число {0}", ex1.Message.ToString());
                goto M1;
            }
            catch (System.OverflowException ex2)
            {
                Console.WriteLine("Значение недопустимо большим {0}", ex2.Message.ToString());
                goto M1;
            }

            // задание 2
            M2:
            try
            {
                // ввод значений через консоль пользователем
                Console.WriteLine("Задание 2");
                Console.WriteLine("Введите два целых положительных числа A и B, число A должно быть меньше чем число B");
                Console.Write("Введите челое положительное число A: ");
                int A = Convert.ToInt32(Console.ReadLine());

                Console.Write("Введите челое положительное число B: ");
                int B = Convert.ToInt32(Console.ReadLine());

                int count = 0;
                int sum = 0;

                // проверка на положительное числа
                if (A>0 && B>0)
                {
                    // выполнение программы
                    for (int i = 0; A < B; i++)
                    {
                        --B;
                        if (B == A)
                        {
                            continue;
                        }
                        Console.WriteLine("Все числа в порядке убывания: {0}", B);
                        count++;
                        sum += B;
                    }
                    Console.WriteLine("Количество чисел: {0}", count);
                    Console.WriteLine("Сумма всех чисел: {0}", sum);
                }
                else
                {
                    Console.WriteLine("Вы введи не положительные числа! Попробуйте еще раз...");
                    goto M2;
                }
            }
            // обработка ошибок
            catch (System.FormatException ex1)
            {
                Console.WriteLine("Ошибка! Вы ввели не число {0}", ex1.Message.ToString());
                goto M2;
            }

            catch (System.OverflowException ex2)
            {
                Console.WriteLine("Значение недопустимо большим {0}", ex2.Message.ToString());
                goto M2;
            }

            // задание 3
            M3:
            try
            {
                // ввод значений через консоль пользователем
                Console.WriteLine("Задание 3");
                Console.Write("Введите челое число A: ");
                int A = Convert.ToInt32(Console.ReadLine());

                Console.Write("Введите челое число B: ");
                int B = Convert.ToInt32(Console.ReadLine());

                Console.Write("Введите челое число C: ");
                int C = Convert.ToInt32(Console.ReadLine());

                // выполнение программы
                for (;A>C;)
                {
                    --A;
                    if (A==B)
                    {
                        Console.WriteLine("Число B находится между числами A и C");
                        break;
                    }
                }
                if (A!=B)
                {
                    Console.WriteLine("Число B не находится между числами A и C");
                }
            }
            // обработка ошибок
            catch (System.FormatException ex1)
            {
                Console.WriteLine("Ошибка! Вы ввели не число {0}", ex1.Message.ToString());
                goto M3;
            }

            catch (System.OverflowException ex2)
            {
                Console.WriteLine("Значение недопустимо большим {0}", ex2.Message.ToString());
                goto M3;
            }
            //задание 4
            M4:
            try
            {
                // ввод значения через консоль пользователем
                Console.WriteLine("Задание 4");
                Console.Write("Введите челое число N оно должно быть больше 0: ");
                int N = Convert.ToInt32(Console.ReadLine());
                double proiz = 1;

                // выполнение программы
                if (N > 0)
                {
                    for (int i = 1; i <= N; i++)
                    {
                        if (i % 2 != 0)
                        {
                            proiz *= i;
                        }
                        else
                        {
                            proiz *= i;
                        }
                    }
                }else
                {
                    Console.WriteLine("N меньше нуля попробуйте еще раз...");
                    goto M4;
                }
                Console.WriteLine("Произведение {0}", proiz);
            }
            // обработка ошибок
            catch (System.FormatException ex1)
            {
                Console.WriteLine("Ошибка! Вы ввели не число {0}", ex1.Message.ToString());
                goto M4;
            }

            catch (System.OverflowException ex2)
            {
                Console.WriteLine("Значение недопустимо большим {0}", ex2.Message.ToString());
                goto M4;
            }
            // задание 5
            M5:
            try
            {
                // ввод значений через консоль пользователем
                Console.WriteLine("Задание 5");
                Console.Write("Введите достоинство карты от 11 до 14: ");
                int N = Convert.ToInt32(Console.ReadLine());
                Console.Write("Введите масть карты от 1 до 4: ");
                int M = Convert.ToInt32(Console.ReadLine());
                string res = "";
                string res2 = "";

                // проверка на коректные числа
                if (N < 6 || N > 14 || M < 1 || M > 4)
                {
                    Console.WriteLine("Не коректные данные. Попродуйте еще раз");
                    goto M5;
                }
                // выпосления программы
                switch (N)
                {
                    case 11: res = "валет";
                        break;
                    case 12:
                        res = "дама";
                        break;
                    case 13:
                        res = "король";
                        break;
                    case 14:
                        res = "туз";
                        break;
                }

                switch (M)
                {
                    case 1:
                        res2 = "пики";
                        break;
                    case 2:
                        res2 = "трефы";
                        break;
                    case 3:
                        res2 = "бубны";
                        break;
                    case 4:
                        res2 = "черви";
                        break;
                }
                Console.WriteLine("{0} {1}",res, res2);
            }
            // обработка ошибок
            catch (System.FormatException ex1)
            {
                Console.WriteLine("Ошибка! Вы ввели не число {0}", ex1.Message.ToString());
                goto M5;
            }

            catch (System.OverflowException ex2)
            {
                Console.WriteLine("Значение недопустимо большим {0}", ex2.Message.ToString());
                goto M5;
            }
        }
    }
}
