import java.io.*;

public class Main {
    public static void main(String[] args) {
        //Дано целое положительное четырехзначное ненулевое число N (N>0).
        //Проверить истинность высказывания: «Данное число читается одинаково слева направо и справа налево».
        System.out.println("Задание 1");
        String path = System.getProperty("user.dir") + File.separatorChar + "input1.txt";

        int N = 0;
        boolean result = false;

        try (FileReader fr = new FileReader(path))
        {
            BufferedReader br = new BufferedReader(fr);
            String s;

            while ((s = br.readLine()) != null)
            {
                N = Integer.parseInt(s);

                if(N > 999 && N <= 9999){
                    int one = (N / 1000) % 10;
                    int two = (N / 100) % 10;
                    int three = (N / 10) % 10;
                    int four = N % 10;

                    if(one == four && two == three){
                        result = true;
                    }
                }else{
                    System.out.println("Число не четырехзначное или не целое.");
                }
            }
            fr.close();

        }
        catch (IOException ex)
        {
            System.out.println(ex.getMessage());
        }

        try(FileWriter writer = new FileWriter("output1.txt", false))
        {
            String text = String.valueOf(Boolean.parseBoolean(String.valueOf(result)));
            writer.write(text);
            System.out.println("Запись в файл выполнена");
            System.out.println();
        }
        catch(IOException ex)
        {
            System.out.println(ex.getMessage());
        }
    }
}