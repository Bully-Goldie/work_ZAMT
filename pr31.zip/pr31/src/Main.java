import java.io.*;
import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        //Дано целое положительное четырехзначное ненулевое число N (N>0).
        //Проверить истинность высказывания: «Данное число читается одинаково слева направо и справа налево».
        try {
            System.out.println("Задание 1");
            String path = System.getProperty("user.dir") + File.separatorChar + "input1.txt";

            FileReader fr = new FileReader(path);
            BufferedReader br = new BufferedReader(fr);
            String s;
            int N = 0;
            boolean result = false;

            while ((s = br.readLine()) != null) {
                N = Integer.parseInt(s);

                if (N > 999 && N <= 9999) {
                    int one = (N / 1000) % 10;
                    int two = (N / 100) % 10;
                    int three = (N / 10) % 10;
                    int four = N % 10;

                    if (one == four && two == three) {
                        result = true;
                    }
                } else {
                    System.out.println("Число не четырехзначное или не целое.");
                }
            }
            fr.close();

        //запись
        FileWriter writer = new FileWriter("output1.txt", false);
            writer.write(String.valueOf(result));
            writer.close();
        System.out.println("Запись в файл выполнена");
        System.out.println();
        }
        catch(Exception ex)
        {
            System.out.println(ex.getMessage());
        }
        //Даны пять целых ненулевых положительных чисел. Найти сумму двух наименьших чисел.
        try {
            System.out.println("Задание 2");
            String path = System.getProperty("user.dir") + File.separatorChar + "input2.txt";

            FileReader fr = new FileReader(path);
            BufferedReader br = new BufferedReader(fr);
            String s;

            int one = 0;
            int two = 0;

            while ((s = br.readLine()) != null) {
                int[] arr = Arrays.stream(s.split(" ")).mapToInt(Integer::parseInt).toArray();
                Arrays.sort(arr);
                one = arr[0];
                two = arr[1];
            }
            fr.close();

            //запись
            FileWriter writer = new FileWriter("output2.txt", false);
            writer.write(String.valueOf(one));
            writer.append("\n");
            writer.append(String.valueOf(two));
            writer.close();
            System.out.println("Запись в файл выполнена");
            System.out.println();
        }
        catch(Exception ex)
        {
            System.out.println(ex.getMessage());
        }
        //Дан целочисленный массив, состоящий из N элементов (N > 0). Поменять местами минимальный и максимальный элемент в массиве.
        //Вывести вначале исходный массив, а строкой ниже полученный массив после замены.
        try {
            System.out.println("Задание 3");
            String path = System.getProperty("user.dir") + File.separatorChar + "input3.txt";

            FileReader fr = new FileReader(path);
            BufferedReader br = new BufferedReader(fr);
            String s;

            StringBuilder output = new StringBuilder();

            while ((s = br.readLine()) != null) {
                int[] arr = Arrays.stream(s.split(" ")).mapToInt(Integer::parseInt).toArray();

                output.append("Исходный массив:\n");
                for (int el : arr) {
                    output.append(el).append(" ");
                }
                output.append("\n");

                int max = arr[0];
                int min = arr[0];
                int maxIndex = 0;
                int minIndex = 0;

                for (int i = 1; i < arr.length; i++) {
                    if (arr[i] > max) {
                        max = arr[i];
                        maxIndex = i;
                    }
                    if (arr[i] < min) {
                        min = arr[i];
                        minIndex = i;
                    }
                }

                int[] newarr = arr.clone();
                newarr[minIndex] = max;
                newarr[maxIndex] = min;

                output.append("Массив после замены:\n");
                for (int el : newarr) {
                    output.append(el).append(" ");
                }
                output.append("\n\n");
            }
            fr.close();

            FileWriter writer = new FileWriter("output3.txt", false);
            writer.write(output.toString());
            writer.close();

            System.out.println("Запись в файл выполнена");
            System.out.println();
        }
        catch(Exception ex) {
            System.out.println(ex.getMessage());
        }
        //Вводится строка. Длина строки может быть разной. Подсчитать и вывести количество содержащихся в ней прописных букв латинского алфавита.
        try {
            System.out.println("Задание 4");
            String path = System.getProperty("user.dir") + File.separatorChar + "input4.txt";

            FileReader fr = new FileReader(path);
            BufferedReader br = new BufferedReader(fr);
            String s;
            int count = 0;

            while ((s = br.readLine()) != null) {
                char[] arrchar = s.toCharArray();
                for(int i = 0; i < arrchar.length; i++){
                    if(Character.isUpperCase(arrchar[i])){
                        count++;
                    }
                }
            }
            fr.close();

            //запись
            FileWriter writer = new FileWriter("output4.txt", false);
            writer.write(String.valueOf(count));
            writer.close();
            System.out.println("Запись в файл выполнена");
            System.out.println();
        }
        catch(Exception ex)
        {
            System.out.println(ex.getMessage());
        }

        //Вводится строка, состоящая из слов, разделенных подчеркиваниями (одним или несколькими).
        //Длина строки может быть разной. Определить и вывести на экран слово/слова, которые содержат ровно три буквы 'z'.
        try {
            System.out.println("Задание 5");
            String path = System.getProperty("user.dir") + File.separatorChar + "input5.txt";

            FileReader fr = new FileReader(path);
            BufferedReader br = new BufferedReader(fr);
            String s;
            String result = "";

            while ((s = br.readLine()) != null) {
                String[] arr = s.split("_");
                for (String word : arr) {
                    int count = 0;
                    for (char c : word.toCharArray()) {
                        if (c == 'z') {
                            count++;
                        }
                    }
                    if (count == 3) {
                        result = word;
                    }
                }
            }
            fr.close();

            //запись
            FileWriter writer = new FileWriter("output5.txt", false);
            writer.write(result);
            writer.close();
            System.out.println("Запись в файл выполнена");
            System.out.println();
        }
        catch(Exception ex)
        {
            System.out.println(ex.getMessage());
        }
    }
}