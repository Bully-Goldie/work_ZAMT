﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassLibrary2;

namespace pr23
{
    class Program
    {
        static void Main(string[] args)
        {
            //Из пяти введенных целых положительных чисел найти два наибольших и вывести произведение этих двух наибольших чисел.
            ClassLibrary2.task1 class1 = new task1();
        m1:
            try
            {
                Console.WriteLine("Задание 1");
                Console.WriteLine("Напишите пять целых положительных чисел:");

                int a = Convert.ToInt32(Console.ReadLine());
                int b = Convert.ToInt32(Console.ReadLine());
                int c = Convert.ToInt32(Console.ReadLine());
                int d = Convert.ToInt32(Console.ReadLine());
                int e = Convert.ToInt32(Console.ReadLine());

                if (a > 0 && b > 0 && c > 0 && d > 0 && e > 0)
                {
                    int[] array = { a, b, c, d, e };

                    int[] res = class1.twohigh(array);

                    Console.WriteLine("Два наибольших числа: {0}, {1}", res[0], res[1]);
                }
                else
                {
                    Console.WriteLine("Вы ввели не положительное число. попробуйте еще раз...");
                    goto m1;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message.ToString());
                goto m1;
            }

            //Дано расстояние L (L - целое положительное число) в сантиметрах.
            //Используя операцию деления нацело, найти количество полных метров в нем (1 метр = 100 см).
            ClassLibrary2.task2 class2 = new task2();
        m2:
            try
            {
                Console.WriteLine("Задание 2");
                Console.Write("Введите расстояние в см: ");
                int L = Convert.ToInt32(Console.ReadLine());

                if (L > 0)
                {
                    int res = class2.metr(L);
                    Console.WriteLine(res);
                }
                else
                {
                    Console.WriteLine("Вы ввели не положительное число. Попробуйте еще раз...");
                    goto m2;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message.ToString());
                goto m2;
            }

            //Дан целочисленный массив, состоящий из N элементов (N > 0).
            //Переставить в обратном порядке элементы массива, расположенные между его минимальным и максимальным элементами,
            //не включая минимальный и максимальный элементы.
            ClassLibrary2.task3 task3 = new task3();
        m3:
            try
            {
                Console.WriteLine("Задание 3");
                Console.Write("Введите длинну массива: ");
                int N = Convert.ToInt32(Console.ReadLine());

                Console.Write("Введите минимальный элемент массива: ");
                int a = Convert.ToInt32(Console.ReadLine());
                Console.Write("Введите максимальный элемент массива: ");
                int b = Convert.ToInt32(Console.ReadLine());

                if (N > 0)
                {
                    int[] res = task3.array(N, a, b);

                    for (int i = 0; i < res.Length; i++)
                    {
                        Console.Write("{0} ", res[i]);
                    }
                }
                else
                {
                    Console.WriteLine("Массива не может быть отрицательным. попробуйте еще раз...");
                    goto m3;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message.ToString());
                goto m3;
            }

            //В вещественном массиве известны данные о количестве осадков, выпавших за каждый день месяца N (N - любой месяц в году).
            //Найти общее число осадков, выпавших по четным числам месяца.
            //Предоставить возможность пользователю реализовать заполнение элементов массива случайными (рандомными) числами.
            ClassLibrary2.task4 task4 = new task4();
        m4:
            try
            {
                Console.WriteLine("Задание 4");
                Console.Write("Введите длинну массива: ");
                int N = Convert.ToInt32(Console.ReadLine());

                if (N <= 12 && N >= 1)
                {
                    int res = task4.osad(N);
                    Console.WriteLine("Общее кол-во осадков = {0}", res);
                }
                else
                {
                    Console.WriteLine("Вы ввели не месяц. Попробуйте еще раз...");
                    goto m4;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message.ToString());
                goto m4;
            }

        //Дан целочисленный массив, состоящий из N элементов и целые числа K и L (1 ≤ K ≤ L ≤ N).
        //Найти среднее арифметическое элементов массива с номерами от K до L включительно.
        m5:
            try
            {

                Console.WriteLine("Задание 5");
                Console.Write("Введите длинну массива: ");
                int N = Convert.ToInt32(Console.ReadLine());

                if (N > 0)
                {

                }
                else
                {
                    Console.WriteLine("Массива не может быть отрицательным. попробуйте еще раз...");
                    goto m3;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message.ToString());
                goto m5;
            }
        }
    }
}
