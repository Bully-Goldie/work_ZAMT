﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary2
{
    public class task5
    {
        public int zadanie5(int N, int K, int L)
        {
            Random random = new Random();
            int[] arr = new int[N];

            for (int i = 0; i < N; i++)
            {
                arr[i] = random.Next(50);
            }

            int res = 0;

            for
        }
    }
}
