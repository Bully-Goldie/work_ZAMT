﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary2
{
    public class task2
    {
        public int metr(int L)
        {
            return L / 100;
        }
    }
}
