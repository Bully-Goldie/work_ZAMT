﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary2
{
    public class task4
    {
        public int osad(int N)
        {
            Random random = new Random();
            int[] array = new int[N];
            int chot = 0;

            for (int i = 0; i < array.Length; i++)
            {
                array[i] = random.Next(50);

                if (array[i] % 2 == 0)
                {
                    chot += array[i];
                }
            }
            return chot;
        }
    }
}
