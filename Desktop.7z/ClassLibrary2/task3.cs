﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary2
{
    public class task3
    {
        public int[] array(int N, int a, int b)
        {
            Random random = new Random();

            int[] arr = new int[N];

            for (int i = 0; i < N; i++)
            {
                arr[i] = random.Next(50);
            }

            int[] arr2 = new int[b-a];
            for (int i = a+1; i < b; i++)
            {
                arr2[i] += arr[i];
            }
            return arr2;
        }
    }
}
