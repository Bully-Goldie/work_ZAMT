function sendMessage(user) {
    const textarea = document.getElementById(user);
    const text = textarea.value.trim();
    if (!text) return;

    const msg = document.createElement('div');
    msg.className = `message ${user}`;
    msg.textContent = text;

    document.getElementById('chat').appendChild(msg);
    textarea.value = '';
}

function clearChat() {
    document.getElementById('chat').innerHTML = '';
}

function setTheme(theme) {
    document.body.className = theme;
}
