function getTime() {
    const d = new Date();
    return d.getFullYear() + '-' +
        String(d.getMonth()+1).padStart(2,'0') + '-' +
        String(d.getDate()).padStart(2,'0') + ' ' +
        String(d.getHours()).padStart(2,'0') + ':' +
        String(d.getMinutes()).padStart(2,'0') + ':' +
        String(d.getSeconds()).padStart(2,'0');
}

function sendMessage(user) {
    const textarea = document.getElementById(user);
    const text = textarea.value; // даже пустые
    textarea.value = '';

    const msg = document.createElement('div');
    msg.className = 'message ' + user;

    const content = document.createElement('div');
    content.textContent = text;

    const time = document.createElement('div');
    time.className = 'time';
    time.textContent = getTime();

    msg.appendChild(content);
    msg.appendChild(time);

    const chat = document.getElementById('chat');
    chat.prepend(msg); // новое сообщение в начало
}

function clearChat() {
    document.getElementById('chat').innerHTML = '';
}

function removeFirst() {
    const chat = document.getElementById('chat');
    if (chat.lastChild) chat.removeChild(chat.lastChild);
}

function removeLast() {
    const chat = document.getElementById('chat');
    if (chat.firstChild) chat.removeChild(chat.firstChild);
}
