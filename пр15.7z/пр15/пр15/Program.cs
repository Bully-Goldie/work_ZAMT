﻿using System;
using System.Collections.Concurrent;
using System.Runtime.InteropServices;

namespace пр15
{
    class Car
    {
        public string stamp;
        public int cylinders;
        public int power;

        public void Original()
        {
            Console.WriteLine("=================================");
            Console.WriteLine($"Торговая марка автомобиля - {stamp}");
            Console.WriteLine($"Число цилиндров - {cylinders}");
            Console.WriteLine($"Мощность - {power}");
            Console.WriteLine("=================================");
        }

        public void Remake()
        {
            Console.WriteLine("=================================");
            Console.WriteLine($"Торговая марка автомобиля - {stamp}");
            Console.WriteLine($"Число цилиндров - {cylinders}");
            Console.WriteLine($"Измененная мощность - {power}");
            Console.WriteLine("=================================");
        }
    }

    class Lorry : Car
    {
        public int Load_capacity;

        public void Remake2()
        {
            Console.WriteLine("=================================");
            Console.WriteLine($"Торговая марка автомобиля - {stamp}");
            Console.WriteLine($"Число цилиндров - {cylinders}");
            Console.WriteLine($"Мощность - {power}");
            Console.WriteLine($"Грузоподъемностью кузова - {Load_capacity}");
            Console.WriteLine("=================================");
        }
    }

    class Liquid
    {
        public string name;
        public int density;

        public void Original()
        {
            Console.WriteLine("=================================");
            Console.WriteLine($"Название жидкости - {name}");
            Console.WriteLine($"Плотность жидкости - {density}");
            Console.WriteLine("=================================");
        }

        public void Remake()
        {
            Console.WriteLine("=================================");
            Console.WriteLine($"Название жидкости - {name}");
            Console.WriteLine($"Изменённая плотность жидкости - {density}");
            Console.WriteLine("=================================");
        }
    }

    class Alcohol : Liquid
    {
        public int strength;

        public void Remake2()
        {
            Console.WriteLine("=================================");
            Console.WriteLine($"Название жидкости - {name}");
            Console.WriteLine($"Плотность жидкости - {density}");
            Console.WriteLine($"Крепкость жидкости - {strength}");
            Console.WriteLine("=================================");
        }

        public void Remake3()
        {
            Console.WriteLine("=================================");
            Console.WriteLine($"Название жидкости - {name}");
            Console.WriteLine($"Плотность жидкости - {density}");
            Console.WriteLine($"Измененная крепкость жидкости - {strength}");
            Console.WriteLine("=================================");
        }
    }
    
    class Man
    {
        public string fname;
        public string lname;
        public int age;
        public string gender;
        public int weight;

        public void Original()
        {
            Console.WriteLine($"Имя - {fname}");
            Console.WriteLine($"Фамилия - {lname}");
            Console.WriteLine($"Возраст - {age}");
            Console.WriteLine($"Пол - {gender}");
            Console.WriteLine($"Вес - {weight}");
        }

        public void Remake()
        {
            Console.WriteLine($"Измененное имя - {fname}");
            Console.WriteLine($"Фамилия - {lname}");
            Console.WriteLine($"Измененный возраст - {age}");
            Console.WriteLine($"Пол - {gender}");
            Console.WriteLine($"Измененный вес - {weight}");
        }
    }

    class Student : Man
    {
        public string year;
        public string specialization;

        public void Remake2()
        {
            Console.WriteLine($"Года обучения - {year}");
            Console.WriteLine($"Специализация - {specialization}");
        }

        public void Remake3()
        {
            Console.WriteLine($"Увеличенные года обучения - {year}");
            Console.WriteLine($"Специализация - {specialization}");
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
        // Задание 1
        // Создать базовый класс Саr (машина), характеризуемый торговой маркой (строка), числом цилиндров, мощностью.
        // Определить методы переназначения и изменения мощности.
        // Создать производный класс Lorry (грузовик), характеризуемый грузоподъемностью кузова. Определить функции переназначения марки и изменения грузоподъемности.
        m1:
            try
            {
                Console.WriteLine("Задание 1");
                Lorry car = new Lorry();

                Console.Write("Введите торговую марку машины: ");
                string stamp = Console.ReadLine();

                Console.Write("Введите число цилиндров машины: ");
                int cylinders = Convert.ToInt32(Console.ReadLine());

                Console.Write("Введите мощность машины: ");
                int power = Convert.ToInt32(Console.ReadLine());

                car.stamp = stamp;
                car.cylinders = cylinders;
                car.power = power;
                car.Original();
                Console.WriteLine();

                Console.Write("Введите новую мощность машины: ");
                int power2 = Convert.ToInt32(Console.ReadLine());

                car.power = power2;
                car.Remake();
                Console.WriteLine();

                Console.Write("Введите новую торговую марку машины: ");
                string stamp2 = Console.ReadLine();
                Console.Write("Введите грузоподъемностью кузова: ");
                int Load_capacity = Convert.ToInt32(Console.ReadLine());

                car.stamp = stamp2;
                car.Load_capacity = Load_capacity;
                car.Remake2();
                Console.WriteLine();
            }
            catch (FormatException ex1)
            {
                Console.WriteLine(ex1.Message.ToString());
                goto m1;
            }
            catch (OverflowException ex2)
            {
                Console.WriteLine(ex2.Message.ToString());
                goto m1;
            }

        // Задание 2
        // Создать класс Liquid (жидкость), имеющий поля названия и плотности.
        // Определить методы переназначения и изменения плотности.
        // Создать производный класс Alcohol (спирт), имеющий крепость. Определить методы переназначения и изменения крепости.
        m2:
            try
            {
                Console.WriteLine("Задание 2");

                Alcohol liq = new Alcohol();

                Console.Write("Введите название жидкости: ");
                string name = Console.ReadLine();

                Console.Write("Введите плотность жидкости: ");
                int density = Convert.ToInt32(Console.ReadLine());

                liq.name = name;
                liq.density = density;
                liq.Original();
                Console.WriteLine();

                Console.Write("Введите измененную плотность жидкости: ");
                int density2 = Convert.ToInt32(Console.ReadLine());
                liq.density = density2;
                liq.Remake();
                Console.WriteLine();

                Console.Write("Введите крепкость жидкости: ");
                int strength = Convert.ToInt32(Console.ReadLine());

                liq.strength = strength;
                liq.Remake2();
                Console.WriteLine();

                Console.Write("Введите изменённую крепкость жидкости: ");
                int strength2 = Convert.ToInt32(Console.ReadLine());

                liq.strength = strength2;
                liq.Remake3();
                Console.WriteLine();
            }
            catch (FormatException ex1)
            {
                Console.WriteLine(ex1.Message.ToString());
                goto m2;
            }
            catch (OverflowException ex2)
            {
                Console.WriteLine(ex2.Message.ToString());
                goto m2;
            }

        // Задание 3
        // Создать класс Man (человек), с полями: имя, фамилия, возраст, пол и вес.
        // Определить методы переназначения имени, изменения возраста и изменения веса.
        // Создать производный класс Student, имеющий поля года обучения и специальность обучения.
        // Определить методы переназначения и увеличения года обучения.
        m3:
            try
            {
                Console.WriteLine("Задание 3");

                Student man = new Student();

                Console.Write("Введите имя: ");
                string fname = Console.ReadLine();

                Console.Write("Введите фамилию: ");
                string lname = Console.ReadLine();

                Console.Write("Введите возраст: ");
                int age  = Convert.ToInt32(Console.ReadLine());

                Console.Write("Введите пол: ");
                string gender = Console.ReadLine();

                Console.Write("Введите вес: ");
                int weight = Convert.ToInt32(Console.ReadLine());

                man.fname = fname;
                man.lname = lname;
                man.age = age;
                man.gender = gender;
                man.weight = weight;
                man.Original();

                Console.Write("Введите новое имя: ");
                string fname1 = Console.ReadLine();

                Console.Write("Введите измененный возраст: ");
                int age1 = Convert.ToInt32(Console.ReadLine());

                Console.Write("Введите измененный вес: ");
                int weight1 = Convert.ToInt32(Console.ReadLine());
                
                man.fname = fname1;
                man.age = age1;
                man.weight = weight;
                man.Remake();

                Console.Write("Введите годы обучения: ");
                string year = Console.ReadLine();

                Console.Write("Введите специализацию: ");
                string specialization = Console.ReadLine();

                man.year = year;
                man.specialization = specialization;
                man.Remake2();

                Console.Write("Введите измененные года обучения: ");
                string year2 = Console.ReadLine();
                man.year= year2;
                man.Remake3();
            }
            catch (FormatException ex1)
            {
                Console.WriteLine(ex1.Message.ToString());
                goto m3;
            }
            catch (OverflowException ex2)
            {
                Console.WriteLine(ex2.Message.ToString());
                goto m3;
            }
        }
    }
}
