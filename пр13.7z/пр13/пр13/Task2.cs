﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace var10
{
    class Task2
    {
        public (int sum, long res) Sum(int[] array)
        {
            int sum = 0;
            long res = 1;

            foreach (int number in array)
            {
                sum += number;
                res *= number;
            }

            return (sum, res);
        }
        public (double sum, double res) Sum(double[] array)
        {
            double sum = 0.0;
            double res = 1.0;

            foreach (double number in array)
            {
                sum += number;
                res *= number;
            }

            return (sum, res);
        }
        public (float sum, float res) Sum(float[] array)
        {
            float sum = 0.0f;
            float res = 1.0f;

            foreach (float number in array)
            {
                sum += number;
                res *= number;
            }

            return (sum, res);
        }
        public (long sum, long res) Sum(long[] array)
        {
            long sum = 0;
            long res = 1;

            foreach (long number in array)
            {
                sum += number;
                res *= number;
            }

            return (sum, res);
        }
        public (decimal sum, decimal res) Sum(decimal[] array)
        {
            decimal sum = 0.0m;
            decimal res = 1.0m;

            foreach (decimal number in array)
            {
                sum += number;
                res *= number;
            }

            return (sum, res);
        }
    }
}
