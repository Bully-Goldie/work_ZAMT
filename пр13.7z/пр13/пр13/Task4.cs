﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace var10
{
    class Task4
    {
        public bool IsSquare(int K)
        {
            if (K <= 0) return false;
            int sqrt = (int)Math.Sqrt(K);
            return sqrt * sqrt == K;
        }
        public bool IsSquare(long K)
        {
            if (K <= 0) return false;
            long sqrt = (long)Math.Sqrt(K);
            return sqrt * sqrt == K;
        }
        public bool IsSquare(float K)
        {
            if (K <= 0) return false;
            int sqrt = (int)Math.Sqrt(K);
            return sqrt * sqrt == K;
        }
        public bool IsSquare(double K)
        {
            if (K <= 0) return false;
            int sqrt = (int)Math.Sqrt(K);
            return sqrt * sqrt == K;
        }
        public bool IsSquare(decimal K)
        {
            if (K <= 0) return false;
            int sqrt = (int)Math.Sqrt((double)K);
            return sqrt * sqrt == K;
        }
    }
}
