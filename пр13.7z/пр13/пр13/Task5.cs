﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace var10
{
    class Task5
    {
        public string tochka(string str)
        {
            return tochka(str, '.');
        }
        public string tochka(string str, char delimiter)
        {
            int firstIndex = str.IndexOf(delimiter);
            int secondIndex = str.IndexOf(delimiter, firstIndex + 1);

            if (firstIndex == -1 || secondIndex == -1)
            {
                return str;
            }

            return str.Substring(firstIndex + 1, secondIndex - firstIndex - 1).Trim();
        }
        public string tochka(string[] strings)
        {
            if (strings.Length == 0) return string.Empty;
            return tochka(strings[0]);
        }
        public string tochka(string[] strings, char delimiter)
        {
            if (strings.Length == 0) return string.Empty;
            return tochka(strings[0], delimiter);
        }
        public string tochka(char delimiter, params string[] strings)
        {
            if (strings.Length == 0) return string.Empty;
            return tochka(strings[0], delimiter);
        }
    }
}
