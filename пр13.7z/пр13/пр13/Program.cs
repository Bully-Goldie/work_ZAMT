﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using var10;

namespace пр13
{
    class Program
    {
        static void Main(string[] args)
        {
        //Задание 1
        //Дано целое число N (N > 0).
        //Если N - нечетное, то вывести произведение нечетных чисел до этого числа (1*3*5*N);
        //если N - четное, то вывести произведение четных чисел до этого числа (2*4*6*N).
        //Чтобы избежать целочисленного переполнения, вычислять это выражение с помощью вещественной переменной и выводить его как вещественное число.
        //(Пример, 6=2*4*6; 9=1*3*5*7*9).
        m1:
            try
            {
                Console.WriteLine("Задание 1");
                Console.Write("Введите целое положительное число: ");
                int N = Convert.ToInt32(Console.ReadLine());

                Task1 Composition = new Task1();
                double res;

                if (N > 0)
                {
                    if (N % 2 == 0)
                    {
                        res = Composition.Composition(N);
                    }
                    else
                    {
                        res = Composition.Composition((double) N);
                    }
                    Console.WriteLine(res);
                }
                else
                {
                    Console.WriteLine("Вы ввели число меньше 0. Попробуйте еще раз...");
                    goto m1;
                }
            }
            catch (FormatException ex1)
            {
                Console.WriteLine(ex1.Message.ToString());
                goto m1;
            }
            catch (OverflowException ex2)
            {
                Console.WriteLine(ex2.Message.ToString());
                goto m1;
            }

        // Задание 2
        // Дан целочисленный массив, состоящий из N элементов (N > 0). Найти сумму и произведение всех чисел из данного массива.
        m2:
            try
            {
                Console.WriteLine("Задание 1");
                Console.Write("Введите длину массива: ");
                int N = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Введите число 1 чтобы массив заполнился рандомными числами или 2 чтобы заполнить массив с клавиатуры:");
                int A = Convert.ToInt32(Console.ReadLine());

                Task2 array2 = new Task2();

                if (N > 0)
                {
                    int[] array = new int[N];
                m21:
                    switch (A)
                    {
                        case 1:
                            {
                                Random random = new Random();
                                for (int i = 0; i < array.Length; i++)
                                {
                                    array[i] = random.Next(50);
                                }
                            }
                            break;

                        case 2:
                            {
                                int i = 0;
                                while (i < N)
                                {
                                    array[i] = Convert.ToInt32(Console.ReadLine());
                                    Console.WriteLine();
                                    i++;
                                }
                            }
                            break;

                        default:
                            Console.WriteLine("Вы введи не 1 и не 2. Попробуйте еще раз...");
                            goto m21;
                    }

                    var res = array2.Sum(array);

                    Console.WriteLine("Сумма: {0}, Произведение: {1}", res.sum, res.res);
                }
                else
                {
                    Console.WriteLine("Вы ввели длину массива меньше 0. Попробуйте еще раз...");
                    goto m2;
                }
            }
            catch (FormatException ex1)
            {
                Console.WriteLine(ex1.Message.ToString());
                goto m2;
            }
            catch (OverflowException ex2)
            {
                Console.WriteLine(ex2.Message.ToString());
                goto m2;
            }

        // Задание 3
        // Написать функцию int Quarter(X, Y) целого типа, определяющую номер координатной четверти,
        // в которой находится точка с ненулевыми целыми координатами (X, Y).
        m3:
            try
            {
                Console.WriteLine("Задание 3");
                Console.Write("Введи первую целую точку: ");
                int X = Convert.ToInt32(Console.ReadLine());
                Console.Write("Введи вторую целую точку: ");
                int Y = Convert.ToInt32(Console.ReadLine());

                Task3 coordinate = new Task3();

                int res = coordinate.Quarter(X, Y);

                Console.WriteLine("Номер координатной четверти - {0}" ,res);
            }
            catch (FormatException ex1)
            {
                Console.WriteLine(ex1.Message.ToString());
                goto m3;
            }
            catch (OverflowException ex2)
            {
                Console.WriteLine(ex2.Message.ToString());
                goto m3;
            }

        // Задание 4
        // Написать функцию bool IsSquare(K) логического типа, возвращающую True, если целый параметр K (K > 0)
        // является квадратом некоторого целого числа, и False в противном случае.

        m4:
            try
            {
                Console.WriteLine("Задание 4");
                Console.Write("Введите число: ");
                int K = Convert.ToInt32(Console.ReadLine());

                Task4 logic = new Task4();

                bool res = logic.IsSquare(K);

                Console.WriteLine(res);
            }
            catch (FormatException ex1)
            {
                Console.WriteLine(ex1.Message.ToString());
                goto m4;
            }
            catch (OverflowException ex2)
            {
                Console.WriteLine(ex2.Message.ToString());
                goto m4;
            }

        // Задание 5
        // Вводится строка, состоящая из слов разделенных точками. Длина строки может быть разной.
        // Сформировать и вывести подстроку, расположенную между первой и второй точками исходной строки.
        // Если в строке менее двух точек, то вывести всю исходную строку.

        m5:
            try
            {
                Console.WriteLine("Задание 5");
                Console.Write("Введите строку состоящую из слов разделительным знаком '.': ");
                string str = Console.ReadLine();

                Task5 tochka = new Task5();

                string res = tochka.tochka(str);

                Console.WriteLine(res);
            }
            catch (FormatException ex1)
            {
                Console.WriteLine(ex1.Message.ToString());
                goto m5;
            }
            catch (OverflowException ex2)
            {
                Console.WriteLine(ex2.Message.ToString());
                goto m5;
            }
        }
    }
}
