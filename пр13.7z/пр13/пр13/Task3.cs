﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace var10
{
    class Task3
    {
        public int Quarter(int X, int Y)
        {
            if (X > 0 && Y > 0) return 1;
            if (X < 0 && Y > 0) return 2;
            if (X < 0 && Y < 0) return 3;
            if (X > 0 && Y < 0) return 4;

            return 0;
        }
        public int Quarter(float X, float Y)
        {
            if (X > 0 && Y > 0) return 1;
            if (X < 0 && Y > 0) return 2;
            if (X < 0 && Y < 0) return 3;
            if (X > 0 && Y < 0) return 4;

            return 0;
        }
        public int Quarter(double X, double Y)
        {
            if (X > 0 && Y > 0) return 1;
            if (X < 0 && Y > 0) return 2;
            if (X < 0 && Y < 0) return 3;
            if (X > 0 && Y < 0) return 4;

            return 0;
        }
        public int Quarter(long X, long Y)
        {
            if (X > 0 && Y > 0) return 1;
            if (X < 0 && Y > 0) return 2;
            if (X < 0 && Y < 0) return 3;
            if (X > 0 && Y < 0) return 4;

            return 0;
        }
        public int Quarter(decimal X, decimal Y)
        {
            if (X > 0 && Y > 0) return 1;
            if (X < 0 && Y > 0) return 2;
            if (X < 0 && Y < 0) return 3;
            if (X > 0 && Y < 0) return 4;

            return 0;
        }
    }
}
