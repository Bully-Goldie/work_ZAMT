﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace var10
{
    class Task1
    {
        public double Composition(int N)
        {
            double res1 = 1.0;

            if (N % 2 == 0)
            {
                for (int i = 2; i <= N; i += 2)
                {
                    res1 *= i;
                }
            }
            else
            {
                for (int i = 1; i <= N; i += 2)
                {
                    res1 *= i;
                }
            }

            return res1;
        }

        public double Composition(double N)
        {
            double res1 = 1.0;

            if (N % 2 == 0)
            {
                for (int i = 2; i <= N; i += 2)
                {
                    res1 *= i;
                }
            }
            else
            {
                for (int i = 1; i <= N; i += 2)
                {
                    res1 *= i;
                }
            }

            return res1;
        }

        public double Composition(float N)
        {
            return Composition((int)N);
        }
        public double Composition(long N)
        {
            return Composition((double)N);
        }
        public double Composition(decimal N)
        {
            return Composition((int)N);
        }
    }
}
