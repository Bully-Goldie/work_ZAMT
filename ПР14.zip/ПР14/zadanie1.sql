BEGIN;
UPDATE balls
SET ball = ball - 2 - 1 + 3
WHERE name = 'Сергей';
UPDATE balls
SET ball = ball + 1
WHERE name = 'Илья';
COMMIT;
SELECT SUM(ball) FROM balls;