UPDATE balls
SET ball = ball - 2
WHERE name = 'Сергей';

BEGIN;
UPDATE balls
SET ball = ball - 1
WHERE name = 'Сергей';
UPDATE balls
SET ball = ball + 1
WHERE name = 'Илья';
COMMIT;

UPDATE balls
SET ball = ball + 3
WHERE name = 'Сергей';

SELECT SUM(ball) FROM balls
WHERE name IN ('Сергей', 'Илья');