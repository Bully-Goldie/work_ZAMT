CREATE TABLE balls (id serial PRIMARY KEY NOT NULL, name varchar(50) NOT NULL, ball int NOT NULL);

INSERT INTO balls(name, ball) VALUES
('Сергей', 11),
('Илья', 0);