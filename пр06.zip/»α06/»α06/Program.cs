﻿// This is a personal academic project. Dear PVS-Studio, please check it.
// PVS-Studio Static Code Analyzer for C, C++, C#, and Java: https://pvs-studio.com

using System;
using System.Linq;


namespace пр06
{
    internal class Program
    {
        static void Main(string[] args)
        {
        #region ЗАДАНИЕ 1
        /* Задание 1
        Проверить истинность высказывания:
        "Цифры данного целого положительного четырехзначного числа образуют возрастающую последовательность"
        */
        m1:
            try
            {
                Console.WriteLine("Задание 1");
                Console.Write("Введите челое четырёхзначное положительное число: ");
                int N = Convert.ToInt32(Console.ReadLine());

                int four = (N / 1000) % 10;
                int trhee = (N / 100) % 10;
                int two = (N / 10) % 10;
                int one = N % 10;

                if (N > 999 && N <= 9999)
                {
                    if (trhee > four && two > trhee && one > two)
                    {
                        Console.WriteLine("Числа образуют возрастающую последовательность");
                    }
                    else
                    {
                        Console.WriteLine("Числа не образует возрастающую последовательность");
                    }
                }
                else
                {
                    Console.WriteLine("Вы ввели не четырехзначное число. Попробуйте еще раз...");
                    goto m1;
                }
            }
            catch (System.FormatException ex1)
            {
                Console.WriteLine("Ошибка! Вы ввели не число или же оно с плавующей точкой. {0}", ex1.Message.ToString());
                goto m1;
            }

            catch (System.OverflowException ex2)
            {
                Console.WriteLine("Ошибка! Значение недопустимо большое. {0}", ex2.Message.ToString());
                goto m1;
            }
        #endregion

        #region ЗАДАНИЕ 2
        /* Задание 2
        Из шести целых чисел найти наибольшее и наименьшее число, а так же среднее арифметическое этих введенных чисел.
        */
        m2:
            try
            {
                Console.WriteLine("Задание 2");
                Console.WriteLine("Введите шесть целых чисел: ");

                int[] array = new int[6];
                int i = 0;
                int arif = 0;

                while (i < 6)
                {
                    array[i] = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine();
                    i++;
                }

                int max = array.Max();
                int min = array.Min();
                Console.WriteLine("Максимальное значение {0}, Минимальное значение {1}", max, min);

                for (int j = 0; j < array.Length; j++)
                {
                    arif += array[j];
                }

                int res = arif / 6;
                Console.WriteLine("Среднее арифметическое данных чисел: {0}", res);
            }
            catch (System.FormatException ex1)
            {
                Console.WriteLine("Ошибка! Вы ввели не число или же оно с плавующей точкой. {0}", ex1.Message.ToString());
                goto m2;
            }

            catch (System.OverflowException ex2)
            {
                Console.WriteLine("Ошибка! Значение недопустимо большое. {0}", ex2.Message.ToString());
                goto m2;
            }
        #endregion

        #region ЗАДАНИЕ 3
        /* Задание 3
        Дан целочисленный массив, состоящий из N элементов (N > 0).
        Сложить со всеми нечетными числами максимальное четное число из этого массива. Вывести новый полученный массив.
        */
        m3:
            try
            {
                Console.WriteLine("Задание 3");
                Console.Write("Напишите длинну массива: ");
                int N = Convert.ToInt32(Console.ReadLine());

                if (N > 0)
                {
                    Console.Write("Введите 1 или 2 (1 - заполнить массив рандомными числами, 2 - заполнить массив с клавиотуры): ");
                    int A = Convert.ToInt32(Console.ReadLine());

                    int[] array = new int[N];
                m31:
                    switch (A)
                    {
                        case 1:
                            {
                                Random random = new Random();
                                for (int i = 0; i < array.Length; i++)
                                {
                                    array[i] = random.Next(-50, 50);
                                    Console.Write("{0} ", array[i]);
                                }
                                Console.WriteLine();
                                Console.WriteLine("=====================");
                            }
                            break;

                        case 2:
                            {
                                int i = 0;
                                while (i < N)
                                {
                                    array[i] = Convert.ToInt32(Console.ReadLine());
                                    Console.WriteLine();
                                    i++;
                                }
                            }
                            break;

                        default:
                            Console.WriteLine("Вы введи не 1 и не 2. Попробуйте еще раз...");
                            goto m31;
                    }

                    int max = array.Max();

                    for (int i = 0; i < array.Length; i++)
                    {
                        array[i] += max;
                        Console.Write("{0} ", array[i]);
                    }
                    Console.WriteLine();

                }
            }
            catch (System.FormatException ex1)
            {
                Console.WriteLine("Ошибка! Вы ввели не число или же оно с плавующей точкой. {0}", ex1.Message.ToString());
                goto m3;
            }

            catch (System.OverflowException ex2)
            {
                Console.WriteLine("Ошибка! Значение недопустимо большое. {0}", ex2.Message.ToString());
                goto m3;
            }
        #endregion

        #region ЗАДАНИЕ 4
        /* Задание 4
        Вводится строка, состоящая из слов разделенных точками. Длина строки может быть разной.
        Сформировать и вывести подстроку, расположенную между первой и второй точками исходной строки.
        Если в строке менее двух точек, то вывести всю исходную строку.
        */
        m4:
            Console.WriteLine("Задание 4");

            Console.WriteLine("Введите строку стостоящую из слов разделенными точками: ");
            string str = Console.ReadLine();

            bool proverka = false;
            int count3 = 0;

            char[] chararray = str.ToCharArray();

            for (int i = 0; i < chararray.Length; i++)
            {
                if (chararray[i] == '.')
                {
                    proverka = true;
                }
            }

            if (proverka)
            {
                for (int i = 0; i < chararray.Length; i++)
                {
                    if (chararray[i] == '.')
                    {
                        count3++;
                    }
                }
            }

            else
            {
                Console.WriteLine("Нету знаков '.'. Попробуйте еще раз...");
                goto m4;
            }

            int one1 = 0;
            int two1 = 0;

            int count4 = 0;

            for (int i = 0; i < chararray.Length; i++)
            {
                if (chararray[i] == '.')
                {
                    count4++;
                    if (count4 == 1)
                    {
                        one1 = i;
                    }
                    else if (count4 == 2)
                    {
                        two1 = i;
                        break;
                    }
                }
            }
            if (one1 != -1 && two1 != -1)
            {
                string res = str.Substring(one1 + 1, two1 - one1 - 1).Trim();
                Console.WriteLine("Подстрока между первой и второй '.': {0}", res);
            }

            if (count3 < 2)
            {
                Console.WriteLine("Меньше трех '.': {0}", str);
            }
            #endregion

        #region ЗАДАНИЕ 5
            /* Задание 5 из варианта 26
            Вводится строка, состоящая из слов, разделенных подчеркиваниями (одним или несколькими).
            Длина строки может быть разной. Преобразовать в строке все строчные буквы (как латинские, так и русские)
            в прописные, а прописные — в строчные(мин).
            */

            Console.WriteLine("Задание 5");

            Console.WriteLine("Введите строку которая разделена подчеркиваниями: ");
            string str2 = Console.ReadLine();

            string[] chararray2 = str2.Split(new char[] { '_' }, StringSplitOptions.RemoveEmptyEntries);

            for (int i = 0; i < chararray2.Length; i++)
            {
                char[] charArray = chararray2[i].ToCharArray();
                for (int j = 0; j < charArray.Length; j++)
                {
                    if (char.IsLower(charArray[j]))
                    {
                        charArray[j] = char.ToUpper(charArray[j]);
                    }
                    else if (char.IsUpper(charArray[j]))
                    {
                        charArray[j] = char.ToLower(charArray[j]);
                    }
                }
                chararray2[i] = new string(charArray);
            }

            Console.WriteLine(string.Join("_", chararray2));
            #endregion
        }
    }
}
