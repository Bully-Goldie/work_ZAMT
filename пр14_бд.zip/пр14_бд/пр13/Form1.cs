﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using пр13.Forms;

namespace пр13
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            CreateAttribute open = new CreateAttribute();
            this.Visible = false;
            open.ShowDialog();

            this.Visible = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ViewСontent open = new ViewСontent();
            this.Visible = false;
            open.ShowDialog();

            this.Visible = true;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Backup open = new Backup();
            this.Visible = false;
            open.ShowDialog();

            this.Visible = true;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
