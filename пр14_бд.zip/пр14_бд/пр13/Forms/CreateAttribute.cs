﻿using MySql.Data.MySqlClient;
using System;
using System.Data;
using System.Windows.Forms;

namespace пр13
{
    public partial class CreateAttribute : Form
    {
        string str = @"host=localhost;uid=root;pwd=root;database=pr13_Kichigin;";

        string command = @"SELECT 
                        bo.id_operation,
                        CONCAT_WS(' ', cb.last_name, cb.first_name, cb.middle_name) AS client_fio,
                        bo.credit_amount AS credit_amount,
                        be.percent AS credit_percent,
                        bo.date_take AS `Дата заёма`,
                        bo.date_return AS `Дата возврата`
                    FROM bank_operations bo
                    INNER JOIN client_bank cb ON bo.id_client = cb.id_client
                    INNER JOIN bank_employee be ON bo.id_service = be.id_service;";

        public CreateAttribute()
        {
            InitializeComponent();
            dateTimePicker1.MinDate = DateTime.Now;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        string commandEmployees = @"SELECT id_service, 
                                    CONCAT_WS(' ', last_name, first_name, middle_name) AS employee_fio,
                                    department,
                                    percent
                                    FROM bank_employee;";

        string commandClients = @"SELECT id_client, 
                                  CONCAT_WS(' ', last_name, first_name, middle_name) AS client_fio
                                  FROM client_bank;";

        private void CreateAttribute_Load(object sender, EventArgs e)
        {
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

            try
            {
                MySqlConnection con = new MySqlConnection(str);
                con.Open();

                MySqlCommand cmd = new MySqlCommand(command, con);
                MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;

                dataGridView1.Columns["client_fio"].HeaderText = "ФИО клиента";
                dataGridView1.Columns["credit_amount"].HeaderText = "Сумма заёма";
                dataGridView1.Columns["credit_percent"].HeaderText = "Процент кредита";
                dataGridView1.Columns["id_operation"].Visible = false;

                MySqlCommand cmdEmployees = new MySqlCommand(commandEmployees, con);
                MySqlDataAdapter daEmployees = new MySqlDataAdapter(cmdEmployees);
                DataTable dtEmployees = new DataTable();
                daEmployees.Fill(dtEmployees);

                comboBox1.DataSource = dtEmployees;
                comboBox1.DisplayMember = "employee_fio";
                comboBox1.ValueMember = "id_service";
                comboBox1.SelectedIndex = -1;

                MySqlCommand cmdClients = new MySqlCommand(commandClients, con);
                MySqlDataAdapter daClients = new MySqlDataAdapter(cmdClients);
                DataTable dtClients = new DataTable();
                daClients.Fill(dtClients);

                comboBox2.DataSource = dtClients;
                comboBox2.DisplayMember = "client_fio";
                comboBox2.ValueMember = "id_client";
                comboBox2.SelectedIndex = -1;

                comboBox1.DropDownStyle = ComboBoxStyle.DropDownList;
                comboBox2.DropDownStyle = ComboBoxStyle.DropDownList;

                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка подключения к БД: {ex.Message}");
            }
        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !(Char.IsDigit(e.KeyChar) || e.KeyChar == (char)Keys.Back);
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !(Char.IsDigit(e.KeyChar) || e.KeyChar == (char)Keys.Back || e.KeyChar == '.');
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MySqlConnection con = new MySqlConnection(str);

            try
            {
                con.Open();

                string sum = textBox3.Text;
                string date_take = DateTime.Now.ToString("yyyy-MM-dd");
                DateTime date = dateTimePicker1.Value;
                string date_return = date.ToString("yyyy-MM-dd");
                string percent = textBox2.Text;

                if (comboBox2.SelectedIndex == -1)
                {
                    MessageBox.Show("Выберите клиента из списка!");
                    con.Close();
                    return;
                }

                if (comboBox1.SelectedIndex == -1)
                {
                    MessageBox.Show("Выберите сотрудника из списка!");
                    con.Close();
                    return;
                }

                if (string.IsNullOrEmpty(sum) || string.IsNullOrEmpty(percent))
                {
                    MessageBox.Show("Заполните все поля!");
                    con.Close();
                    return;
                }

                int clientId = Convert.ToInt32(comboBox2.SelectedValue);
                int employeeId = Convert.ToInt32(comboBox1.SelectedValue);

                decimal creditSum = Convert.ToDecimal(sum);
                decimal creditPercent = Convert.ToDecimal(percent);

                string updateClientSum = "UPDATE client_bank SET sum = sum + @sum WHERE id_client = @clientId";
                MySqlCommand cmdUpdate = new MySqlCommand(updateClientSum, con);
                cmdUpdate.Parameters.AddWithValue("@sum", creditSum);
                cmdUpdate.Parameters.AddWithValue("@clientId", clientId);
                cmdUpdate.ExecuteNonQuery();

                string updateEmployeePercent = "UPDATE bank_employee SET percent = @percent WHERE id_service = @employeeId";
                MySqlCommand cmdUpdateEmployee = new MySqlCommand(updateEmployeePercent, con);
                cmdUpdateEmployee.Parameters.AddWithValue("@percent", creditPercent);
                cmdUpdateEmployee.Parameters.AddWithValue("@employeeId", employeeId);
                cmdUpdateEmployee.ExecuteNonQuery();

                string insertOperation = @"INSERT INTO bank_operations(id_service, id_client, credit_amount, date_take, date_return) 
                         VALUES (@serviceId, @clientId, @credit_amount, @date_take, @date_return)";

                MySqlCommand cmdOperation = new MySqlCommand(insertOperation, con);
                cmdOperation.Parameters.AddWithValue("@serviceId", employeeId);
                cmdOperation.Parameters.AddWithValue("@clientId", clientId);
                cmdOperation.Parameters.AddWithValue("@credit_amount", creditSum);
                cmdOperation.Parameters.AddWithValue("@date_take", date_take);
                cmdOperation.Parameters.AddWithValue("@date_return", date_return);
                cmdOperation.ExecuteNonQuery();

                MessageBox.Show("Кредит успешно оформлен!");

                MySqlCommand cmd2 = new MySqlCommand(command, con);
                MySqlDataAdapter da = new MySqlDataAdapter(cmd2);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;

                textBox3.Text = "";
                textBox2.Text = "";
                dateTimePicker1.Value = DateTime.Now;
                comboBox1.SelectedIndex = -1;
                comboBox2.SelectedIndex = -1;

                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }
    }
}