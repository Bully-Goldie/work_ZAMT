﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace пр13
{
    public partial class CreateAttribute : Form
    {
        string str = @"host=localhost;
                        uid=root;
                        pwd=root;
                        database=pr13_Kichigin;";

        string command = @"SELECT 
                        bo.id_employee,
                        CONCAT_WS(' ', cb.last_name, cb.first_name, cb.middle_name) AS client_fio,
                        cb.sum AS credit_amount,
                        be.percent AS credit_percent,
                        bo.date_take AS `Дата заёма`,
                        bo.date_return AS `Дата возврата`
                    FROM bank_operations bo
                    INNER JOIN client_bank cb ON bo.id_client = cb.id_client
                    INNER JOIN bank_employee be ON bo.id_service = be.id_service;";
        public CreateAttribute()
        {
            InitializeComponent();
            dateTimePicker1.MinDate = DateTime.Now;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        string commandReaders = "SELECT * FROM bank_employee;";
        private void CreateAttribute_Load(object sender, EventArgs e)
        {
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            try
            {
                MySqlConnection con = new MySqlConnection(str);
                con.Open();

                MySqlCommand cmd = new MySqlCommand(command, con);
                MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                DataTable dt = new DataTable();

                da.Fill(dt);
                dataGridView1.DataSource = dt;

                dataGridView1.Columns["client_fio"].HeaderText = "ФИО клиента";
                dataGridView1.Columns["credit_amount"].HeaderText = "Сумма заёма";
                dataGridView1.Columns["credit_percent"].HeaderText = "Процент кредита";

                dataGridView1.Columns["id_employee"].Visible = false;

                MySqlCommand cmd2 = new MySqlCommand(commandReaders, con);
                MySqlDataReader rdr = cmd2.ExecuteReader();

                while (rdr.Read())
                {
                    comboBox1.Items.Add($"{rdr["last_name"]} {rdr["first_name"]} {rdr["middle_name"]}");
                }

                con.Close();
            }
            catch (Exception)
            {
                MessageBox.Show("Вы не подключились к БД!");
            }
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;

            if ((ch >= 'А' && ch <= 'я') || ch == (char)Keys.Back || ch == (char)Keys.Space)
            {
                e.Handled = false;

                return;
            }

            e.Handled = true;
        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = Char.IsDigit(e.KeyChar) || e.KeyChar == (char)Keys.Back ? false : true;
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = Char.IsDigit(e.KeyChar) || e.KeyChar == (char)Keys.Back || e.KeyChar == '.' ? false : true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MySqlConnection con = new MySqlConnection(str);

            try
            {
                con.Open();

                string passport = maskedTextBox1.Text;
                string sum = textBox3.Text;
                string date_take = DateTime.Now.ToString("yyyy-MM-dd");
                DateTime date = dateTimePicker1.Value;
                string date_return = date.ToString("yyyy-MM-dd");
                string fio_client = textBox1.Text;
                string[] parts = fio_client.Split(' ');
                string lastName = parts.Length > 0 ? parts[0] : "";
                string firstName = parts.Length > 1 ? parts[1] : "";
                string middleName = parts.Length > 2 ? parts[2] : "";
                string department = comboBox2.Text;
                string percent = textBox2.Text;
                string fio_employee = comboBox1.Text;
                string[] parts_employee = fio_employee.Split(' ');
                string lastName_employee = parts_employee.Length > 0 ? parts_employee[0] : "";
                string firstName_employee = parts_employee.Length > 1 ? parts_employee[1] : "";
                string middleName_employee = parts_employee.Length > 2 ? parts_employee[2] : "";

                string insertClient = @"INSERT INTO client_bank(last_name, first_name, middle_name, passport, sum) 
                              VALUES (@lastName, @firstName, @middleName, @passport, @sum)";
                MySqlCommand cmdClient = new MySqlCommand(insertClient, con);
                cmdClient.Parameters.AddWithValue("@lastName", lastName);
                cmdClient.Parameters.AddWithValue("@firstName", firstName);
                cmdClient.Parameters.AddWithValue("@middleName", middleName);
                cmdClient.Parameters.AddWithValue("@passport", passport);
                cmdClient.Parameters.AddWithValue("@sum", sum);
                cmdClient.ExecuteNonQuery();
                long clientId = cmdClient.LastInsertedId;

                string insertEmployee = @"INSERT INTO bank_employee(last_name, first_name, middle_name, department, percent) 
                                VALUES (@lastName_emp, @firstName_emp, @middleName_emp, @department, @percent)";
                MySqlCommand cmdEmployee = new MySqlCommand(insertEmployee, con);
                cmdEmployee.Parameters.AddWithValue("@lastName_emp", lastName_employee);
                cmdEmployee.Parameters.AddWithValue("@firstName_emp", firstName_employee);
                cmdEmployee.Parameters.AddWithValue("@middleName_emp", middleName_employee);
                cmdEmployee.Parameters.AddWithValue("@department", department);
                cmdEmployee.Parameters.AddWithValue("@percent", percent);
                cmdEmployee.ExecuteNonQuery();
                long employeeId = cmdEmployee.LastInsertedId;

                string insertOperation = @"INSERT INTO bank_operations(id_service, id_client, date_take, date_return) 
                                 VALUES (@serviceId, @clientId, @date_take, @date_return)";
                MySqlCommand cmdOperation = new MySqlCommand(insertOperation, con);
                cmdOperation.Parameters.AddWithValue("@serviceId", employeeId);
                cmdOperation.Parameters.AddWithValue("@clientId", clientId);
                cmdOperation.Parameters.AddWithValue("@date_take", date_take);
                cmdOperation.Parameters.AddWithValue("@date_return", date_return);
                cmdOperation.ExecuteNonQuery();

                MessageBox.Show("Запись успешно добавлена!");

                MySqlCommand cmd2 = new MySqlCommand(command, con);
                MySqlDataAdapter da = new MySqlDataAdapter(cmd2);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;

                textBox1.Text = "";
                maskedTextBox1.Text = "";
                textBox3.Text = "";
                textBox2.Text = "";
                comboBox1.SelectedIndex = -1;
                comboBox2.SelectedIndex = -1;

                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        string selectedReader;
        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex != -1)
            {
                selectedReader = comboBox1.SelectedItem.ToString();
            }
        }
    }
}
