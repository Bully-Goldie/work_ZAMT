﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace пр13.Forms
{
    public partial class addClient : Form
    {
        private string str = "host=localhost;user=root;pwd=root;database=PR13_Kichigin;";

        public addClient()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string fullName = textBox1.Text.Trim();
            string passport = maskedTextBox1.Text.Trim();

            if (string.IsNullOrWhiteSpace(fullName))
            {
                MessageBox.Show("Пожалуйста, введите ФИО клиента");
                return;
            }

            if (!maskedTextBox1.MaskCompleted)
            {
                MessageBox.Show("Пожалуйста, введите полный номер паспорта");
                maskedTextBox1.Focus();
                return;
            }

            string[] name = fullName.Split(new char[] { ' ' });

            if (name.Length < 2)
            {
                MessageBox.Show("Введите фамилию и имя (отчество не обязательно)");
                return;
            }

            string lastName = name[0];
            string firstName = name[1];
            string middleName = name.Length > 2 ? name[2] : null;

            try
            {
                MySqlConnection conn = new MySqlConnection(str);

                conn.Open();

                string command = @"INSERT INTO client_bank 
                                (last_name, first_name, middle_name, passport, sum) 
                                VALUES (@lastName, @firstName, @middleName, @passport, @sum)";

                MySqlCommand cmd = new MySqlCommand(command, conn);

                cmd.Parameters.AddWithValue("@lastName", lastName);
                cmd.Parameters.AddWithValue("@firstName", firstName);
                cmd.Parameters.AddWithValue("@middleName", middleName ?? (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@passport", passport);
                cmd.Parameters.AddWithValue("@sum", 0.00);

                int rowsAffected = cmd.ExecuteNonQuery();

                if (rowsAffected > 0)
                {
                    MessageBox.Show("Клиент успешно добавлен!");
                    textBox1.Clear();
                    maskedTextBox1.Clear();
                }
                else
                {
                    MessageBox.Show("Не удалось добавить клиента");
                }
                conn.Close();
            }
            catch (Exception)
            {
                MessageBox.Show("Вы не подключились к БД!");
            }
        }


        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            e.Handled = !((ch >= 'А' && ch <= 'я') || ch == (char)Keys.Back || ch == (char)Keys.Space);
        }
    }
}
