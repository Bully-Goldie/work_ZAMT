﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;

namespace пр13.Forms
{
    public partial class info : Form
    {
        string connectionStr = "host=localhost;uid=root;pwd=root;database=pr13_kichigin;";
        int id_operation;

        public info()
        {
            InitializeComponent();
        }

        public info(int id_operation)
        {
            InitializeComponent();
            this.id_operation = id_operation;
            GetInfo();
        }

        void GetInfo()
        {
            string commandTakeBook = $@"SELECT 
                                    be.last_name AS emp_last_name,
                                    be.first_name AS emp_first_name,
                                    be.middle_name AS emp_middle_name,
                                    be.department,
                                    be.percent,
                                    cb.last_name AS client_last_name,
                                    cb.first_name AS client_first_name,
                                    cb.middle_name AS client_middle_name,
                                    cb.passport,
                                    bo.credit_amount,  -- Изменено с cb.sum на bo.credit_amount
                                    bo.date_take,
                                    bo.date_return
                                FROM bank_operations bo
                                JOIN bank_employee be ON bo.id_service = be.id_service
                                JOIN client_bank cb ON bo.id_client = cb.id_client
                                WHERE bo.id_operation = {id_operation};";

            try
            {
                MySqlConnection con = new MySqlConnection(connectionStr);
                con.Open();

                MySqlCommand cmd = new MySqlCommand(commandTakeBook, con);
                MySqlDataReader rdr = cmd.ExecuteReader();

                if (rdr.Read())
                {
                    label1.Text += rdr["emp_last_name"].ToString() + " " +
                                   rdr["emp_first_name"].ToString() + " " +
                                   rdr["emp_middle_name"].ToString();

                    label2.Text += rdr["passport"].ToString();

                    label3.Text += rdr["department"].ToString();

                    decimal creditAmount = Convert.ToDecimal(rdr["credit_amount"]);
                    label4.Text += creditAmount.ToString("N2") + " руб.";

                    label5.Text += rdr["percent"].ToString() + "%";

                    label6.Text += rdr["client_last_name"].ToString() + " " +
                                   rdr["client_first_name"].ToString() + " " +
                                   rdr["client_middle_name"].ToString();

                    DateTime dateTake = rdr.GetDateTime("date_take");
                    label7.Text += dateTake.ToString("dd.MM.yyyy");

                    DateTime dateReturn = rdr.GetDateTime("date_return");
                    label8.Text += dateReturn.ToString("dd.MM.yyyy");
                }
                else
                {
                    MessageBox.Show("Запись не найдена", "Информация",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

                rdr.Close();
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка чтения",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}