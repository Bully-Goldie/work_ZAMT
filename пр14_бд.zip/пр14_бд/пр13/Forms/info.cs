﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;

namespace пр13.Forms
{
    public partial class info : Form
    {

        string connectionStr = "host=localhost;uid=root;pwd=root;database=pr13_kichigin;";
        int id_employee;
        public info()
        {
            InitializeComponent();
        }
        public info(int id_employee)
        {
            InitializeComponent();

            this.id_employee = id_employee;
            GetInfo();
        }

        void GetInfo()
        {
            string commandTakeBook = $@"SELECT 
                                    be.last_name,
                                    be.first_name,
                                    be.middle_name,
                                    be.department,
                                    be.percent,
                                    cb.last_name,
                                    cb.first_name,
                                    cb.middle_name,
                                    cb.passport,
                                    cb.sum,
                                    bo.date_take,
                                    bo.date_return
                                FROM bank_operations bo
                                JOIN bank_employee be ON bo.id_service = be.id_service
                                JOIN client_bank cb ON bo.id_client = cb.id_client
                                WHERE bo.id_employee = {id_employee};";

            try
            {
                MySqlConnection con = new MySqlConnection(connectionStr);
                con.Open();

                MySqlCommand cmd = new MySqlCommand(commandTakeBook, con);
                MySqlDataReader rdr = cmd.ExecuteReader();

                if (rdr.Read())
                {
                    label1.Text += rdr[0].ToString() + " " + rdr[1].ToString() + " " + rdr[2].ToString();

                    label2.Text += rdr[8].ToString();

                    label3.Text += rdr[3].ToString();

                    label4.Text += rdr[9].ToString();

                    label5.Text += rdr[4].ToString();

                    label6.Text += rdr[5].ToString() + " " + rdr[6].ToString() + " " + rdr[7].ToString();

                    DateTime dateTake = rdr.GetDateTime(10);
                    label7.Text += dateTake.ToString("dd.MM.yyyy");

                    DateTime dateReturn = rdr.GetDateTime(11);
                    label8.Text += dateReturn.ToString("dd.MM.yyyy");
                }
                else
                {
                    MessageBox.Show("Запись не найдена", "Информация", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

                rdr.Close();
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "Ошибка чтения", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
