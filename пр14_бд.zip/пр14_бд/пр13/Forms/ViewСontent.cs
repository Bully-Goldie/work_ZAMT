﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using пр13.Forms;

namespace пр13
{
    public partial class ViewСontent : Form
    {
        string str = @"host=localhost;uid=root;pwd=root;database=pr13_Kichigin;";

        string command = @"SELECT 
                        bo.id_operation,
                        CONCAT_WS(' ', cb.last_name, cb.first_name, cb.middle_name) AS client_fio,
                        bo.credit_amount AS credit_amount,
                        be.percent AS credit_percent,
                        bo.date_take AS `Дата заёма`,
                        bo.date_return AS `Дата возврата`
                    FROM bank_operations bo
                    INNER JOIN client_bank cb ON bo.id_client = cb.id_client
                    INNER JOIN bank_employee be ON bo.id_service = be.id_service;";
        public ViewСontent()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void ViewСontent_Load(object sender, EventArgs e)
        {
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            try
            {
                MySqlConnection conn = new MySqlConnection(str);
                conn.Open();

                MySqlCommand cmd = new MySqlCommand(command, conn);
                MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                DataTable dt = new DataTable();

                da.Fill(dt);
                dataGridView1.DataSource = dt;

                dataGridView1.Columns["client_fio"].HeaderText = "ФИО клиента";
                dataGridView1.Columns["credit_amount"].HeaderText = "Сумма заёма";
                dataGridView1.Columns["credit_percent"].HeaderText = "Процент кредита";

                if (dataGridView1.Columns.Contains("id_operation"))
                {
                    dataGridView1.Columns["id_operation"].Visible = false;
                }

                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка подключения к БД: {ex.Message}");
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                int id_operation = Convert.ToInt32(dataGridView1.Rows[e.RowIndex].Cells["id_operation"].Value);

                info open = new info(id_operation);
                open.ShowDialog();
            }
        }
    }
}