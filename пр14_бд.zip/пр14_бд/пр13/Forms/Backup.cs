﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace пр13.Forms
{
    public partial class Backup : Form
    {
        string str = @"host=localhost;uid=root;pwd=root;database=pr13_Kichigin;";

        public Backup()
        {
            InitializeComponent();
            LoadTables();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        string selectedTable;
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex != -1)
            {
                selectedTable = comboBox1.SelectedItem.ToString();
            }
        }

        private void LoadTables()
        {
            try
            {
                MySqlConnection conn = new MySqlConnection(str);
                conn.Open();

                string query = @"SELECT TABLE_NAME 
                                    FROM INFORMATION_SCHEMA.TABLES 
                                    WHERE TABLE_SCHEMA = 'pr13_Kichigin' 
                                    AND TABLE_TYPE = 'BASE TABLE'";

                MySqlCommand cmd = new MySqlCommand(query, conn);

                MySqlDataReader reader = cmd.ExecuteReader();

                comboBox1.Items.Clear();

                while (reader.Read())
                {
                    string tableName = reader["TABLE_NAME"].ToString();
                    comboBox1.Items.Add(tableName);
                }

                if (comboBox1.Items.Count > 0)
                    comboBox1.SelectedIndex = 0;
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки таблиц: {ex.Message}");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string originalTable = comboBox1.SelectedItem.ToString();
            string timestamp = DateTime.Now.ToString("yyyy_MM_dd");
            string backupTable = originalTable + "_backup_" + timestamp;

            try
            {
                CreateTableBackup(originalTable, backupTable);
                MessageBox.Show($"Бэкап таблицы '{originalTable}' создан успешно!\nНовая таблица: '{backupTable}'");
                LoadTables();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка создания бэкапа: {ex.Message}");
            }
        }

        private void CreateTableBackup(string originalTable, string backupTable)
        {
            MySqlConnection conn = new MySqlConnection(str);
            conn.Open();

            string createBackupTable = $@"CREATE TABLE `{backupTable}` AS SELECT * FROM `{originalTable}`";

            MySqlCommand cmd = new MySqlCommand(createBackupTable, conn);
            cmd.ExecuteNonQuery();
            conn.Close();
        }
    }
}
