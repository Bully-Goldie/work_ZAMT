﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace пр13.Forms
{
    public partial class Backup : Form
    {
        string str = @"host=localhost;
                        uid=root;
                        pwd=root;
                        database=pr13_Kichigin;";

        private Dictionary<string, string> tableNames = new Dictionary<string, string>()
        {
            { "Банковские сотрудники", "bank_employee" },
            { "Клиенты банка", "client_bank" },
            { "Банковские операции", "bank_operations" }
        };

        public Backup()
        {
            InitializeComponent();
            LoadTables();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        string selectedReader;
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex != -1)
            {
                selectedReader = comboBox1.SelectedItem.ToString();
            }
        }

        private void LoadTables()
        {
            try
            {
                using (MySqlConnection con = new MySqlConnection(str))
                {
                    con.Open();

                    string query = @"SELECT TABLE_NAME 
                               FROM INFORMATION_SCHEMA.TABLES 
                               WHERE TABLE_SCHEMA = 'PR13_Kichigin' 
                               AND TABLE_TYPE = 'BASE TABLE'";

                    using (MySqlCommand cmd = new MySqlCommand(query, con))
                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {
                        comboBox1.Items.Clear();
                        while (reader.Read())
                        {
                            string tableName = reader["TABLE_NAME"].ToString();
                            string displayName = GetRussianTableName(tableName);
                            comboBox1.Items.Add(displayName);
                        }
                    }

                    if (comboBox1.Items.Count > 0)
                        comboBox1.SelectedIndex = 0;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки таблиц: {ex.Message}");
            }
        }

        private string GetRussianTableName(string englishName)
        {
            foreach (var pair in tableNames)
            {
                if (pair.Value == englishName)
                {
                    return pair.Key;
                }
            }
            return englishName;
        }

        private string GetEnglishTableName(string russianName)
        {
            if (tableNames.ContainsKey(russianName))
            {
                return tableNames[russianName];
            }
            return russianName;
        }

        private string GetRussianBackupName(string originalTable, string backupTable)
        {
            string russianTableName = GetRussianTableName(originalTable);

            string[] parts = backupTable.Split(new string[] { "_backup_" }, StringSplitOptions.None);
            if (parts.Length == 2)
            {
                string dateTimePart = parts[1];
                if (dateTimePart.Length >= 15)
                {
                    string year = dateTimePart.Substring(0, 4);
                    string month = dateTimePart.Substring(4, 2);
                    string day = dateTimePart.Substring(6, 2);
                    string hour = dateTimePart.Substring(9, 2);
                    string minute = dateTimePart.Substring(11, 2);

                    string formattedDateTime = $"{year}.{month}.{day}_{hour}.{minute}";
                    return $"{russianTableName}_бэкап_{formattedDateTime}";
                }
            }

            return $"{russianTableName}_бэкап_{DateTime.Now:yyyy.MM.dd_HH.mm}";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedItem == null)
            {
                MessageBox.Show("Выберите таблицу для бэкапа!");
                return;
            }

            string selectedRussianTable = comboBox1.SelectedItem.ToString();
            string originalTable = GetEnglishTableName(selectedRussianTable);

            string timestamp = DateTime.Now.ToString("yyyy.MM.dd_HH.mm");
            string backupTable = originalTable + "_backup_" + timestamp;

            try
            {
                CreateTableBackup(originalTable, backupTable);

                string russianBackupName = GetRussianBackupName(originalTable, backupTable);

                MessageBox.Show($"Бэкап таблицы '{selectedRussianTable}' создан успешно!\nНовая таблица: '{russianBackupName}'");
                LoadTables();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка создания бэкапа: {ex.Message}");
            }
        }

        private void CreateTableBackup(string originalTable, string backupTable)
        {
            using (MySqlConnection con = new MySqlConnection(str))
            {
                con.Open();

                string createBackupTable = $@"
                CREATE TABLE `{backupTable}` 
                AS SELECT * FROM `{originalTable}`";

                using (MySqlCommand cmd = new MySqlCommand(createBackupTable, con))
                {
                    cmd.ExecuteNonQuery();
                }

                try
                {
                    string addBackupDateColumn = $@"
                    ALTER TABLE `{backupTable}` 
                    ADD COLUMN backup_created DATETIME DEFAULT CURRENT_TIMESTAMP";

                    using (MySqlCommand cmd = new MySqlCommand(addBackupDateColumn, con))
                    {
                        cmd.ExecuteNonQuery();
                    }
                }
                catch
                {
                }

                if (originalTable == "bank_employee" || originalTable == "client_bank" || originalTable == "bank_operations")
                {
                    string setAutoIncrement = $@"
                    ALTER TABLE `{backupTable}` 
                    MODIFY COLUMN {GetPrimaryKeyColumn(originalTable)} INT AUTO_INCREMENT PRIMARY KEY";

                    using (MySqlCommand cmd = new MySqlCommand(setAutoIncrement, con))
                    {
                        cmd.ExecuteNonQuery();
                    }
                }
            }
        }

        private string GetPrimaryKeyColumn(string tableName)
        {
            switch (tableName)
            {
                case "bank_employee":
                    return "id_service";
                case "client_bank":
                    return "id_client";
                case "bank_operations":
                    return "id_employee";
                default:
                    return "id";
            }
        }
    }
}