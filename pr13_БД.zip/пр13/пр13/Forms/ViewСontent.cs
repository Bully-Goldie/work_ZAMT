﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace пр13
{
    public partial class ViewСontent : Form
    {
        string str = @"host=localhost;
                        uid=root;
                        pwd=root;
                        database=pr13_Kichigin;";

        string command = @"SELECT
                        id_employee,

                        (SELECT CONCAT_WS(' ', last_name, first_name, middle_name) 
                         FROM client_bank 
                         WHERE bank_operations.id_client = client_bank.id_client) AS client_fio,

                        (SELECT sum 
                         FROM client_bank 
                         WHERE bank_operations.id_client = client_bank.id_client) AS credit_amount,

                        (SELECT percent 
                         FROM bank_employee 
                         WHERE bank_operations.id_service = bank_employee.id_service) AS credit_percent,

                        date_take AS `Дата заёма`,
                        date_return AS `Дата возврата`

                    FROM bank_operations;";
        public ViewСontent()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void ViewСontent_Load(object sender, EventArgs e)
        {
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            try
            {
                MySqlConnection conn = new MySqlConnection(str);
                conn.Open();

                MySqlCommand cmd = new MySqlCommand(command, conn);
                MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                DataTable dt = new DataTable();

                da.Fill(dt);
                dataGridView1.DataSource = dt;

                dataGridView1.Columns["client_fio"].HeaderText = "ФИО клиента";
                dataGridView1.Columns["credit_amount"].HeaderText = "Сумма заёма";
                dataGridView1.Columns["credit_percent"].HeaderText = "Процент кредита";

                dataGridView1.Columns["id_employee"].Visible = false;

                conn.Close();
            }
            catch (Exception)
            {
                MessageBox.Show("Вы не подключились к БД!");
            }
        }
    }
}
