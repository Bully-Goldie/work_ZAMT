CREATE DATABASE PR13_Kichigin;

USE PR13_Kichigin;

CREATE TABLE bank_employee(
    id_service INT AUTO_INCREMENT PRIMARY KEY,
    last_name VARCHAR(50) NOT NULL,
    first_name VARCHAR(50) NOT NULL,
    middle_name VARCHAR(50),
    department VARCHAR(100) NOT NULL,
    percent DECIMAL(4,1) NOT NULL CHECK (percent BETWEEN 0 AND 100)
);

INSERT INTO bank_employee (last_name, first_name, middle_name, department, percent) VALUES
('Иванов', 'Иван', 'Иванович', 'Старший', 2.5),
('Петрова', 'Анна', 'Сергеевна', 'Младший', 3.0),
('Сидоров', 'Алексей', 'Петрович', 'Средний', 2.8),
('Козлова', 'Елена', 'Владимировна', 'Старший', 2.7),
('Васильев', 'Дмитрий', 'Николаевич', 'Младший', 3.2),
('Морозова', 'Ольга', 'Игоревна', 'Старший', 2.9),
('Николаев', 'Сергей', 'Александрович', 'Младший', 2.6),
('Федорова', 'Мария', 'Павловна', 'Средний', 3.1),
('Алексеев', 'Андрей', 'Викторович', 'Старший', 2.4),
('Семенова', 'Ирина', 'Олеговна', 'Средний', 3.3);

CREATE TABLE client_bank(
    id_client INT AUTO_INCREMENT PRIMARY KEY, 
    last_name VARCHAR(50) NOT NULL,
    first_name VARCHAR(50) NOT NULL,
    middle_name VARCHAR(50),
    passport VARCHAR(11),
    sum INT NOT NULL
);
                        
INSERT INTO client_bank(last_name, first_name, middle_name, passport, sum) VALUES 
('Иванов', 'Сергей', 'Петрович', '4510-123456', 150000),
('Петрова', 'Анна', 'Владимировна', '4511-654321', 275000),
('Сидоров', 'Дмитрий', 'Игоревич', '4520-112233', 85000),
('Козлова', 'Елена', 'Михайловна', '4515-445566', 420000),
('Васильев', 'Андрей', 'Николаевич', '4530-778899', 125000),
('Николаева', 'Мария', 'Сергеевна', '4518-990011', 65000),
('Федоров', 'Иван', 'Кузьмич', '4525-223344', 185000),
('Алексеева', 'Ольга', 'Дмитриевна', '4513-556677', 320000),
('Павлов', 'Алексей', 'Викторович', '4522-667788', 95000),
('Семенова', 'Юлия', 'Игоревна', '4519-334455', 155000);

CREATE TABLE bank_operations(
    id_employee INT AUTO_INCREMENT PRIMARY KEY,
    id_service INT NOT NULL,
    id_client INT NOT NULL,
    date_take DATE NOT NULL,
    date_return DATE NOT NULL,
    FOREIGN KEY (id_service) REFERENCES bank_employee(id_service),
    FOREIGN KEY (id_client) REFERENCES client_bank(id_client)
);
                        
INSERT INTO bank_operations (id_service, id_client, date_take, date_return) VALUES 
(1, 1, '2025-01-15', '2027-02-15'),
(2, 2, '2025-01-20', '2027-06-20'),
(3, 3, '2025-02-01', '2027-08-01'),
(4, 4, '2025-02-10', '2027-03-10'),
(5, 5, '2025-02-15', '2027-05-15'),
(6, 6, '2025-03-01', '2027-04-01'),
(7, 7, '2025-03-05', '2027-09-05'),
(8, 8, '2025-03-10', '2027-03-20'),
(9, 9, '2025-03-15', '2027-06-15'),
(10, 10, '2025-03-20', '2027-04-20');