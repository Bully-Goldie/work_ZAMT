﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;

namespace пр09
{
    class Program
    {
        static int DecToOct(int A)
        {
            int res = 0;
            int razrad = 1;

            while (A > 0)
            {
                int ostatok = A % 8;
                res += ostatok * razrad;
                A /= 8;
                razrad *= 10;
            }

            return res;
        }

        static int SumRange(int A, int B)
        {
            if (A > B)
            {
                return 0;
            }
            else
            {
                int res = 0;
                for (int i = A; i <= B; i++)
                {
                    res += i;
                }
                return res;
            }
        }
        static void Main(string[] args)
        {
            //Задание 1
            //Проверить истинность высказывания: "Все цифры данного целого положительного четырехзначного числа различны".

            string input1 = "input1.txt";
            string output1 = "output1.txt";

            try
            {
                string content1 = File.ReadAllText(input1);

                int x = Convert.ToInt32(content1);

                int one = (x / 1000) % 10;
                int two = (x / 100) % 10;
                int three = (x / 10) % 10;
                int four = x % 10;

                if (one != two && two != three && three != four)
                {
                    File.WriteAllLines(output1, new string[] { "Все цифры данного целого положительного четырехзначного числа различны" });
                }
                else
                {
                    File.WriteAllLines(output1, new string[] { "Не все цифры данного целого положительного четырехзначного числа различны" });
                }
            }
            catch (FileNotFoundException ex)
            {

                Console.WriteLine($"Ошибка: файл '{input1}' не найден. {ex}");
            }
            catch (IOException ex)
            {

                Console.WriteLine($"Ошибка ввода-вывода: {ex.Message}");
            }
            catch (Exception ex)
            {

                Console.WriteLine($"Ошибка при обработке файла: {ex.Message}");
            }

            //Задание 2
            //Дан целочисленный массив, состоящий из N элементов (N > 0).
            //Найти и вывести количество элементов, расположенных после самого последнего максимального элемента.
            string input2 = "input2.txt";
            string output2 = "output2.txt";

            try
            {
                string content2 = File.ReadAllText(input2);

                string[] str2 = content2.Split(new char[] { ' ', ',', '!', '.', '?' }, StringSplitOptions.RemoveEmptyEntries);

                int[] array = new int[str2.Length];

                for (int i = 0; i < str2.Length; i++)
                {
                    array[i] = Convert.ToInt32(str2[i].ToString());
                }

                int max = array.Max();
                int lmax = Array.LastIndexOf(array, max);
                int count = array.Length - lmax - 1;

                File.WriteAllLines(output2, new string[] { $"Количество элементов, расположенных после самого последнего максимального элемента = {count}" });
            }
            catch (FileNotFoundException ex)
            {

                Console.WriteLine($"Ошибка: файл '{input2}' не найден. {ex}");
            }
            catch (IOException ex)
            {

                Console.WriteLine($"Ошибка ввода-вывода: {ex.Message}");
            }
            catch (Exception ex)
            {

                Console.WriteLine($"Ошибка при обработке файла: {ex.Message}");
            }

            //Задание 4
            //Написать функцию int DecToOct(A), целого типа, для выполнения перевода целого трехзначного числа А
            //из десятичной системы счисления в восьмеричную систему счисления.

            string input4 = "input4.txt";
            string output4 = "output4.txt";

            try
            {
                string content4 = File.ReadAllText(input4);

                int A = Convert.ToInt32(content4);

                int res = DecToOct(A);

                File.WriteAllLines(output4, new string[] { $"Восьмеричная система счисления = {res}" });
            }
            catch (FileNotFoundException ex)
            {

                Console.WriteLine($"Ошибка: файл '{input4}' не найден. {ex}");
            }
            catch (IOException ex)
            {

                Console.WriteLine($"Ошибка ввода-вывода: {ex.Message}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка при обработке файла: {ex.Message}");
            }

            //Задание 5
            //Написать функцию int SumRange(A, B) целого типа, находящую сумму всех целых чисел в диапазоне от A до B
            //включительно (A и B — целые положительные). Если A > B, то функция должна возвращать число 0.

            string input5 = "input5.txt";
            string output5 = "output5.txt";

            try
            {
                string content5 = File.ReadAllText(input5);

                string[] str5 = content5.Split(new char[] { ' ', ',', '!', '.', '?' }, StringSplitOptions.RemoveEmptyEntries);

                int A = Convert.ToInt32(str5[0]);
                int B = Convert.ToInt32(str5[1]);

                int res = SumRange(A, B);

                File.WriteAllLines(output5, new string[] { $"{res}" });
            }
            catch (FileNotFoundException ex)
            {

                Console.WriteLine($"Ошибка: файл '{input5}' не найден. {ex}");
            }
            catch (IOException ex)
            {

                Console.WriteLine($"Ошибка ввода-вывода: {ex.Message}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка при обработке файла: {ex.Message}");
            }
        }
    }
}
