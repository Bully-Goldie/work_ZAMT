#!/bin/bash

if [ -d "./Folder1/" ]
then
cd Folder1
touch file{0..9}.exe
chmod +x file{0..9}.exe
else
mkdir Folder1
fi