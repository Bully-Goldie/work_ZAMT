#!/bin/bash

normal='\033[0m'
green='\033[0;32m'
yellow='\033[0;33m'

if [ -e "/etc/passwd" ] && [ -e "/etc/group" ]
then
echo -e "${green}Файлы сущетвуют в системе!${normal}"
else
mkpasswd -l > /etc/passwd
mkgroup -l > /etc/group
fi

echo -e "${yellow}"
tail -n 1 "/etc/passwd"
tail -n 1 "/etc/group"
echo -e "${normal}"