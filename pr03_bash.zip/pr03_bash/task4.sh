#!/bin/bash

normal='\033[0m'
blue='\033[0;34m'
red='\033[0;31m'

cd Folder1
count=$(ls | wc -l)

if [[ $count -gt 7 ]] && [ -x "file0.exe" ]
then
echo -e "${blue}Файл исполняемый и существует.${normal}"
else
echo -e "${red}ОТСУТСТВУЕТ${normal}"
fi