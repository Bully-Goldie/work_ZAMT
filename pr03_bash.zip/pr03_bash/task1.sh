#!/bin/bash

normal='\033[0m'
red='\033[1;31m'
blue='\033[0;34m'

num=$RANDOM

if (($num % 2 == 0))
then
echo -e "${red}${num}${normal}"
else
echo -e "${blue}${num}${normal}"
fi