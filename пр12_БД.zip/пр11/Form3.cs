﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using static System.Runtime.CompilerServices.RuntimeHelpers;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace пр11
{
    public partial class Form3 : Form
    {
        
        DataGridView dgv;
        string StrCon = "host=localhost" +
        ";uid=root" +
        ";pwd=root;" +
        "database=pr12_Kichigin";
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridView1.DefaultCellStyle.SelectionBackColor = ColorTranslator.FromHtml("#FDBD40");

            FillDataGrid();
        }

        void FillDataGrid()
        {
            using (MySqlConnection con = new MySqlConnection())
            {
                try
                {
                    con.ConnectionString = StrCon;

                    con.Open();

                    MySqlCommand cmd = new MySqlCommand("SELECT id, brand as 'Марка', model as 'Модель', year as 'Год выпуска', price as 'Цена', color as 'Цвет' FROM automobiles", con);
                    cmd.ExecuteNonQuery();

                    MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                    DataTable dt = new DataTable();

                    da.Fill(dt);

                    dataGridView1.DataSource = dt;
                    dataGridView1.Columns["id"].Visible = false;
                }
                catch (Exception)
                {
                    MessageBox.Show(Text = "Вы не подключились к БД");
                }
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0 || e.ColumnIndex >= dataGridView1.Rows.Count)
                return;

            dgv = (DataGridView)sender;
            int rowIndex = e.RowIndex;

            dgv.Rows[rowIndex].Selected = true;

            string cell0 = dgv.Rows[rowIndex].Cells[0].Value.ToString();
            string cell1 = dgv.Rows[rowIndex].Cells[1].Value.ToString();
            string strCmd = "DELETE FROM automobiles WHERE id='" + cell0 + "';";
            string strCon = "host=localhost;uid=root;pwd=root;database=pr12_Kichigin;";

            using (MySqlConnection con = new MySqlConnection())
            {
                try
                {
                    con.ConnectionString = strCon;

                    con.Open();

                    MySqlCommand cmd = new MySqlCommand(strCmd, con);

                    DialogResult dr = MessageBox.Show("Удалить запись?", "Внимание!", MessageBoxButtons.YesNo, MessageBoxIcon.Asterisk);
                    if (dr == DialogResult.Yes)
                    {
                        int res = cmd.ExecuteNonQuery();
                        MessageBox.Show("Удалено " + res.ToString(), "Внимание!", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);

                        FillDataGrid();
                    }

                }
                catch (Exception)
                {
                    throw;
                }
            }
        }
    }
}
