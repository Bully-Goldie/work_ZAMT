CREATE DATABASE `PR12_Kichigin`;

USE PR12_Kichigin;

CREATE TABLE automobiles (
    id INT PRIMARY KEY AUTO_INCREMENT,
    brand VARCHAR(50) NOT NULL,
    model VARCHAR(50) NOT NULL,
    year INT NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    color VARCHAR(30) NOT NULL
);

INSERT INTO automobiles (brand, model, year, price, color) VALUES
('Toyota', 'Camry', 2022, 2850000.00, 'Белый'),
('BMW', 'X5', 2023, 6500000.00, 'Черный'),
('Mercedes-Benz', 'C-Class', 2022, 4200000.00, 'Серый'),
('Honda', 'CR-V', 2023, 3200000.00, 'Красный'),
('Audi', 'A4', 2022, 3800000.00, 'Синий'),
('Volkswagen', 'Tiguan', 2023, 2650000.00, 'Белый'),
('Hyundai', 'Tucson', 2022, 2450000.00, 'Оранжевый'),
('Kia', 'Sportage', 2023, 2550000.00, 'Зеленый'),
('Ford', 'Focus', 2022, 1850000.00, 'Желтый'),
('Skoda', 'Octavia', 2023, 1950000.00, 'Серебристый');