import integer.*;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //Проверить истинность высказывания: "Данное целое положительное число является нечетным трехзначным числом".
        try{
            Scanner sc = new Scanner(System.in);
            System.out.println("Задание 1");

            System.out.print("Введите целое положительное число: ");
            int N = sc.nextInt();

            if(N > 0){
                Task1 task1 = new Task1();
                boolean result = task1.Zadanie1(N);
                System.out.println(result);
            }else{
                System.out.println("Вы ввели не положительное число.");
            }
        }catch (Exception ex){
            System.out.println(ex.getMessage());
        }
        //Дано вещественное число A и целое число N (N > 0). Вывести значение результата A в степени N: AN = A*A*...*A (число A перемножается N раз).
        try{
            Scanner sc = new Scanner(System.in);
            System.out.println("Задание 2");

            System.out.print("Введите вещественное число A:");
            double A = sc.nextDouble();

            System.out.print("Введите целое число N: ");
            int N = sc.nextInt();

            if(N > 0){
                Task2 task2 = new Task2();
                double res = task2.Zadanie2(A, N);
                System.out.println(res);
            }else{
                System.out.println("Вы ввели отрицательное число N.");
            }
        }catch (Exception ex){
            System.out.println(ex.getMessage());
        }
    }
}