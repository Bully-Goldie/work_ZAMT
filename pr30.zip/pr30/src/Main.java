import number.*;
import str.*;

import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //Проверить истинность высказывания: "Данное целое положительное число является нечетным трехзначным числом".
        try{

            Scanner sc = new Scanner(System.in);
            System.out.println("Задание 1");

            System.out.print("Введите целое положительное число: ");
            int N = sc.nextInt();

            if(N > 0){
                Task1 task1 = new Task1();
                boolean result = task1.Zadanie1(N);
                System.out.println(result);
            }else{
                System.out.println("Вы ввели не положительное число.");
            }
        }catch (Exception ex){
            System.out.println(ex.getMessage());
        }
        //Дано вещественное число A и целое число N (N > 0). Вывести значение результата A в степени N: AN = A*A*...*A (число A перемножается N раз).
        try{
            Scanner sc = new Scanner(System.in);
            System.out.println("Задание 2");

            System.out.print("Введите вещественное число A:");
            double A = sc.nextDouble();

            System.out.print("Введите целое число N: ");
            int N = sc.nextInt();

            if(N > 0){
                Task2 task2 = new Task2();
                double res = task2.Zadanie2(A, N);
                System.out.println(res);
            }else{
                System.out.println("Вы ввели отрицательное число N.");
            }
        }catch (Exception ex){
            System.out.println(ex.getMessage());
        }
        //Дан целочисленный массив, состоящий из N элементов (N > 0).
        //Переставить в обратном порядке элементы массива, расположенные между его минимальным и максимальным элементами,
        //не включая минимальный и максимальный элементы.
        try{
            Scanner sc = new Scanner(System.in);
            System.out.println("Задание 3");

            Task3 task3 = new Task3();

            System.out.print("Ввелите кол-во элементов массива: ");
            int N = sc.nextInt();

            if(N > 0){
                Random random = new Random();
                int[] arr = new int[N];

                for(int i = 0; i < N; i++){
                    arr[i] = random.nextInt();
                }

                System.out.println("До: " + Arrays.toString(arr));

                System.out.println("После: " + Arrays.toString(task3.Zadanie3(arr)));
            }else{
                System.out.println("Вы ввели кол-во элементов массива меньше 0.");
            }

        }catch (Exception ex){
            System.out.println(ex.getMessage());
        }
        //Написать функцию int DigitN(K, N) целого типа, возвращающую N-ю цифру целого положительного числа K (цифры в числе нумеруются справа налево).
        //Если количество цифр в числе K меньше N, то функция должна возвращать значение -1.
        try{
            Scanner sc = new Scanner(System.in);
            System.out.println("Задание 4");

            Task4 task4 = new Task4();

            System.out.print("Введите целое положительное число K: ");
            int K = sc.nextInt();
            System.out.print("Введите целое число N: ");
            int N = sc.nextInt();

            if(K > 0 && N > 0){
                System.out.println(task4.DigitN(K, N));
            }else{
                System.out.println("Вы ввели не положительное число K или N.");
            }

        }catch (Exception ex){
            System.out.println(ex.getMessage());
        }
        //Вводится строка-предложение на английском языке. Длина строки может быть разной.
        //Определить и вывести слово, содержащего наибольшее число символов 'd'.
        try{
            Scanner sc = new Scanner(System.in);
            System.out.println("Задание 5");

            Task5 task5 = new Task5();

            System.out.println("Введите строку на англ. языке: ");
            String str = sc.next();

            System.out.println(task5.Zadanie5(str));
        }catch (Exception ex){
            System.out.println(ex.getMessage());
        }
    }
}