package number;

public class Task2 {
    public double Zadanie2(double A, int N){
        double res = 1;
        for(int i = 0; i < N; i++){
            res = res*A;
        }
        return res;
    }
}

