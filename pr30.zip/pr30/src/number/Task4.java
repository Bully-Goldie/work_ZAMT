package number;

public class Task4 {
    public int DigitN(int K, int N) {
        int count = 0;
        int temp = K;

        while (temp > 0) {
            count++;
            temp /= 10;
        }

        if (count < N) {
            return -1;
        }

        for (int i = 1; i < N; i++) {
            K /= 10;
        }

        return K % 10;
    }
}
