package number;

public class Task1 {
    public boolean Zadanie1(int N){
        if(N % 2 != 0 && N > 99 && N <= 999){
            return true;
        }
        else{
            return false;
        }
    }
}
