package number;

import java.util.Arrays;

public class Task3 {
    public int[] Zadanie3(int[] arr){
        int min = 0;
        int max = 0;

        for (int i = 1; i < arr.length; i++) {
            if (arr[i] < arr[min]) {
                min = i;
            }
            if (arr[i] > arr[max]) {
                max = i;
            }
        }

        int left = Math.min(min, max) + 1;
        int right = Math.max(min, max) - 1;

        while (left < right) {
            int temp = arr[left];
            arr[left] = arr[right];
            arr[right] = temp;

            left++;
            right--;
        }
        return arr;
    }
}
