package str;

public class Task5 {
    public String Zadanie5(String str){
        String[] words = str.split("\\s+");
        String result = "";
        int count = 0;

        for (String word : words) {
            String clean = word.replaceAll("[^a-zA-Z]", "");

            if (!clean.isEmpty()) {
                int dCount = 0;
                for (int i = 0; i < clean.length(); i++) {
                    char c = clean.charAt(i);
                    if (c == 'd' || c == 'D') {
                        dCount++;
                    }
                }
                if (dCount > count || (dCount > 0 && result.isEmpty())) {
                    count = dCount;
                    result = clean;
                }
            }
        }

        return result;
    }
}
