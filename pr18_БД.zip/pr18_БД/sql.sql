CREATE DATABASE pr18_kichigin;
USE pr18_kichigin;

CREATE TABLE category (
    id_category INT AUTO_INCREMENT PRIMARY KEY,
    name_category VARCHAR(30) NOT NULL UNIQUE
);

INSERT INTO category (name_category) VALUES
('Администратор'),
('Пользователь');

CREATE TABLE user (
    id INT AUTO_INCREMENT PRIMARY KEY,
    login VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    id_category INT NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    create_account DATETIME NOT NULL,
    mode_account DATETIME NOT NULL,

    FOREIGN KEY (id_category) REFERENCES category(id_category)
);

INSERT INTO user
(login, password, id_category, full_name, phone, create_account, mode_account)
VALUES
('admin', SHA2('admin', 256), 1, 'Петров Алексей Сергеевич', '+7 (901) 234-56-78', '2025-02-10 09:30:00', NOW()),
('user1', SHA2('user1', 256), 2, 'Сидоров Михаил Иванович', '+7 (912) 345-67-12', '2025-03-15 14:20:00', NOW()),
('user2', SHA2('user2', 256), 2, 'Кузнецова Ольга Дмитриевна', '+7 (923) 456-78-34', '2025-04-22 11:15:00', NOW()),
('user3', SHA2('user3', 256), 2, 'Николаев Андрей Павлович', '+7 (934) 567-89-45', '2025-05-18 16:40:00', NOW()),
('user4', SHA2('user4', 256), 2, 'Васильева Дарья Сергеевна', '+7 (945) 678-90-56', '2025-06-12 08:50:00', NOW());

CREATE TABLE master(master_id INT AUTO_INCREMENT PRIMARY KEY,
					full_name VARCHAR(100) NOT NULL,
					experience INT NOT NULL,
					phone VARCHAR(20) NOT NULL,
					specification VARCHAR(30) NOT NULL);

CREATE TABLE devices(devices_id INT AUTO_INCREMENT PRIMARY KEY,
					name VARCHAR(30) NOT NULL,
					type VARCHAR(30) NOT NULL,
					brand VARCHAR(30) NOT NULL,
					serial_number INT NOT NULL);

CREATE TABLE work(work_id INT AUTO_INCREMENT PRIMARY KEY,
				master_id INT NOT NULL,
				devices_id INT NOT NULL,
				date_gave DATE NOT NULL,
				date_return DATE NOT NULL,
				FOREIGN KEY (master_id) REFERENCES master(master_id),
				FOREIGN KEY (devices_id) REFERENCES devices(devices_id));

INSERT INTO master (full_name, experience, phone, specification) VALUES
('Иванов Алексей Петрович', 5, '+7-901-123-45-67', 'Старший'),
('Смирнова Ольга Ивановна', 8, '+7-902-234-56-78', 'Средний'),
('Кузнецов Дмитрий Сергеевич', 3, '+7-903-345-67-89', 'Младший'),
('Попова Анна Викторовна', 10, '+7-904-456-78-90', 'Средний'),
('Соколов Михаил Андреевич', 6, '+7-905-567-89-01', 'Старший'),
('Лебедева Екатерина Дмитриевна', 4, '+7-906-678-90-12', 'Средний'),
('Новиков Павел Олегович', 7, '+7-907-789-01-23', 'Младший'),
('Морозова Татьяна Владимировна', 9, '+7-908-890-12-34', 'Старший'),
('Волков Артем Игоревич', 2, '+7-909-901-23-45', 'Младший'),
('Алексеева Мария Сергеевна', 12, '+7-910-012-34-56', 'Старший');

INSERT INTO devices (name, type, brand, serial_number) VALUES
('Ноутбук игровой', 'Ноутбук', 'ASUS', 100001),
('Смартфон флагман', 'Смартфон', 'Samsung', 200002),
('Планшет графический', 'Планшет', 'Apple', 300003),
('Монитор офисный', 'Монитор', 'LG', 400004),
('Принтер лазерный', 'Принтер', 'HP', 500005),
('Ноутбук ультрабук', 'Ноутбук', 'Lenovo', 600006),
('Смартфон бюджетный', 'Смартфон', 'Xiaomi', 700007),
('Системный блок', 'Компьютер', 'Deepcool', 800008),
('Планшет детский', 'Планшет', 'Huawei', 900009),
('Монитор игровой', 'Монитор', 'AOC', 100010);

INSERT INTO work (master_id, devices_id, date_gave, date_return) VALUES
(1, 1, '2024-01-10', '2024-01-15'),
(2, 2, '2024-01-12', '2024-01-18'),
(3, 3, '2024-01-14', '2024-01-20'),
(4, 6, '2024-01-16', '2024-01-22'),
(5, 4, '2024-01-18', '2024-01-25'),
(6, 5, '2024-01-20', '2024-01-28'),
(7, 7, '2024-01-22', '2024-01-30'),
(8, 8, '2024-01-25', '2024-02-02'),
(9, 9, '2024-01-28', '2024-02-05'),
(10, 10, '2024-02-01', '2024-02-10');