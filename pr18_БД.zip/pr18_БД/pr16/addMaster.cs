﻿using MySql.Data.MySqlClient;
using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace pr16
{
    public partial class addMaster : Form
    {
        string str = "host=localhost;user=root;pwd=root;database=pr18_kichigin;";

        public addMaster()
        {
            InitializeComponent();
            LoadSpecifications();

            add.BackColor = Color.FromArgb(204, 102, 0);
            exit.BackColor = Color.FromArgb(255, 204, 153);
            this.BackColor = Color.FromArgb(255,255, 255);
        }

        private void LoadSpecifications()
        {
            comboBox1.Items.Clear();
            comboBox1.DropDownStyle = ComboBoxStyle.DropDownList;

            try
            {
                using (MySqlConnection conn = new MySqlConnection(str))
                {
                    conn.Open();

                    string sql = "SELECT DISTINCT specification FROM master";
                    using (MySqlCommand cmd = new MySqlCommand(sql, conn))
                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            comboBox1.Items.Add(reader.GetString("specification"));
                        }
                    }
                }
            }
            catch
            {
                MessageBox.Show("Ошибка загрузки квалификаций из БД");
            }
        }

        private void add_Click(object sender, EventArgs e)
        {
            string fullName = textBox1.Text.Trim();
            string experienceText = textBox2.Text.Trim();
            string phone = maskedTextBox1.Text.Trim();
            string specification = comboBox1.Text;

            if (string.IsNullOrWhiteSpace(fullName))
            {
                MessageBox.Show("Введите ФИО мастера");
                return;
            }

            if (!int.TryParse(experienceText, out int experience))
            {
                MessageBox.Show("Стаж должен быть числом");
                return;
            }

            if (!maskedTextBox1.MaskCompleted)
            {
                MessageBox.Show("Введите полный номер телефона");
                return;
            }

            if (string.IsNullOrWhiteSpace(specification))
            {
                MessageBox.Show("Выберите квалификацию");
                return;
            }

            try
            {
                using (MySqlConnection conn = new MySqlConnection(str))
                {
                    conn.Open();

                    string sql = @"
                        INSERT INTO master (full_name, experience, phone, specification)
                        VALUES (@fullName, @experience, @phone, @spec)";

                    using (MySqlCommand cmd = new MySqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("@fullName", fullName);
                        cmd.Parameters.AddWithValue("@experience", experience);
                        cmd.Parameters.AddWithValue("@phone", phone);
                        cmd.Parameters.AddWithValue("@spec", specification);

                        cmd.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Мастер успешно добавлен!");

                textBox1.Clear();
                textBox2.Clear();
                maskedTextBox1.Clear();
                comboBox1.SelectedIndex = -1;
            }
            catch
            {
                MessageBox.Show("Ошибка подключения к базе данных");
            }
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;

            if ((ch >= 'А' && ch <= 'я') || ch == (char)Keys.Back || ch == ' ')
                e.Handled = false;
            else
                e.Handled = true;
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && e.KeyChar != (char)Keys.Back;
        }

        private void exit_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show(
                "Вы точно хотите выйти?",
                "Подтверждение",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                Close();
            }
        }
    }
}
