﻿using MySql.Data.MySqlClient;
using System;
using System.Data;
using System.Drawing;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace pr16
{
    public partial class authorization : Form
    {
        string str = "host=localhost;user=root;pwd=root;database=pr18_kichigin";

        string[] img =
        {
            @"imgCaptha/one.jpg",
            @"imgCaptha/two.jpg",
            @"imgCaptha/three.jpg"
        };

        Random random = new Random();
        int proverka;

        int failCount = 0;
        int failWithCaptcha = 0;
        bool captchaEnabled = false;

        public authorization()
        {
            InitializeComponent();

            password.PasswordChar = '*';
            reroll.Cursor = Cursors.Hand;

            captha.Visible = false;
            textBox1.Visible = false;
            label3.Visible = false;
            reroll.Visible = false;

            proverka = randomImage();

            exit.BackColor = Color.FromArgb(255, 204, 153);
            authorize.BackColor = Color.FromArgb(204, 102, 0);
            this.BackColor = Color.FromArgb(255, 255, 255);
        }

        private void authorization_Load(object sender, EventArgs e)
        {
            try
            {
                using (MySqlConnection con = new MySqlConnection(str))
                {
                    con.Open();

                    MySqlCommand cmd = new MySqlCommand(@"
                        SELECT 
                            CONCAT(u.full_name, ' (', u.login, ')') AS display_text,
                            u.login
                        FROM user u", con);

                    DataTable dt = new DataTable();
                    new MySqlDataAdapter(cmd).Fill(dt);

                    comboBox1.DataSource = dt;
                    comboBox1.DisplayMember = "display_text";
                    comboBox1.ValueMember = "login";
                    comboBox1.SelectedIndex = -1;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка загрузки");
            }
        }
        string GetHashPass(string password)
        {
            byte[] bytes = Encoding.UTF8.GetBytes(password);
            using (SHA256 sha = SHA256.Create())
            {
                byte[] hash = sha.ComputeHash(bytes);
                StringBuilder sb = new StringBuilder();
                foreach (byte b in hash)
                    sb.Append(b.ToString("x2"));
                return sb.ToString();
            }
        }
        bool tryCaptcha(int captha, string text)
        {
            if (captha == 0 && text == "798yuhi") return true;
            if (captha == 1 && text == "zser67e") return true;
            if (captha == 2 && text == "8tyugh") return true;
            return false;
        }

        int randomImage()
        {
            int r = random.Next(img.Length);
            captha.Image = Image.FromFile(img[r]);
            return r;
        }

        private void authorize_Click(object sender, EventArgs e)
        {
            try
            {
                string login = comboBox1.SelectedValue?.ToString();
                string inputPassword = password.Text;

                if (string.IsNullOrEmpty(login))
                {
                    MessageBox.Show("Выберите пользователя");
                    return;
                }

                using (MySqlConnection con = new MySqlConnection(str))
                {
                    con.Open();

                    MySqlCommand cmd = new MySqlCommand(@"
                        SELECT u.password, c.name_category
                        FROM user u
                        INNER JOIN category c ON u.id_category = c.id_category
                        WHERE u.login = @login", con);

                    cmd.Parameters.AddWithValue("@login", login);

                    DataTable dt = new DataTable();
                    new MySqlDataAdapter(cmd).Fill(dt);

                    if (dt.Rows.Count == 0)
                    {
                        MessageBox.Show("Пользователь не найден");
                        return;
                    }

                    if (captchaEnabled)
                    {
                        if (!tryCaptcha(proverka, textBox1.Text))
                        {
                            failWithCaptcha++;
                            resetAfterFail();

                            if (failWithCaptcha == 3)
                                freezeForm();

                            MessageBox.Show("Неверная капча");
                            return;
                        }
                    }

                    string hashInput = GetHashPass(inputPassword);
                    string hashDB = dt.Rows[0]["password"].ToString();
                    string role = dt.Rows[0]["name_category"].ToString();

                    if (hashInput == hashDB)
                    {
                        this.Hide();

                        if (role == "Администратор")
                            new admin(role).ShowDialog();
                        else
                            new user(login).ShowDialog();

                        Close();
                    }
                    else
                    {
                        failCount++;

                        if (failCount > 1 && !captchaEnabled)
                            enableCaptcha();

                        if (captchaEnabled)
                        {
                            failWithCaptcha++;
                            if (failWithCaptcha == 2)
                                freezeForm();
                        }

                        resetAfterFail();
                        MessageBox.Show("Неверный пароль");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка");
            }
        }

        void enableCaptcha()
        {
            captchaEnabled = true;

            captha.Visible = true;
            textBox1.Visible = true;
            label3.Visible = true;
            reroll.Visible = true;

            proverka = randomImage();
        }

        void resetAfterFail()
        {
            password.Clear();
            textBox1.Clear();
            proverka = randomImage();
        }

        void freezeForm()
        {
            authorize.Enabled = false;
            MessageBox.Show("Превышено количество попыток.\nБлокировка на 10 секунд");
            Thread.Sleep(10000);
            authorize.Enabled = true;

            failWithCaptcha = 0;
        }

        private void reroll_Click(object sender, EventArgs e)
        {
            proverka = randomImage();
        }

        private void exit_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show(
            $"Вы точно хотите выйти?",
            "Подтверждение",
            MessageBoxButtons.YesNo,
            MessageBoxIcon.Warning);

            if (dr == DialogResult.Yes)
                Close();
        }
    }
}
