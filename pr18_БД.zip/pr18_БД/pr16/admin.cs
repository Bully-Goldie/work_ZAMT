﻿using MySql.Data.MySqlClient;
using System;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace pr16
{
    public partial class admin : Form
    {
        string str = "host=localhost;user=root;pwd=root;database=pr18_kichigin";
        string commandDevices = @"
                            SELECT 
                                w.work_id,
                                m.full_name AS master_fio,
                                m.specification AS specialization,
                                m.experience,
                                d.devices_id,
                                d.name AS device_name,
                                d.type AS device_type,
                                d.brand AS device_brand,
                                d.serial_number,
                                w.date_gave AS `Дата выдачи`,
                                w.date_return AS `Дата возврата`
                            FROM work w
                            INNER JOIN master m ON w.master_id = m.master_id
                            INNER JOIN devices d ON w.devices_id = d.devices_id
                            ORDER BY w.date_gave DESC;";

        public bool realClose = false;

        public admin(string userCategory)
        {
            InitializeComponent();

            if (userCategory != "Администратор")
            {
                MessageBox.Show("Доступ запрещён", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                Close();
                return;
            }

            LoadCategories();
            SetAddMode();
            LoadUsers();

            dataGridView1.BackgroundColor = Color.FromArgb(204, 102, 0);
            this.BackColor = Color.FromArgb(255, 255, 255);
            button3.BackColor = Color.FromArgb(255, 204, 153);
            button1.BackColor = Color.FromArgb(255, 204, 153);
            button6.BackColor = Color.FromArgb(255, 204, 153);

            dataGridView2.BackgroundColor = Color.FromArgb(204, 102, 0);
            add.BackColor = Color.FromArgb(255, 204, 153);
            button8.BackColor = Color.FromArgb(255, 204, 153);
            button9.BackColor = Color.FromArgb(255, 204, 153);


            LoadDevices();
            LoadMasters();
            LoadDeviceTypes();
            dateTimePicker1.Value = DateTime.Now;
            dateTimePicker1.MinDate = DateTime.Now;

            dataGridView2.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        }

        void LoadCategories()
        {
            using (MySqlConnection con = new MySqlConnection(str))
            {
                string sql = "SELECT id_category, name_category FROM category";
                MySqlDataAdapter da = new MySqlDataAdapter(sql, con);
                DataTable dt = new DataTable();
                da.Fill(dt);

                comboBox1.DataSource = dt;
                comboBox1.DisplayMember = "name_category";
                comboBox1.ValueMember = "id_category";
                comboBox1.SelectedIndex = -1;
            }
        }

        void LoadUsers()
        {
            using (MySqlConnection con = new MySqlConnection(str))
            {
                string sql = @"
                    SELECT 
                        u.id,
                        u.login,
                        c.name_category AS category,
                        u.full_name,
                        u.phone,
                        u.create_account,
                        u.mode_account,
                        u.id_category
                    FROM user u
                    INNER JOIN category c ON u.id_category = c.id_category";

                MySqlDataAdapter da = new MySqlDataAdapter(sql, con);
                DataTable dt = new DataTable();
                da.Fill(dt);

                dataGridView1.DataSource = dt;

                dataGridView1.Columns["id"].Visible = false;
                dataGridView1.Columns["id_category"].Visible = false;

                dataGridView1.Columns["login"].HeaderText = "Логин";
                dataGridView1.Columns["category"].HeaderText = "Категория";
                dataGridView1.Columns["full_name"].HeaderText = "ФИО";
                dataGridView1.Columns["phone"].HeaderText = "Телефон";
                dataGridView1.Columns["create_account"].HeaderText = "Дата создания";
                dataGridView1.Columns["mode_account"].HeaderText = "Дата изменения";

                dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
                dataGridView1.ReadOnly = true;
                dataGridView1.AllowUserToAddRows = false;
                dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            }
        }

        void SetAddMode()
        {
            button3.Enabled = true;
            button1.Enabled = false;
            button6.Enabled = false;
        }

        void SetEditMode()
        {
            button3.Enabled = false;
            button1.Enabled = true;
            button6.Enabled = true;
        }

        bool ValidateInput()
        {
            if (string.IsNullOrWhiteSpace(textBox1.Text))
            {
                MessageBox.Show("Введите логин");
                return false;
            }
            if (string.IsNullOrWhiteSpace(textBox3.Text))
            {
                MessageBox.Show("Введите пароль");
                return false;
            }
            if (comboBox1.SelectedIndex == -1)
            {
                MessageBox.Show("Выберите категорию");
                return false;
            }
            if (string.IsNullOrWhiteSpace(textBox2.Text))
            {
                MessageBox.Show("Введите ФИО");
                return false;
            }
            if (!maskedTextBox1.MaskCompleted)
            {
                MessageBox.Show("Введите номер телефона полностью");
                return false;
            }
            return true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            const string chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*";
            Random rnd = new Random();
            int length = rnd.Next(4, 9);

            StringBuilder pass = new StringBuilder();
            for (int i = 0; i < length; i++)
                pass.Append(chars[rnd.Next(chars.Length)]);

            textBox3.Text = pass.ToString();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (!ValidateInput()) return;

            try
            {
                using (MySqlConnection con = new MySqlConnection(str))
                {
                    con.Open();

                    MySqlCommand check = new MySqlCommand(
                        "SELECT COUNT(*) FROM user WHERE login=@login", con);
                    check.Parameters.AddWithValue("@login", textBox1.Text);

                    if (Convert.ToInt32(check.ExecuteScalar()) > 0)
                    {
                        MessageBox.Show("Пользователь с таким логином уже существует");
                        return;
                    }

                    MySqlCommand cmd = new MySqlCommand(@"
                        INSERT INTO user
                        (login, password, id_category, full_name, phone, create_account, mode_account)
                        VALUES
                        (@login, SHA2(@pass,256), @id_cat, @fio, @phone, NOW(), NOW())", con);

                    cmd.Parameters.AddWithValue("@login", textBox1.Text);
                    cmd.Parameters.AddWithValue("@pass", textBox3.Text);
                    cmd.Parameters.AddWithValue("@id_cat", comboBox1.SelectedValue);
                    cmd.Parameters.AddWithValue("@fio", textBox2.Text);
                    cmd.Parameters.AddWithValue("@phone", maskedTextBox1.Text);

                    cmd.ExecuteNonQuery();

                    MessageBox.Show("Пользователь добавлен");
                    LoadUsers();
                    ClearForm();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка: " + ex.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow == null)
            {
                MessageBox.Show("Выберите пользователя");
                return;
            }

            if (!ValidateInput()) return;

            try
            {
                int id = Convert.ToInt32(dataGridView1.CurrentRow.Cells["id"].Value);

                using (MySqlConnection con = new MySqlConnection(str))
                {
                    con.Open();

                    MySqlCommand cmd;

                    if (string.IsNullOrWhiteSpace(textBox3.Text))
                    {
                        cmd = new MySqlCommand(@"
                    UPDATE user SET
                    login=@login,
                    id_category=@id_cat,
                    full_name=@fio,
                    phone=@phone,
                    mode_account=NOW()
                    WHERE id=@id", con);
                    }
                    else
                    {
                        cmd = new MySqlCommand(@"
                    UPDATE user SET
                    login=@login,
                    password=SHA2(@pass,256),
                    id_category=@id_cat,
                    full_name=@fio,
                    phone=@phone,
                    mode_account=NOW()
                    WHERE id=@id", con);
                        cmd.Parameters.AddWithValue("@pass", textBox3.Text);
                    }

                    cmd.Parameters.AddWithValue("@id", id);
                    cmd.Parameters.AddWithValue("@login", textBox1.Text);
                    cmd.Parameters.AddWithValue("@id_cat", comboBox1.SelectedValue);
                    cmd.Parameters.AddWithValue("@fio", textBox2.Text);
                    cmd.Parameters.AddWithValue("@phone", maskedTextBox1.Text);

                    cmd.ExecuteNonQuery();

                    MessageBox.Show("Данные обновлены");
                    LoadUsers();
                    ClearForm();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка: " + ex.Message);
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            textBox1.Text = dataGridView1.Rows[e.RowIndex].Cells["login"].Value.ToString();
            comboBox1.Text = dataGridView1.Rows[e.RowIndex].Cells["category"].Value.ToString();
            textBox2.Text = dataGridView1.Rows[e.RowIndex].Cells["full_name"].Value.ToString();
            maskedTextBox1.Text = dataGridView1.Rows[e.RowIndex].Cells["phone"].Value.ToString();

            SetEditMode();
        }

        void ClearForm()
        {
            textBox1.Text = "";
            textBox3.Text = "";
            comboBox1.SelectedIndex = -1;
            textBox2.Text = "";
            maskedTextBox1.Text = "";

            dataGridView1.ClearSelection();
            SetAddMode();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            ClearForm();
        }

        private void exit_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show(
            "Вы точно хотите выйти?",
            "Подтверждение",
            MessageBoxButtons.YesNo,
            MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                authorization authorizationForm = new authorization();
                this.Visible = false;
                authorizationForm.ShowDialog();
                this.Visible = false;
            }
        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (!realClose)
                e.Cancel = true;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow == null)
            {
                MessageBox.Show("Выберите пользователя для удаления");
                return;
            }

            string login = dataGridView1.CurrentRow.Cells["login"].Value.ToString();

            DialogResult dr = MessageBox.Show(
                $"Вы действительно хотите удалить пользователя '{login}'?",
                "Подтверждение удаления",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning);

            if (dr != DialogResult.Yes) return;

            try
            {
                int id = Convert.ToInt32(dataGridView1.CurrentRow.Cells["id"].Value);

                using (MySqlConnection con = new MySqlConnection(str))
                {
                    con.Open();

                    MySqlCommand cmd = new MySqlCommand("DELETE FROM user WHERE id=@id", con);
                    cmd.Parameters.AddWithValue("@id", id);
                    cmd.ExecuteNonQuery();
                }

                MessageBox.Show("Пользователь удалён");
                LoadUsers();
                ClearForm();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при удалении: " + ex.Message);
            }
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if ((ch >= 'А' && ch <= 'я') || ch == (char)Keys.Back || ch == (char)Keys.Space)
                e.Handled = false;
            else
                e.Handled = true;
        }

        void LoadDevices()
        {
            try
            {
                using (MySqlConnection con = new MySqlConnection(str))
                {
                    con.Open();
                    MySqlDataAdapter da = new MySqlDataAdapter(commandDevices, con);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dataGridView2.DataSource = dt;

                    if (dataGridView2.Columns.Contains("work_id"))
                        dataGridView2.Columns["work_id"].Visible = false;

                    dataGridView2.Columns["master_fio"].HeaderText = "ФИО мастера";
                    dataGridView2.Columns["specialization"].HeaderText = "Специализация";
                    dataGridView2.Columns["experience"].HeaderText = "Опыт (лет)";
                    dataGridView2.Columns["device_name"].HeaderText = "Название устройства";
                    dataGridView2.Columns["device_type"].HeaderText = "Тип устройства";
                    dataGridView2.Columns["device_brand"].HeaderText = "Бренд";
                    dataGridView2.Columns["serial_number"].HeaderText = "Серийный номер";
                    dataGridView2.Columns["Дата выдачи"].HeaderText = "Дата выдачи";
                    dataGridView2.Columns["Дата возврата"].HeaderText = "Дата возврата";

                    dataGridView2.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                    dataGridView2.Columns["devices_id"].Visible = false;
                    UpdateDeviceButtons(false);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки устройств: " + ex.Message);
            }
        }

        void LoadMasters()
        {
            try
            {
                using (MySqlConnection con = new MySqlConnection(str))
                {
                    con.Open();
                    string sql = "SELECT master_id, full_name FROM master";
                    MySqlDataAdapter da = new MySqlDataAdapter(sql, con);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    comboBox3.DataSource = dt;
                    comboBox3.DisplayMember = "full_name";
                    comboBox3.ValueMember = "master_id";
                    comboBox3.SelectedIndex = -1;
                    comboBox3.DropDownStyle = ComboBoxStyle.DropDownList;
                    UpdateDeviceButtons(false);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки мастеров: " + ex.Message);
            }
        }

        void LoadDeviceTypes()
        {
            try
            {
                using (MySqlConnection con = new MySqlConnection(str))
                {
                    con.Open();
                    string sql = "SELECT DISTINCT type FROM devices";
                    MySqlDataAdapter da = new MySqlDataAdapter(sql, con);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    comboBox2.DataSource = dt;
                    comboBox2.DisplayMember = "type";
                    comboBox2.ValueMember = "type";
                    comboBox2.SelectedIndex = -1;
                    comboBox2.DropDownStyle = ComboBoxStyle.DropDownList;

                    UpdateDeviceButtons(false);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки типов устройств: " + ex.Message);
            }
        }

        private void add_Click(object sender, EventArgs e)
        {
            if (comboBox3.SelectedIndex == -1)
            {
                MessageBox.Show("Выберите мастера!");
                return;
            }
            if (comboBox2.SelectedIndex == -1)
            {
                MessageBox.Show("Выберите тип техники!");
                return;
            }
            if (string.IsNullOrWhiteSpace(textBox4.Text))
            {
                MessageBox.Show("Введите бренд техники!");
                return;
            }

            try
            {
                using (MySqlConnection con = new MySqlConnection(str))
                {
                    con.Open();

                    int masterId = Convert.ToInt32(comboBox3.SelectedValue);
                    string type = comboBox2.Text;
                    string brand = textBox4.Text;
                    string dateGave = DateTime.Now.ToString("yyyy-MM-dd");
                    string dateReturn = dateTimePicker1.Value.ToString("yyyy-MM-dd");

                    string insertDevice = @"INSERT INTO devices(name, type, brand, serial_number)
                                            VALUES('Техника', @type, @brand, FLOOR(RAND()*900000)+100000)";
                    MySqlCommand cmdDevice = new MySqlCommand(insertDevice, con);
                    cmdDevice.Parameters.AddWithValue("@type", type);
                    cmdDevice.Parameters.AddWithValue("@brand", brand);
                    cmdDevice.ExecuteNonQuery();

                    int deviceId = (int)cmdDevice.LastInsertedId;

                    string insertWork = @"INSERT INTO work(master_id, devices_id, date_gave, date_return)
                                          VALUES(@master, @device, @gave, @return)";
                    MySqlCommand cmdWork = new MySqlCommand(insertWork, con);
                    cmdWork.Parameters.AddWithValue("@master", masterId);
                    cmdWork.Parameters.AddWithValue("@device", deviceId);
                    cmdWork.Parameters.AddWithValue("@gave", dateGave);
                    cmdWork.Parameters.AddWithValue("@return", dateReturn);
                    cmdWork.ExecuteNonQuery();
                }

                MessageBox.Show("Запись успешно добавлена!");
                LoadDevices();
                comboBox3.SelectedIndex = -1;
                comboBox2.SelectedIndex = -1;
                textBox4.Clear();
                dateTimePicker1.Value = DateTime.Now;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка добавления: " + ex.Message);
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (dataGridView2.CurrentRow == null)
            {
                MessageBox.Show("Выберите запись для редактирования");
                return;
            }

            if (comboBox3.SelectedIndex == -1 || comboBox2.SelectedIndex == -1 || string.IsNullOrWhiteSpace(textBox4.Text))
            {
                MessageBox.Show("Заполните все поля!");
                return;
            }

            DateTime returnDate = Convert.ToDateTime(dataGridView2.CurrentRow.Cells["Дата возврата"].Value);
            if (returnDate < DateTime.Today)
            {
                MessageBox.Show("Редактирование запрещено! Дата возврата уже прошла.");
                return;
            }

            try
            {
                using (MySqlConnection con = new MySqlConnection(str))
                {
                    con.Open();

                    int workId = Convert.ToInt32(dataGridView2.CurrentRow.Cells["work_id"].Value);
                    int masterId = Convert.ToInt32(comboBox3.SelectedValue);
                    string type = comboBox2.Text;
                    string brand = textBox4.Text;
                    string dateReturn = dateTimePicker1.Value.ToString("yyyy-MM-dd");

                    int deviceId = Convert.ToInt32(dataGridView2.CurrentRow.Cells["devices_id"].Value);
                    string updateDevice = @"UPDATE devices SET type=@type, brand=@brand WHERE devices_id=@id";
                    MySqlCommand cmdDevice = new MySqlCommand(updateDevice, con);
                    cmdDevice.Parameters.AddWithValue("@type", type);
                    cmdDevice.Parameters.AddWithValue("@brand", brand);
                    cmdDevice.Parameters.AddWithValue("@id", deviceId);
                    cmdDevice.ExecuteNonQuery();

                    string updateWork = @"UPDATE work SET master_id=@master, date_return=@return WHERE work_id=@work";
                    MySqlCommand cmdWork = new MySqlCommand(updateWork, con);
                    cmdWork.Parameters.AddWithValue("@master", masterId);
                    cmdWork.Parameters.AddWithValue("@return", dateReturn);
                    cmdWork.Parameters.AddWithValue("@work", workId);
                    cmdWork.ExecuteNonQuery();
                }

                MessageBox.Show("Запись обновлена!");
                LoadDevices();
                comboBox3.SelectedIndex = -1;
                comboBox2.SelectedIndex = -1;
                textBox4.Clear();
                dateTimePicker1.Value = DateTime.Now;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка редактирования: " + ex.Message);
            }
        }

        private void dataGridView2_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            DataGridViewRow row = dataGridView2.Rows[e.RowIndex];

            comboBox3.Text = row.Cells["master_fio"].Value.ToString();
            comboBox2.Text = row.Cells["device_type"].Value.ToString();
            textBox4.Text = row.Cells["device_brand"].Value.ToString();

            DateTime returnDate = Convert.ToDateTime(row.Cells["Дата возврата"].Value);

            if (returnDate < dateTimePicker1.MinDate)
            {
                dateTimePicker1.Value = dateTimePicker1.MinDate;
            }
            else
            {
                dateTimePicker1.Value = returnDate;
            }
            UpdateDeviceButtons(true);
        }
        private void button9_Click(object sender, EventArgs e)
        {
            if (dataGridView2.CurrentRow == null)
            {
                MessageBox.Show("Выберите запись для удаления");
                return;
            }

            DateTime returnDate = Convert.ToDateTime(dataGridView2.CurrentRow.Cells["Дата возврата"].Value);
            if (returnDate < DateTime.Today)
            {
                MessageBox.Show("Удаление запрещено! Дата возврата уже прошла.");
                return;
            }

            DialogResult dr = MessageBox.Show("Вы действительно хотите удалить запись?", "Подтверждение", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (dr != DialogResult.Yes) return;

            try
            {
                using (MySqlConnection con = new MySqlConnection(str))
                {
                    con.Open();
                    int workId = Convert.ToInt32(dataGridView2.CurrentRow.Cells["work_id"].Value);
                    MySqlCommand cmd = new MySqlCommand("DELETE FROM work WHERE work_id=@id", con);
                    cmd.Parameters.AddWithValue("@id", workId);
                    cmd.ExecuteNonQuery();
                }
                MessageBox.Show("Запись удалена!");
                LoadDevices();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка удаления: " + ex.Message);
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            comboBox3.SelectedIndex = -1;
            comboBox2.SelectedIndex = -1;
            textBox4.Text = "";
            dateTimePicker1.Value = DateTime.Now;

            dataGridView2.ClearSelection();
            UpdateDeviceButtons(false);
        }
        void UpdateDeviceButtons(bool isRowSelected)
        {
            add.Enabled = !isRowSelected;
            button8.Enabled = isRowSelected;
            button9.Enabled = isRowSelected;
        }

        private void button11_Click(object sender, EventArgs e)
        {
            addMaster open = new addMaster();
            open.ShowDialog();
            LoadMasters();
        }
    }
}
