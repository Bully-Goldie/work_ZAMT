import math

n=int(input('Введите число квадратной матрицы:\n'))
A=[]
for i in range(n):
    A.append([])
    for j in range(n):
        A[i].append(math.sqrt(2*j+1)+(math.tan(i)))

outfile=open('lab12_1.out','w')
print("Сгенерированная матрица:")
for row in A:
    print(row,file=outfile)
    print(row)

A2=[]
for i in range(n):
    A2.append(A[i][0])
a=sum(A2)
print('Сумма элементов первого столбца: ',a,file=outfile)
print('Сумма элементов первого столбца: ',a)

b=1
for j in range(n):
    if n>1:
        b*=(A[1][j])
print('Произведение элементов второй строки: ',b,file=outfile)
print('Произведение элементов второй строки: ',b)

c=0
for i in A:
    c+=sum(i)
f=c/(n*n)
print('Среднее арифметическое элементов матрицы A: ', f,file=outfile)
print('Среднее арифметическое элементов матрицы A: ', f)
outfile.close()