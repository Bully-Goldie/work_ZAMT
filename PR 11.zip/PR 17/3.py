import math

def input_array():
    print("Введите 10 элементов массива:")
    return [float(input(f"F[{i}] = ")) for i in range(10)]

def print_array(arr, label="Массив"):
    print(f"{label}: {arr}")

def sum_elements(arr):
    return sum(arr)

def product_elements(arr):
    product = 1
    for el in arr:
        product *= el
    return product

def calculate_g(F, k):
    G = []
    for F_i in F:
        if F_i != 0:
            G_i = k ** 3 + (k * math.sin(F_i)) / (math.sqrt(F_i) + 1)
        else:
            G_i = k ** 3
        G.append(G_i)
    return G

def sum_negative_elements(arr):
    return sum(el for el in arr if el < 0)

def replace_even_index_with_abs(arr, value):
    return [abs(value) if i % 2 == 0 else el for i, el in enumerate(arr)]

F = input_array()
print_array(F, "Исходный массив F")

k = float(input("Введите значение k: "))

sum_F = sum_elements(F)
product_F = product_elements(F)
print(f"Сумма элементов массива F: {sum_F}")
print(f"Произведение элементов массива F: {product_F}")

G = calculate_g(F, k)
print_array(G, "Массив G после вычислений")

sum_negative_G = sum_negative_elements(G)
print(f"Сумма отрицательных элементов массива G: {sum_negative_G}")

G_modified = replace_even_index_with_abs(G, sum_negative_G)
print_array(G_modified, "Массив G после замены четных индексов")