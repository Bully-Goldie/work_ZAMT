import math

def compute_series_sum(x, m):
    series_sum = 0 
    for n in range(m + 1):
        term = math.sin(n * x) / ((4 * n**2 - 1)**2)
        series_sum += term
        print(f"Текущий член при n={n}: {term:.5f}, Сумма ряда: {series_sum:.5f}")
    return series_sum

x = int(input("Введите значение x: "))
m = int(input("Введите значение m: "))
final_sum = compute_series_sum(x, m)
print("\nИтоговая сумма ряда: ",final_sum)