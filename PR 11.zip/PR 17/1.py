import math

def error():
    print ('Ошибка вычисления!')

k1=int(input('Введите число k1:'))
k2=int(input('введите число k2:'))

for y in range(1,7):
    if k1!=0 and k2!=0:
        g=(5*math.pow(y,2)/(k1))-k2*(math.atan(2/2-y))
        print(g)
    else:
        error()
        continue