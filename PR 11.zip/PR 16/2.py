#2.1
compitem=['Испанские тапас','Итальянские кростини','Датские сморреброды']
def comp_sengw(*compitem):
    print('Вы заказали:')
    for comp in compitem:
        print(comp)
comp_sengw('Испанские тапас','Итальянские кростини','Датские сморреброды')
comp_sengw('Испанские тапас','Итальянские кростини')
comp_sengw('Испанские тапас')

#2.2
def  build_profile(first,last,**user_info):
    profile = {}
    profile['first_name'] = first 
    profile['last_name'] = last
    for key, value in user_info.items(): 
        profile[key] = value 
        return profile
user_profile = build_profile('Иван', 'Кичигин', location='Воскресенское', field='программист')
print(user_profile)

#2.3
def  make_car(first,last,**car_info):
    profile = {}
    profile['name_car_first'] = first
    profile['outback_last'] = last
    for key, value in car_info.items(): 
        profile[key] = value 
        return profile
car = make_car('subaru', 'outback', color='blue', tow_package=True)
print(car)