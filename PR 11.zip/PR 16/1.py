#1.1

mag=['Иван','Алексей','Артем']

def  show_magicians(mag):
    for mag in mag:
        print(mag)

#1.2
def make_great(mag):
    for i in range(len(mag)):
        mag[i] = "Great "+mag[i]
    return mag

show_magicians(mag)
mag=make_great(mag)
show_magicians(mag)