class Hero:
    def __init__(self, name, health, damage, defense):
        self.name = name
        self.health = health
        self.damage = damage
        self.defense = defense if defense <= 100 else 100

    def get_status(self):
        return f"Имя: {self.name}, Здоровье: {self.health}, Урон: {self.damage}, Защита: {self.defense}"

    def increase_defense(self):
        self.defense = int(self.defense * 1.5)
        if self.defense > 100:
            self.defense = 100

    def take_damage(self, incoming_damage):
        blocked_damage = incoming_damage * self.defense / 100
        effective_damage = incoming_damage - blocked_damage
        self.health -= int(effective_damage)
        if self.health < 0:
            self.health = 0

hero = Hero("Герой", 100, 20, 50)

print("Начальные параметры:")
print(hero.get_status())

print("\nГерой увеличивает защиту:")
hero.increase_defense()
print(hero.get_status())

print("\nГерой получает урон (31):")
hero.take_damage(31)
print(hero.get_status())