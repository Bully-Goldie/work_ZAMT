lear=('learning_python.txt')

with open(lear) as file_object:
    file1 = file_object.read()
    print(file1)
    
with open(lear) as file_object:
    for file2 in file_object:
        print(file2)

with open(lear) as file3:
    lines = file3.readlines()
    for line in lines:
        print(line.rstrip())