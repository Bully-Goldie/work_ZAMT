filename="guest_book.txt"

with open (filename, 'w') as file_object:
    while True:
        name=input('Введите имена гостей(чтобы прекратить напишите закрыть): ')
        if name == "закрыть":
            break
        elif name == 'закрыть':
            break
        file_object.write("Приветствую " + name + '\n')
