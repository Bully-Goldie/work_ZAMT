filename="opros.txt"

with open (filename, 'w') as file_object:
    while True:
        name=input('Напишите причину почему вы любите программировать(чтобы прекратить напишите закрыть): ')
        if name == "Закрыть":
            break
        elif name == 'закрыть':
            break
        file_object.write(name + '\n')