import math

n = int(input("Р—Р°РґР°Р№С‚Рµ n:\n"))
x = -1

while x <= 5:
    if x - n < 1:
        if x >= 0:
            y = 2 * math.sqrt(x) - n * x
        else:
            y = -n * x
    else:
        y = math.sqrt(x**2 + math.cos(n * x))

    print("x = {:.2f} y(x) = {:.4f}".format(x, y))
    
    x += 0.6