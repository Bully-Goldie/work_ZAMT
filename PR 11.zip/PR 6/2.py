import math
import numpy

k1 = 1
k2 = 2

for a in numpy.arange(-1, 6.1, 0.3):
    cot = 1 / math.tan(a**2)
    if abs(cot - k1) == 0: continue
    if (k2 - a) < 0: continue
    f = (k2 - a) / math.log(abs(cot - k1))
    print("a =", "%.2f" % a, " f(x) =", "%.4f" % f)