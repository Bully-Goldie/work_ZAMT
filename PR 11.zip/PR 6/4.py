import math

n = int(input("Р—Р°РґР°Р№С‚Рµ n:\n"))
x = -1
while True:
    if x >= 0:
        y = 2 * math.sqrt(x) - n * x
        print("{0} {1:.2f} {2} {3:.4f}".format("x =", x, "y(x) =", y))
    else:
        print("{0} {1:.2f} {2} {3}".format("x =", x, "y(x) =", "РЅРµ РѕРїСЂРµРґРµР»РµРЅРѕ"))

    if x - n + 1 >= 0:
        y = math.sqrt(x ** 2 + math.cos(n * x))
        print("{0} {1:.2f} {2} {3:.4f}".format("x =", x, "y(x) =", y))
        break

    x += 1