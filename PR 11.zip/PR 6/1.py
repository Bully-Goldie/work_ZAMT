import math

x=float(input("Р’РІРµРґРёС‚Рµ С‡РёСЃР»Рѕ x:"))
n=float(input("Р’РІРµРґС‰РёС‚Рµ С‡РёСЃР»Рѕ n:"))


if x-n<1:
    f=2*math.sqrt(x)-n*x
elif x-n>=1:
    f=math.sqrt(x**2 + math.cos(n * x))
print(f)