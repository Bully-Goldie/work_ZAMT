import math

infile = open('lab13_1.in', 'r')
lab_13_1 = infile.readline()
D = lab_13_1.split('\t')
D = list(map(int, D))
infile.close()

b = int(input("Введите число b:\n"))
Z = []
for i in range(len(D)):
    if 2 * D[i] >= 0:
        Z.append(math.sqrt(2 * D[i]) + (b * math.tan(D[i])))
    else:
        Z.append(-math.sqrt(abs(2 * D[i])) + (b * math.tan(D[i])))
outfile=open('lab12_1.out','w')
for i in range(len(Z)):
    print('{0:.2f}'.format(Z[i]), end=' ', file=outfile)
    print('{0:.2f}'.format(Z[i]), end=' ')

a=sum(Z[i] for i in range(1, len(Z), 2))
print('{0} {1:.2f}' .format('\nСумма элементов массива Z с нечетными кол-во индексами: ', a), file=outfile)
print('{0} {1:.2f}' .format('\nСумма элементов массива Z с нечетными кол-во индексами: ', a))

b=sum(1 for z in Z if z < 0)
print('\nКол-во отрицательных элементов Z: ', b, file=outfile)
print('\nКол-во отрицательных элементов Z: ', b)
outfile.close()