# 1.1 and 1.2
class Restaurant:
    def __init__(self, restaurant_name, cuisine_type):
        self.restaurant_name=restaurant_name
        self.cuisine_type=cuisine_type

    def describe_restaurant(self):
        print("Название ресторана " + self.restaurant_name.title())
        print("Тип кухни: " + self.cuisine_type)

    def open_restaurant(self):
        print('Ресторан открыт!\n')

restaurant = Restaurant("Клод Моне","выпечка\n")
restaurant2 = Restaurant("Osteria Mario","Европейская кухня\n")
restaurant3 = Restaurant("Tehnikum","Африканская кухня\n")
restaurant.describe_restaurant()
restaurant2.describe_restaurant()
restaurant3.describe_restaurant()
restaurant.open_restaurant()

# 1.3
class User:
    def describe_user(self):
        print("Имя: " + self.first_name)
        print("Фамилия: " + self.last_name)
        print("Возраст: " + str(self.age))

    def greet_user(self):
        print("Привет!\n")

user1 = User()
user1.first_name = "Иван"
user1.last_name = "Кичигин"
user1.age = 17
user1.describe_user()
user1.greet_user()

user2 = User()
user2.first_name = "Артем"
user2.last_name = "Акакий"
user2.age = 17
user2.describe_user()
user2.greet_user()

# 1.4
class Restaurant:
    def __init__(self, restaurant_name, cuisine_type):
        self.restaurant_name = restaurant_name
        self.cuisine_type = cuisine_type
        self.number_served = 0

    def describe_restaurant(self):
        print(f"Ресторан: {self.restaurant_name}")
        print(f"Тип кухни: {self.cuisine_type}")

    def open_restaurant(self):
        print(f"{self.restaurant_name} открыт!")

    def set_number_served(self, number):
        self.number_served = number

    def increment_number_served(self, number):
        self.number_served += number

restaurant = Restaurant("Итальянский уголок", "Итальянская")
print(f"Количество обслуженных посетителей: {restaurant.number_served}")

restaurant.set_number_served(5)
print(f"Количество обслуженных посетителей: {restaurant.number_served}")

restaurant.increment_number_served(10)
print(f"Количество обслуженных посетителей: {restaurant.number_served}\n")

# 1.5
class User:
    first_name = ""
    last_name = ""
    age = 0
    login_attempts = 0

    def describe_user(self):
        print("Имя: " + self.first_name)
        print("Фамилия: " + self.last_name)
        print("Возраст: " + str(self.age))

    def greet_user(self):
        print("Привет!\n")

    def increment_login_attempts(self):
        self.login_attempts += 1

    def reset_login_attempts(self):
        self.login_attempts = 0

user1 = User()
user1.first_name = "Иван"
user1.last_name = "Кичигин"
user1.age = 17
user1.describe_user()
user1.greet_user()

user1.increment_login_attempts()
user1.increment_login_attempts()
user1.increment_login_attempts()

print(f"Количество попыток входа: {user1.login_attempts}")

user1.reset_login_attempts()
print(f"Количество попыток входа после сброса: {user1.login_attempts}")