class Restaurant:
    def __init__(self, restaurant_name, cuisine_type):
        self.restaurant_name=restaurant_name
        self.cuisine_type=cuisine_type

    def describe_restaurant(self):
        print("Название ресторана " + self.restaurant_name.title())
        print("Тип кухни: " + self.cuisine_type)

    def open_restaurant(self):
        print('Ресторан открыт!\n')

class IceCreamStand(Restaurant):
    def __init__(self, restaurant_name, cuisine_type, flavors):
        super().__init__(restaurant_name, cuisine_type)
        self.flavors=flavors
    
    def show_list(self):
        for flavor in self.flavors:
            print(flavor)

ice=IceCreamStand("Клод Моне","мороженое\n", ['Молочное', 'Сливочное', 'Пломбир', 'Фруктовый лёд', 'Йогуртовое'])
ice.show_list()