import res

a = res.Restaurant("Итальянский уголок", "Итальянская")
a.describe_restaurant()