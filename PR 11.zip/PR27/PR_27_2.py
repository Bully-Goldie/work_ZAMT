class User:
    def __init__(self, first_name, last_name, age):
        self.first_name=first_name
        self.last_name=last_name
        self.age=age
    
    def print_user(self):
        print(self.first_name, self.last_name, self.age)

    def greet_user(self):
        print("Привет!\n")

class Admin(User):
    def __init__(self, first_name, last_name, age, privileges):
        super().__init__(first_name, last_name, age)
        self.privileges=privileges

    def show_privileges(self):
        for privileges in self.privileges:
            print(privileges)

adm=Admin('иван', 'кичигин', 17, ['разрешено добавлять сообщения', 'разрешено удалять пользователей', 'разрешено банить пользователей'])
adm.show_privileges()