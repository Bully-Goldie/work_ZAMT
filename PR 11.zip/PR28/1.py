class Dog():
    def __init__(self, __name, __happiness=0):
        self.__name = __name
        self.__happiness = __happiness

    def caress(self, new_happiness):
        self.__happiness = new_happiness + 10
        return "Гав-гав!"
    
    def set_name(self, new_name):
        if new_name.isalpha():
            self.__name = new_name
            return f"Теперь собаку зовут {self.__name}!"
        else:
            return "В имени собаки должны быть только буквы!"
        
    def get_name(self):
        return f"Собаку зовут {self.__name}"
    
    def bring_item(self, item, distance):
        if distance <= 100 and self.__happiness >= 10:
            return f"{self.__name} принес(ла) предмет: {item}"
        elif distance > 100:
            return f"{item} находится слишком далеко!"
        elif self.__happiness < 10:
            return f"{self.__name} нуждается в заботе!"

Lucky = Dog("Шарик")
print(Lucky.caress(0))
print(Lucky.bring_item("палка", 20))
print(Lucky.set_name("Бобик"))