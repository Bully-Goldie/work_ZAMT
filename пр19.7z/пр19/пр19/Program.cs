﻿using System;
using System.Xml;
using System.Xml.Linq;

namespace пр19
{
    internal class Program
    {
        static double TriangleS(double a)
        {
            return ((Math.Pow(a, 2)) * (Math.Pow(3, 0.5))) / 4;
        }
        static void Main(string[] args)
        {
            // Задание 1
            // Дано четырехзначное целое ненулевое положительное число N (N>0).
            // Проверить истинность высказывания: "Все цифры данного числа различны".
            try
            {
                XmlDocument doc = new XmlDocument();
                doc.Load("input1.xml");

                XmlNodeList items = doc.GetElementsByTagName("PR19");

                int N = 0;

                foreach (XmlNode item in items)
                {
                    N = Convert.ToInt32(item["value"].InnerText);
                }

                int one = (N / 1000) % 10;
                int two = (N / 100) % 10;
                int three = (N / 10) % 10;
                int four = N % 10;

                if (one != two || two != three || three != four)
                {
                    XDocument xdoc = new XDocument(
                        new XElement("PR19",
                            new XElement("Result", "Все цифры данного числа различны")
                        )
                    );

                    string filePath = "output1.xml";

                    xdoc.Save(filePath);
                }
                else
                {
                    XDocument xdoc = new XDocument(
                        new XElement("PR19",
                            new XElement("Result", "Не все цифры данного числа различны")
                        )
                    );

                    string filePath = "output1.xml";

                    xdoc.Save(filePath);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            // Задание 2
            // Ввести пять различных ненулевых целых чисел. Найти произведение трех наибольших чисел.
            try
            {
                XmlDocument doc = new XmlDocument();
                doc.Load("input2.xml");

                XmlNodeList items = doc.GetElementsByTagName("PR19");

                int A = 0;
                int B = 0;
                int C = 0;
                int D = 0;
                int F = 0;

                foreach (XmlNode item in items)
                {
                    A = Convert.ToInt32(item["value1"].InnerText);
                    B = Convert.ToInt32(item["value2"].InnerText);
                    C = Convert.ToInt32(item["value3"].InnerText);
                    D = Convert.ToInt32(item["value4"].InnerText);
                    F = Convert.ToInt32(item["value5"].InnerText);
                }

                int[] array = {A, B, C, D, F};
                Array.Sort(array);

                int res = array[0] + array[1] + array[2];

                XDocument xdoc = new XDocument(
                    new XElement("PR19",
                        new XElement("Result", $"{res}")
                    )
                );

                string filePath = "output2.xml";

                xdoc.Save(filePath);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            // Задание 3
            // Дан целочисленный массив, состоящий из N элементов (N > 0).
            // Если в наборе имеются отрицательные нечетные числа, то найти сумму всех положительных четных чисел,
            // иначе вычислить сумму всех чисел, которые кратные числу 5.
            try
            {
                XmlDocument doc = new XmlDocument();
                doc.Load("input3.xml");

                XmlNodeList items = doc.GetElementsByTagName("PR19");

                string str = "";

                foreach (XmlNode item in items)
                {
                    str = item["value"].InnerText;
                }

                string[] chararray = str.Split('_');

                int[] array = new int[chararray.Length];
                for (int i = 0; i < chararray.Length; i++)
                {
                    array[i] += Convert.ToInt32(chararray[i]);
                }

                bool check = true;

                for (int i = 0; i < array.Length; i++)
                {
                    if (array[i] < 0 && array[i] % 2 != 0)
                    {
                        check = false;
                        break;
                    }
                }

                int res = 0;
                if (check)
                {
                    for (int i = 0; i < array.Length; i++)
                    {
                        if (array[i] < 0 && array[i] % 2 != 0)
                        {
                            res += array[i];
                        }
                    }
                }
                else
                {
                    for(int i = 0;i < array.Length; i++)
                    {
                        if (array[i] % 5 == 0)
                        {
                            res += array[i];
                        }
                    }
                }

                    XDocument xdoc = new XDocument(
                        new XElement("PR19",
                            new XElement("Result", $"{res}")
                        )
                    );

                string filePath = "output3.xml";

                xdoc.Save(filePath);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            // Задание 4
            // Написать функцию double TriangleS(a) вещественного типа, вычисляющую по стороне a равностороннего треугольника его площадь
            // S = a2·(3)0.5/4 (параметр a является вещественным).
            // С помощью этой процедуры найти площади трех равносторонних треугольников с данными сторонами.
            try
            {
                XmlDocument doc = new XmlDocument();
                doc.Load("input4.xml");

                XmlNodeList items = doc.GetElementsByTagName("PR19");

                double a = 0;

                foreach (XmlNode item in items)
                {
                    a = Convert.ToInt32(item["value"].InnerText);
                }

                double res = TriangleS(a);

                XDocument xdoc = new XDocument(
                    new XElement("PR19",
                        new XElement("Result", $"{res}")
                    )
                );

                string filePath = "output4.xml";

                xdoc.Save(filePath);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
