﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace var10
{
    class Task4
    {
        public double Factorial(int N)
        {
            double res = 1;

            for (int i = 1; i <= N; i++)
            {
                res *= i;
            }

            return res;
        }
        public double Factorial(float N)
        {
            double res = 1;

            for (int i = 1; i <= N; i++)
            {
                res *= i;
            }

            return res;
        }
        public double Factorial(double N)
        {
            double res = 1;

            for (int i = 1; i <= N; i++)
            {
                res *= i;
            }

            return res;
        }
        public double Factorial(long N)
        {
            double res = 1;

            for (int i = 1; i <= N; i++)
            {
                res *= i;
            }

            return res;
        }
        public double Factorial(decimal N)
        {
            double res = 1;

            for (int i = 1; i <= N; i++)
            {
                res *= i;
            }

            return res;
        }
    }
}
