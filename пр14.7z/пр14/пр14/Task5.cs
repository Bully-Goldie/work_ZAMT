﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace пр14
{
    class Task5
    {
        public string StrClass(string str)
        {
            string[] chararray = str.Split(new char[] { ' ', '.', ',', '!', '?', ';', ':' }, StringSplitOptions.RemoveEmptyEntries);

            string max1 = string.Empty;
            int count = 0;

            for (int i = 0; i < chararray.Length; i++)
            {
                int countw = 0;

                for (int j = 0; j < chararray[i].Length; j++)
                {
                    if (chararray[i][j] == 'w')
                    {
                        countw++;
                    }
                }

                if (countw > count)
                {
                    count = countw;
                    max1 = chararray[i];
                }
            }

            return max1;
        }
    }
}
