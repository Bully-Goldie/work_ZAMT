﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace var10
{
    class Task3
    {
        public int Min5(int A, int B, int C, int D, int E)
        {
            int[] array = { A, B, C, D, E };

            Array.Sort(array);
            return array[0];
        }

        public double Min5(double A, double B, double C, double D, double E)
        {
            double[] array = { A, B, C, D, E };

            Array.Sort(array);
            return array[0];
        }

        public float Min5(float A, float B, float C, float D, float E)
        {
            float[] array = { A, B, C, D, E };

            Array.Sort(array);
            return array[0];
        }

        public long Min5(long A, long B, long C, long D, long E)
        {
            long[] array = { A, B, C, D, E };

            Array.Sort(array);
            return array[0];
        }

        public decimal Min5(decimal A, decimal B, decimal C, decimal D, decimal E)
        {
            decimal[] array = { A, B, C, D, E };

            Array.Sort(array);
            return array[0];
        }
    }
}
