﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace var10
{
    class Task1
    {
        public string Four(int N)
        {
            int one = (N / 1000) % 10;
            int two = (N / 100) % 10;
            int three = (N / 10) % 10;
            int four = N % 10;

            if(one == four && two == three)
            {
                return "Данное число N читается одинаково слева направо и справа налево";
            }
            else
            {
                return "Данное число N не читается одинаково слева направо и справа налево";
            }
        }
    }
}
