﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using var10;

namespace пр14
{
    class Program
    {
        static void Main(string[] args)
        {
            // Задание 1
            // Дано целое положительное четырехзначное ненулевое число N (N>0). Проверить истинность высказывания: «Данное число N читается одинаково слева направо и справа налево».
            m1:
            try
            {
                Console.WriteLine("Задание 1");
                Console.Write("Введите целое четырехзначное число: ");
                int N = Convert.ToInt32(Console.ReadLine());

                if(N>999 && N < 99999)
                {
                    Task1 four = new Task1();
                    string res1 = four.Four(N);

                    Console.WriteLine(res1);
                }
                else
                {
                    Console.WriteLine("Вы ввели не четырехзначное чилсло. Попробуйте еще раз...");
                    goto m1;
                }
            }
            catch (FormatException ex1)
            {
                Console.WriteLine(ex1.Message.ToString());
                goto m1;
            }
            catch (OverflowException ex2)
            {
                Console.WriteLine(ex2.Message.ToString());
                goto m1;
            }

            // Задание 2
            // Дано вещественное число A и целое число N (N > 0). Вывести значение результата A в степени N: AN = A*A*...*A (число A перемножается N раз).
            m2:
            try
            {
                Console.WriteLine("Задание 2");
                Console.Write("Введите число: ");
                double A = Convert.ToInt64(Console.ReadLine());
                Console.Write("Введите целое число: ");
                int N = Convert.ToInt32(Console.ReadLine());

                if (N > 0)
                {
                    Task2 stepen = new Task2();
                    double res2 = stepen.Stepen(A, N);

                    Console.WriteLine(res2);
                }
                else
                {
                    Console.WriteLine("Вы ввели не подходящее числа. Попробуйте еще раз...");
                    goto m2;
                }
            }
            catch (FormatException ex1)
            {
                Console.WriteLine(ex1.Message.ToString());
                goto m2;
            }
            catch (OverflowException ex2)
            {
                Console.WriteLine(ex2.Message.ToString());
                goto m2;
            }

            // Задание 3
            // Написать функцию int Min5(A, B, C, D, E) целого типа, возвращающую одно минимальное значение из 5-и своих аргументов (параметры A, B, C, D и E - целые числа).
            m3:
            try
            {
                Console.WriteLine("Задание 3");
                Console.WriteLine("Введите пять целых чисел:");
                int A = Convert.ToInt32(Console.ReadLine());
                int B = Convert.ToInt32(Console.ReadLine());
                int C = Convert.ToInt32(Console.ReadLine());
                int D = Convert.ToInt32(Console.ReadLine());
                int E = Convert.ToInt32(Console.ReadLine());

                Task3 Min5 = new Task3();

                int res3 = Min5.Min5(A, B, C, D, E);

                Console.WriteLine(res3);
            }
            catch (FormatException ex1)
            {
                Console.WriteLine(ex1.Message.ToString());
                goto m3;
            }
            catch (OverflowException ex2)
            {
                Console.WriteLine(ex2.Message.ToString());
                goto m3;
            }

            // Задание 4
            // Написать функцию double Factorial(N) вещественного типа, вычисляющую значение факториала N! = 1*2*…*N (N > 0 — параметр целого типа;
            // вещественное возвращаемое значение используется для того, чтобы избежать целочисленного переполнения при больших значениях N).
            m4:
            try
            {
                Console.WriteLine("Задание 4");
                Console.Write("Введите целое значение:");
                int N = Convert.ToInt32(Console.ReadLine());

                if (N > 0)
                {
                    Task4 Factorial = new Task4();
                    double res4 = Factorial.Factorial(N);

                    Console.WriteLine(res4);
                }
                else
                {
                    Console.WriteLine("Вы ввели не подходящее числа. Попробуйте еще раз...");
                    goto m4;
                }
            }
            catch (FormatException ex1)
            {
                Console.WriteLine(ex1.Message.ToString());
                goto m4;
            }
            catch (OverflowException ex2)
            {
                Console.WriteLine(ex2.Message.ToString());
                goto m4;
            }

            // Задание 5
            // Вводится строка-предложение на английском языке. Длина строки может быть разной. Определить и вывести слово, содержащего наибольшее число символов 'w'.

            Console.WriteLine("Задание 5");
            Console.WriteLine("Введите строку на английском языке:");
            string str = Console.ReadLine();

            Task5 Str = new Task5();
            string res5 = Str.StrClass(str);

            Console.WriteLine(res5);
        }
    }
}
