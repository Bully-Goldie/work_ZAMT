﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Word = Microsoft.Office.Interop.Word;

namespace pr21
{
    public partial class Form1 : Form
    {
        public int DigitN(int K, int N)
        {
            if (K < 0 || N <= 0)
            {
                return -1;
            }
            int a = 1;
            while (K > 0)
            {
                int b = K % 10;
                if (a == N)
                {
                    return b;
                }
                K /= 10;
                a++;
            }
            return -1;
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                //Задание 1
                int N = Convert.ToInt32(textBox1.Text);
                bool result = false;

                if (N >= 100 && N<=999)
                {
                    int n1 = (N / 1000) % 10;
                    int n2 = (N / 100) % 10;
                    int n3 = N % 10;

                    int one = n1 + n2;
                    int two = n2 + n3;

                    if (one == two)
                    {
                        result = true;
                    }
                    else
                    {
                        result = false;
                    }
                }

                //Задание 2
                int A = Convert.ToInt32(textBox2.Text);
                int B = Convert.ToInt32(textBox3.Text);

                int count = 0;
                int sum = 0;

                for (int i = A + 1; i < B; i++)
                {
                    if (i % 2 != 0)
                    {
                        count++;
                        sum += i;
                    }
                }

                int[] array = new int[count];
                int index = 0;

                for (int i = A + 1; i < B; i++)
                {
                    if (i % 2 != 0)
                    {
                        array[index] = i;
                        index++;
                    }
                }
                //Задание 5
                int K = Convert.ToInt32(textBox5.Text);
                int N1 = Convert.ToInt32(textBox4.Text);

                int result5 = DigitN(K, N);

                //создаем новый документ Word
                Word.Application wdApp = new Word.Application();
                Word.Document wdDoc = null;
                Object wdMiss = System.Reflection.Missing.Value;

                wdDoc = wdApp.Documents.Add(ref wdMiss, ref wdMiss, ref wdMiss, ref wdMiss);

                wdDoc.PageSetup.Orientation = Word.WdOrientation.wdOrientPortrait;

                wdDoc.PageSetup.TopMargin = wdApp.InchesToPoints(0.60f);
                wdDoc.PageSetup.BottomMargin = wdApp.InchesToPoints(0.60f);
                wdDoc.PageSetup.LeftMargin = wdApp.InchesToPoints(0.80f);
                wdDoc.PageSetup.RightMargin = wdApp.InchesToPoints(0.59f);

                wdApp.Visible = true;

                wdApp.ActiveWindow.Selection.ParagraphFormat.LineSpacingRule = Word.WdLineSpacing.wdLineSpaceSingle;
                wdApp.ActiveWindow.Selection.ParagraphFormat.SpaceAfter = 0.0F;

                Word.Paragraph oPara7;
                oPara7 = wdDoc.Content.Paragraphs.Add(ref wdMiss);
                oPara7.Range.Text = "МДК.01.01 Разработка программных модулей";
                oPara7.Alignment = Word.WdParagraphAlignment.wdAlignParagraphCenter;
                oPara7.Range.Font.Size = Convert.ToInt32(18);
                oPara7.Range.Font.Bold = 1;
                oPara7.Range.InsertParagraphAfter();
                oPara7.CloseUp();

                Word.Paragraph oPara8;
                oPara8 = wdDoc.Content.Paragraphs.Add(ref wdMiss);
                oPara8.Range.Text = "ПР21 «Программное создание документов MS Word в языке С#»\r\nВыполнил Абрамов, студент группы ИС-23Б\r\n";
                oPara8.Alignment = Word.WdParagraphAlignment.wdAlignParagraphJustify;
                oPara8.Range.Font.Size = Convert.ToInt32(16);
                oPara8.Range.Font.Bold = 0;
                wdApp.ActiveWindow.Selection.ParagraphFormat.LineSpacingRule = Word.WdLineSpacing.wdLineSpaceSingle;
                wdApp.ActiveWindow.Selection.ParagraphFormat.SpaceAfter = 0.0F;
                oPara8.Range.InsertParagraphAfter();
                oPara8.CloseUp();

                Word.Paragraph oPara1;
                oPara1 = wdDoc.Content.Paragraphs.Add(ref wdMiss);
                oPara1.Range.Text = string.Format("\r\nЗадание 1:\r\nначальное число 1: {0}\r\nрезультат: {1}\r\n", N, result);
                oPara1.Alignment = Word.WdParagraphAlignment.wdAlignParagraphJustify;
                oPara1.Range.Font.Size = Convert.ToInt32(16);
                oPara1.Range.Font.Bold = 0;
                wdApp.ActiveWindow.Selection.ParagraphFormat.LineSpacingRule = Word.WdLineSpacing.wdLineSpaceSingle;
                wdApp.ActiveWindow.Selection.ParagraphFormat.SpaceAfter = 0.0F;
                oPara1.Range.InsertParagraphAfter();
                oPara1.CloseUp();

                Word.Paragraph oPara2;
                oPara2 = wdDoc.Content.Paragraphs.Add(ref wdMiss);
                oPara2.Range.Text = string.Format("Задание 2:\r\nначальное число 1: {0}\r\nначальное число 1: {1}\r\nколичество: {2}\r\nсумма: {3}\r\nмассив: {4}\r\n", A, B, count, sum, string.Join(",", array));
                oPara2.Alignment = Word.WdParagraphAlignment.wdAlignParagraphJustify;
                oPara2.Range.Font.Size = Convert.ToInt32(16);
                oPara2.Range.Font.Bold = 0;
                wdApp.ActiveWindow.Selection.ParagraphFormat.LineSpacingRule = Word.WdLineSpacing.wdLineSpaceSingle;
                wdApp.ActiveWindow.Selection.ParagraphFormat.SpaceAfter = 0.0F;
                oPara2.Range.InsertParagraphAfter();
                oPara2.CloseUp();

                Word.Paragraph oPara5;
                oPara5 = wdDoc.Content.Paragraphs.Add(ref wdMiss);
                oPara5.Range.Text = string.Format("Задание 5:\r\nначальное число 1: {0}\r\nначальное число 1: {1}\r\nрезультат: {2}\r\n", K, N1, result5);
                oPara5.Alignment = Word.WdParagraphAlignment.wdAlignParagraphJustify;
                oPara5.Range.Font.Size = Convert.ToInt32(16);
                oPara5.Range.Font.Bold = 0;
                wdApp.ActiveWindow.Selection.ParagraphFormat.LineSpacingRule = Word.WdLineSpacing.wdLineSpaceSingle;
                wdApp.ActiveWindow.Selection.ParagraphFormat.SpaceAfter = 0.0F;
                oPara5.Range.InsertParagraphAfter();
                oPara5.CloseUp();

                try
                {
                    object filename = @"pr21" + ".doc";

                    wdDoc.SaveAs(ref filename);

                    wdDoc.Close(ref wdMiss, ref wdMiss, ref wdMiss);
                    wdDoc = null;

                    wdApp.Quit(ref wdMiss, ref wdMiss, ref wdMiss);
                    wdDoc = null;
                }
                catch (Exception y)
                {
                    Console.WriteLine("Ошибка сохранения документа", y.ToString());
                }
                label11.Text = "";
            }
            catch (Exception ex)
            {
                label11.Text = ex.Message;
                
            }
        }
    }
}
