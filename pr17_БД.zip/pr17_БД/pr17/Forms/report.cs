﻿using System;
using System.Data;
using System.IO;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using Word = Microsoft.Office.Interop.Word;

namespace pr17.Forms
{
    public partial class report : Form
    {
        string str = "host=localhost;uid=root;pwd=root;database=pr17_kichigin;";
        string command = @"SELECT 
                    w.work_id,
                    m.full_name AS master_fio,
                    m.specification AS specialization,
                    m.experience,
                    d.name AS device_name,
                    d.type AS device_type,
                    d.brand AS device_brand,
                    d.serial_number,
                    w.date_gave AS `Дата выдачи`,
                    w.date_return AS `Дата возврата`
                FROM work w
                INNER JOIN master m ON w.master_id = m.master_id
                INNER JOIN devices d ON w.devices_id = d.devices_id
                ORDER BY w.date_gave DESC;";
        string fileName = Directory.GetCurrentDirectory() + @"\template\report.docx";

        string master_fio, specialization, experience;
        string device_name, device_type, device_brand, serial_number;
        string date_gave, date_return;

        public report()
        {
            InitializeComponent();
        }

        private void report_Load(object sender, EventArgs e)
        {
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            LoadData();
        }

        void LoadData()
        {
            try
            {
                MySqlConnection conn = new MySqlConnection(str);
                conn.Open();
                MySqlCommand cmd = new MySqlCommand(command, conn);
                MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;

                dataGridView1.Columns["master_fio"].HeaderText = "ФИО мастера";
                dataGridView1.Columns["specialization"].HeaderText = "Специализация";
                dataGridView1.Columns["experience"].HeaderText = "Опыт (лет)";
                dataGridView1.Columns["device_name"].HeaderText = "Название устройства";
                dataGridView1.Columns["device_type"].HeaderText = "Тип устройства";
                dataGridView1.Columns["device_brand"].HeaderText = "Бренд";
                dataGridView1.Columns["serial_number"].HeaderText = "Серийный номер";
                dataGridView1.Columns["Дата выдачи"].HeaderText = "Дата выдачи";
                dataGridView1.Columns["Дата возврата"].HeaderText = "Дата возврата";

                if (dataGridView1.Columns.Contains("work_id"))
                {
                    dataGridView1.Columns["work_id"].Visible = false;
                }

                dataGridView1.Columns["master_fio"].Width = 200;
                dataGridView1.Columns["device_name"].Width = 150;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка подключения к БД: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int n = dataGridView1.CurrentRow.Index;
            master_fio = dataGridView1.Rows[n].Cells["master_fio"].Value.ToString();
            specialization = dataGridView1.Rows[n].Cells["specialization"].Value.ToString();
            experience = dataGridView1.Rows[n].Cells["experience"].Value.ToString();
            device_name = dataGridView1.Rows[n].Cells["device_name"].Value.ToString();
            device_type = dataGridView1.Rows[n].Cells["device_type"].Value.ToString();
            device_brand = dataGridView1.Rows[n].Cells["device_brand"].Value.ToString();
            serial_number = dataGridView1.Rows[n].Cells["serial_number"].Value.ToString();
            date_gave = dataGridView1.Rows[n].Cells["Дата выдачи"].Value.ToString();
            date_return = dataGridView1.Rows[n].Cells["Дата возврата"].Value.ToString();
        }

        private void reportB_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(master_fio))
            {
                MessageBox.Show("Сначала выберите строку в таблице.", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                Word.Application wordApp = new Word.Application();
                wordApp.Visible = false;

                Word.Document wordDocument = wordApp.Documents.Open(fileName);

                ReplaceWord("{full_name}", master_fio, wordDocument);
                ReplaceWord("{specialization}", specialization, wordDocument);
                ReplaceWord("{experience}", experience, wordDocument);
                ReplaceWord("{name}", device_name, wordDocument);
                ReplaceWord("{type}", device_type, wordDocument);
                ReplaceWord("{brand}", device_brand, wordDocument);
                ReplaceWord("{serial_number}", serial_number, wordDocument);
                ReplaceWord("{date_gave}", date_gave, wordDocument);
                ReplaceWord("{date_return}", date_return, wordDocument);

                wordApp.Visible = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при создании отчета: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        void ReplaceWord(string src, string dest, Word.Document doc)
        {
            Word.Range range = doc.Content;
            range.Find.ClearFormatting();
            range.Find.Execute(FindText: src, ReplaceWith: dest);
        }

        private void exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
