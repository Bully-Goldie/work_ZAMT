﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace pr17.Forms
{
    public partial class viewing : Form
    {
        string str = @"host=localhost;uid=root;pwd=root;database=pr17_kichigin;";
        string command = @"SELECT 
                    w.work_id,
                    m.full_name AS master_fio,
                    m.specification AS specialization,
                    m.experience,
                    d.name AS device_name,
                    d.type AS device_type,
                    d.brand AS device_brand,
                    d.serial_number,
                    w.date_gave AS `Дата выдачи`,
                    w.date_return AS `Дата возврата`
                FROM work w
                INNER JOIN master m ON w.master_id = m.master_id
                INNER JOIN devices d ON w.devices_id = d.devices_id
                ORDER BY w.date_gave DESC;";
        public viewing()
        {
            InitializeComponent();
        }

        private void viewing_Load(object sender, EventArgs e)
        {
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

            try
            {
                using (MySqlConnection conn = new MySqlConnection(str))
                {
                    conn.Open();

                    using (MySqlCommand cmd = new MySqlCommand(command, conn))
                    using (MySqlDataAdapter da = new MySqlDataAdapter(cmd))
                    {
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        dataGridView1.DataSource = dt;

                        dataGridView1.Columns["master_fio"].HeaderText = "ФИО мастера";
                        dataGridView1.Columns["specialization"].HeaderText = "Специализация";
                        dataGridView1.Columns["experience"].HeaderText = "Опыт (лет)";
                        dataGridView1.Columns["device_name"].HeaderText = "Название устройства";
                        dataGridView1.Columns["device_type"].HeaderText = "Тип устройства";
                        dataGridView1.Columns["device_brand"].HeaderText = "Бренд";
                        dataGridView1.Columns["serial_number"].HeaderText = "Серийный номер";
                        dataGridView1.Columns["Дата выдачи"].HeaderText = "Дата выдачи";
                        dataGridView1.Columns["Дата возврата"].HeaderText = "Дата возврата";

                        if (dataGridView1.Columns.Contains("work_id"))
                        {
                            dataGridView1.Columns["work_id"].Visible = false;
                        }

                        dataGridView1.Columns["master_fio"].Width = 200;
                        dataGridView1.Columns["device_name"].Width = 150;
                        dataGridView1.Columns["Дата выдачи"].Width = 100;
                        dataGridView1.Columns["Дата возврата"].Width = 100;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка подключения к БД: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
