﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace pr17.Forms
{
    public partial class addEdit : Form
    {
        string str = "host=localhost;uid=root;pwd=root;database=pr17_kichigin;";
        string command = @"SELECT 
                    w.work_id,
                    m.full_name AS master_fio,
                    m.specification AS specialization,
                    m.experience,
                    d.name AS device_name,
                    d.type AS device_type,
                    d.brand AS device_brand,
                    d.serial_number,
                    w.date_gave AS `Дата выдачи`,
                    w.date_return AS `Дата возврата`
                FROM work w
                INNER JOIN master m ON w.master_id = m.master_id
                INNER JOIN devices d ON w.devices_id = d.devices_id
                ORDER BY w.date_gave DESC;";
        public addEdit()
        {
            InitializeComponent();
            dateTimePicker1.Value = DateTime.Now;
            dateTimePicker1.MinDate = DateTime.Now;
        }
        private void add_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex == -1)
            {
                MessageBox.Show("Выберите мастера!");
                return;
            }

            if (comboBox2.SelectedIndex == -1)
            {
                MessageBox.Show("Выберите тип техники!");
                return;
            }

            if (string.IsNullOrWhiteSpace(textBox1.Text))
            {
                MessageBox.Show("Введите бренд техники!");
                return;
            }

            try
            {
                MySqlConnection con = new MySqlConnection(str);
                con.Open();

                int masterId = Convert.ToInt32(comboBox1.SelectedValue);
                string type = comboBox2.Text;
                string brand = textBox1.Text;
                string dateGave = DateTime.Now.ToString("yyyy-MM-dd");
                string dateReturn = dateTimePicker1.Value.ToString("yyyy-MM-dd");

                string insertDevice = @"INSERT INTO devices(name, type, brand, serial_number)
                                VALUES('Техника', @type, @brand, FLOOR(RAND()*900000)+100000)";
                MySqlCommand cmdDevice = new MySqlCommand(insertDevice, con);
                cmdDevice.Parameters.AddWithValue("@type", type);
                cmdDevice.Parameters.AddWithValue("@brand", brand);
                cmdDevice.ExecuteNonQuery();

                int deviceId = (int)cmdDevice.LastInsertedId;

                string insertWork = @"INSERT INTO work(master_id, devices_id, date_gave, date_return)
                              VALUES(@master, @device, @gave, @return)";
                MySqlCommand cmdWork = new MySqlCommand(insertWork, con);
                cmdWork.Parameters.AddWithValue("@master", masterId);
                cmdWork.Parameters.AddWithValue("@device", deviceId);
                cmdWork.Parameters.AddWithValue("@gave", dateGave);
                cmdWork.Parameters.AddWithValue("@return", dateReturn);
                cmdWork.ExecuteNonQuery();

                LoadData();
                MessageBox.Show("Запись успешно добавлена!");

                comboBox1.SelectedIndex = -1;
                comboBox2.SelectedIndex = -1;
                textBox1.Clear();
                dateTimePicker1.Value = DateTime.Now;


                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка добавления: " + ex.Message);
            }
        }
        private void LoadData()
        {
            try
            {
                MySqlConnection con = new MySqlConnection(str);
                con.Open();

                MySqlCommand cmd = new MySqlCommand(command, con);
                MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;

                dataGridView1.Columns["master_fio"].HeaderText = "ФИО мастера";
                dataGridView1.Columns["specialization"].HeaderText = "Специализация";
                dataGridView1.Columns["experience"].HeaderText = "Опыт (лет)";
                dataGridView1.Columns["device_name"].HeaderText = "Название устройства";
                dataGridView1.Columns["device_type"].HeaderText = "Тип устройства";
                dataGridView1.Columns["device_brand"].HeaderText = "Бренд";
                dataGridView1.Columns["serial_number"].HeaderText = "Серийный номер";
                dataGridView1.Columns["Дата выдачи"].HeaderText = "Дата выдачи";
                dataGridView1.Columns["Дата возврата"].HeaderText = "Дата возврата";

                if (dataGridView1.Columns.Contains("work_id"))
                {
                    dataGridView1.Columns["work_id"].Visible = false;
                }

                dataGridView1.Columns["master_fio"].Width = 200;
                dataGridView1.Columns["device_name"].Width = 150;
                dataGridView1.Columns["Дата выдачи"].Width = 100;
                dataGridView1.Columns["Дата возврата"].Width = 100;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка обновления таблицы: " + ex.Message);
            }
        }
        private void addEdit_Load(object sender, EventArgs e)
        {
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

            LoadData();

            try
            {
                MySqlConnection con = new MySqlConnection(str);
                con.Open();

                string cmdMaster = @"SELECT master_id, full_name FROM master";
                MySqlDataAdapter daMaster = new MySqlDataAdapter(cmdMaster, con);
                DataTable dtMaster = new DataTable();
                daMaster.Fill(dtMaster);

                comboBox1.DataSource = dtMaster;
                comboBox1.DisplayMember = "full_name";
                comboBox1.ValueMember = "master_id";
                comboBox1.SelectedIndex = -1;
                comboBox1.DropDownStyle = ComboBoxStyle.DropDownList;

                string cmdType = @"SELECT DISTINCT type FROM devices";
                MySqlDataAdapter daType = new MySqlDataAdapter(cmdType, con);
                DataTable dtType = new DataTable();
                daType.Fill(dtType);

                comboBox2.DataSource = dtType;
                comboBox2.DisplayMember = "type";
                comboBox2.ValueMember = "type";
                comboBox2.SelectedIndex = -1;
                comboBox2.DropDownStyle = ComboBoxStyle.DropDownList;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка подключения к БД: {ex.Message}");
            }
        }
        private void exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
