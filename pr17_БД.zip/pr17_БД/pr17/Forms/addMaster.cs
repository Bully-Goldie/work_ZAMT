﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace pr17.Forms
{
    public partial class addMaster : Form
    {
        string str = "host=localhost;user=root;pwd=root;database=pr17_kichigin;";
        public addMaster()
        {
            InitializeComponent();
            LoadSpecifications();
        }
        private void LoadSpecifications()
        {
            comboBox1.Items.Clear();

            try
            {
                MySqlConnection conn = new MySqlConnection(str);
                {
                    conn.Open();

                    string sql = "SELECT DISTINCT specification FROM master";

                    MySqlCommand cmd = new MySqlCommand(sql, conn);
                    MySqlDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        comboBox1.Items.Add(reader.GetString(0));
                    }

                    reader.Close();
                }

                comboBox1.DropDownStyle = ComboBoxStyle.DropDownList;
            }
            catch (Exception)
            {
                MessageBox.Show("Ошибка загрузки квалификаций из БД");
            }
        }
        private void add_Click(object sender, EventArgs e)
        {
            string fullName = textBox1.Text.Trim();
            string experienceText = textBox2.Text.Trim();
            string phone = maskedTextBox1.Text.Trim();
            string specification = comboBox1.Text;

            if (string.IsNullOrWhiteSpace(fullName))
            {
                MessageBox.Show("Введите ФИО мастера");
                return;
            }

            if (string.IsNullOrWhiteSpace(experienceText))
            {
                MessageBox.Show("Введите стаж");
                return;
            }

            if (!maskedTextBox1.MaskCompleted)
            {
                MessageBox.Show("Введите полный номер телефона");
                return;
            }

            if (string.IsNullOrWhiteSpace(specification))
            {
                MessageBox.Show("Выберите квалификацию");
                return;
            }

            int experience = Convert.ToInt32(experienceText);

            try
            {
                MySqlConnection conn = new MySqlConnection(str);
                conn.Open();

                string sql = @"INSERT INTO master 
                              (full_name, experience, phone, specification)
                              VALUES (@fullName, @experience, @phone, @spec)";

                MySqlCommand cmd = new MySqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@fullName", fullName);
                cmd.Parameters.AddWithValue("@experience", experience);
                cmd.Parameters.AddWithValue("@phone", phone);
                cmd.Parameters.AddWithValue("@spec", specification);

                int res = cmd.ExecuteNonQuery();

                if (res > 0)
                {
                    MessageBox.Show("Мастер успешно добавлен!");

                    textBox1.Clear();
                    textBox2.Clear();
                    maskedTextBox1.Clear();
                    comboBox1.SelectedIndex = -1;
                }
                else
                {
                    MessageBox.Show("Не удалось добавить мастера");
                }

                conn.Close();
            }
            catch (Exception)
            {
                MessageBox.Show("Ошибка подключения к базе данных!");
            }
        }
        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;

            if ((ch >= 'А' && ch <= 'я') || ch == (char)Keys.Back || ch == (char)Keys.Space)
            {
                e.Handled = false;

                return;
            }

            e.Handled = true;
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = Char.IsDigit(e.KeyChar) || e.KeyChar == (char)Keys.Back ? false : true;
        }

        private void exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
