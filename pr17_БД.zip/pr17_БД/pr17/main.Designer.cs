﻿namespace pr17
{
    partial class main
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(main));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.exit = new System.Windows.Forms.Button();
            this.view = new System.Windows.Forms.Button();
            this.report = new System.Windows.Forms.Button();
            this.addEdit = new System.Windows.Forms.Button();
            this.addMaster = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1008, 348);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // exit
            // 
            this.exit.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.exit.Location = new System.Drawing.Point(0, 654);
            this.exit.Name = "exit";
            this.exit.Size = new System.Drawing.Size(1008, 75);
            this.exit.TabIndex = 1;
            this.exit.Text = "Выход";
            this.exit.UseVisualStyleBackColor = true;
            this.exit.Click += new System.EventHandler(this.exit_Click);
            // 
            // view
            // 
            this.view.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.view.Location = new System.Drawing.Point(0, 579);
            this.view.Name = "view";
            this.view.Size = new System.Drawing.Size(1008, 75);
            this.view.TabIndex = 2;
            this.view.Text = "Просмотр";
            this.view.UseVisualStyleBackColor = true;
            this.view.Click += new System.EventHandler(this.view_Click);
            // 
            // report
            // 
            this.report.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.report.Location = new System.Drawing.Point(0, 504);
            this.report.Name = "report";
            this.report.Size = new System.Drawing.Size(1008, 75);
            this.report.TabIndex = 3;
            this.report.Text = "Фоматирования отчетов";
            this.report.UseVisualStyleBackColor = true;
            this.report.Click += new System.EventHandler(this.report_Click);
            // 
            // addEdit
            // 
            this.addEdit.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.addEdit.Location = new System.Drawing.Point(0, 429);
            this.addEdit.Name = "addEdit";
            this.addEdit.Size = new System.Drawing.Size(1008, 75);
            this.addEdit.TabIndex = 4;
            this.addEdit.Text = "Добавление услуги";
            this.addEdit.UseVisualStyleBackColor = true;
            this.addEdit.Click += new System.EventHandler(this.addEdit_Click);
            // 
            // addMaster
            // 
            this.addMaster.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.addMaster.Location = new System.Drawing.Point(0, 354);
            this.addMaster.Name = "addMaster";
            this.addMaster.Size = new System.Drawing.Size(1008, 75);
            this.addMaster.TabIndex = 5;
            this.addMaster.Text = "Добавление мастера";
            this.addMaster.UseVisualStyleBackColor = true;
            this.addMaster.Click += new System.EventHandler(this.addMaster_Click);
            // 
            // main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 26F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1008, 729);
            this.Controls.Add(this.addMaster);
            this.Controls.Add(this.addEdit);
            this.Controls.Add(this.report);
            this.Controls.Add(this.view);
            this.Controls.Add(this.exit);
            this.Controls.Add(this.pictureBox1);
            this.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "main";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Ателье по ремонту бытовой техники";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button exit;
        private System.Windows.Forms.Button view;
        private System.Windows.Forms.Button report;
        private System.Windows.Forms.Button addEdit;
        private System.Windows.Forms.Button addMaster;
    }
}

