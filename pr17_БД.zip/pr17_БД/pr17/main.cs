﻿using pr17.Forms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pr17
{
    public partial class main : Form
    {
        public main()
        {
            InitializeComponent();
        }
        private void addEdit_Click(object sender, EventArgs e)
        {
            addEdit open = new addEdit();
            this.Visible = false;
            open.ShowDialog();
            this.Visible = true;
        }
        private void report_Click(object sender, EventArgs e)
        {
            report open = new report();
            this.Visible = false;
            open.ShowDialog();
            this.Visible = true;
        }
        private void view_Click(object sender, EventArgs e)
        {
            viewing open = new viewing();
            this.Visible = false;
            open.ShowDialog();
            this.Visible = true;
        }
        private void addMaster_Click(object sender, EventArgs e)
        {
            addMaster open = new addMaster();
            this.Visible = false;
            open.ShowDialog();
            this.Visible = true;
        }
        private void exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
