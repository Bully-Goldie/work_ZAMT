﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassLibrary1;

namespace pr24
{
    internal class Program
    {
        static void Main(string[] args)
        {
        //Дано целое число N. Если оно является положительным, то вычесть из него 8; если отрицательным,
        //то прибавить к нему 6; если нулевым, то заменить его на 10. Вывести полученное число.
        m1:
            try
            {
                ClassLibrary1.task1 task1 = new ClassLibrary1.task1();
                Console.WriteLine("=== Задача 1 ===");
                Console.Write("Введите число N: ");
                int n = int.Parse(Console.ReadLine());
                Console.WriteLine($"Результат: {task1.ModifyNumber(n)}");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message.ToString());
                goto m1;
            }

        //Дан целочисленный массив, состоящий из N элементов (N > 0).
        //Сложить со всеми четными числами максимальное нечетное число из этого массива. Вывести новый полученный массив.
        m2:
            try
            {
                ClassLibrary1.task2 task2 = new ClassLibrary1.task2();

                Console.WriteLine("\n=== Задача 2 ===");

                Console.Write("Введите размер массива: ");
                int N = Convert.ToInt32(Console.ReadLine());

                Random random = new Random();

                int[] arr1 = new int[N];

                for (int i = 0; i < N; i++)
                {
                    arr1[i] = random.Next(50);
                }

                Console.WriteLine("Исходный массив: " + string.Join(", ", arr1));
                int[] res1 = task2.AddMaxOddToEvens(arr1);
                Console.WriteLine("Результат: " + string.Join(", ", res1));
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message.ToString());
                goto m2;
            }

        //Дан целочисленный массив, состоящий из N элементов (N > 0).
        //Сложить со всеми нечетными числами максимальное четное число из этого массива. Вывести новый полученный массив.
        m3:
            try
            {
                ClassLibrary1.task3 task3 = new ClassLibrary1.task3();

                Console.WriteLine("\n=== Задача 3 ===");
                Console.Write("Введите размер массива: ");
                int N = Convert.ToInt32(Console.ReadLine());

                Random random = new Random();
                int[] arr2 = new int[N];

                for (int i = 0; i < N; i++)
                {
                    arr2[i] = random.Next(50);
                }

                Console.WriteLine("Исходный массив: " + string.Join(", ", arr2));
                int[] res2 = task3.AddMaxEvenToOdds(arr2);
                Console.WriteLine("Результат: " + string.Join(", ", res2));
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message.ToString());
                goto m3;
            }
        }
    }
}
