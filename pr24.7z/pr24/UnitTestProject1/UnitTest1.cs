﻿using ClassLibrary1;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Threading.Tasks;

namespace UnitTestProject1
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void Task1_ModifyNumber_Positive()
        {
            ClassLibrary1.task1 task1 = new ClassLibrary1.task1();
            int input = 10;
            int expected = 2;
            int actual = task1.ModifyNumber(input);
            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void Task2_AddMaxOddToEvens_Basic()
        {
            ClassLibrary1.task2 task2 = new ClassLibrary1.task2();
            int[] input = { 2, 5, 8, 11 };
            int[] expected = { 13, 5, 19, 11 };
            int[] actual = task2.AddMaxOddToEvens(input);
            CollectionAssert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void Task3_AddMaxEvenToOdds_Basic()
        {
            ClassLibrary1.task3 task3 = new ClassLibrary1.task3();
            int[] input = { 3, 7, 4, 2 };
            int[] expected = { 7, 11, 4, 2 };
            int[] actual = task3.AddMaxEvenToOdds(input);
            CollectionAssert.AreEqual(expected, actual);
        }
    }
}
