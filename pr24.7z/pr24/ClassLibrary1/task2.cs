﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public class task2
    {
        public static int[] AddMaxOddToEvens(int[] arr)
        {
            if (arr.Length == 0)
                throw new ArgumentException("Массив не должен быть пустым");

            int maxOdd = arr.Where(x => x % 2 != 0).DefaultIfEmpty(0).Max();

            return arr.Select(x => x % 2 == 0 ? x + maxOdd : x).ToArray();
        }
    }
}
