﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public class task1
    {
        public static int ModifyNumber(int N)
        {
            if (N > 0)
                return N - 8;
            else if (N < 0)
                return N + 6;
            else
                return 10;
        }
    }
}
